"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrappeWebhookBody = exports.FrappeWebhookEvent = exports.FRAPPE_SIGNATURE_HEADER = void 0;
exports.safeEq = safeEq;
exports.frappeSignature = frappeSignature;
exports.verifyFrappeSignature = verifyFrappeSignature;
exports.parseFrappeWebhookBody = parseFrappeWebhookBody;
exports.frappeEventId = frappeEventId;
exports.supersededBy = supersededBy;
exports.planFrappeEvent = planFrappeEvent;
exports.withRepublish = withRepublish;
const crypto_1 = __importDefault(require("crypto"));
const zod_1 = require("zod");
const selection_1 = require("./selection");
/**
 * The inbound side of a Frappe core Webhook.
 *
 * Frappe signs `frappe.as_json(data)` with HMAC-SHA256 and sends the
 * standard-base64 digest in `X-Frappe-Webhook-Signature`; the request body
 * is that same string, so the digest is verified over the raw bytes and
 * never over anything re-serialised here. Two consequences the setup code
 * takes care of: the Webhook row must add a `Content-Type: application/json`
 * header (Frappe sends none, and without it Medusa does not keep the raw
 * body), and the body shape is whatever the Webhook's template says — ours
 * is `{event, doctype, name, doc}` with the whole document under `doc`.
 *
 * Pure: the route and the retry job both go through here.
 */
exports.FRAPPE_SIGNATURE_HEADER = "x-frappe-webhook-signature";
/** Constant-time string equality; unequal lengths are simply unequal. */
function safeEq(a, b) {
    const ab = Buffer.from(String(a ?? ""), "utf8");
    const bb = Buffer.from(String(b ?? ""), "utf8");
    if (ab.length !== bb.length)
        return false;
    return crypto_1.default.timingSafeEqual(ab, bb);
}
/** What Frappe puts in the header for this body and secret. */
function frappeSignature(rawBody, secret) {
    return crypto_1.default.createHmac("sha256", secret).update(rawBody).digest("base64");
}
function verifyFrappeSignature(args) {
    const header = Array.isArray(args.header) ? args.header[0] : args.header;
    if (!args.rawBody || !header || !args.secret)
        return false;
    const presented = String(header).trim();
    if (!presented)
        return false;
    const mac = crypto_1.default.createHmac("sha256", args.secret).update(args.rawBody);
    const digest = mac.digest();
    // Frappe sends base64. Hex is accepted so a hand-made curl can sign
    // with `openssl dgst -sha256 -hmac`.
    return safeEq(presented, digest.toString("base64")) || safeEq(presented, digest.toString("hex"));
}
exports.FrappeWebhookEvent = zod_1.z.enum(["on_update", "on_trash", "after_insert", "on_submit", "on_cancel"]);
const nameLike = zod_1.z.union([zod_1.z.string(), zod_1.z.number()]).transform((v) => String(v));
exports.FrappeWebhookBody = zod_1.z.object({
    event: exports.FrappeWebhookEvent,
    doctype: zod_1.z.string().min(1),
    name: nameLike.pipe(zod_1.z.string().min(1)),
    doc: zod_1.z.record(zod_1.z.any()),
});
function parseFrappeWebhookBody(raw) {
    let parsed = raw;
    if (Buffer.isBuffer(raw) || typeof raw === "string") {
        try {
            parsed = JSON.parse(Buffer.isBuffer(raw) ? raw.toString("utf8") : raw);
        }
        catch {
            return { ok: false, message: "body is not JSON" };
        }
    }
    const res = exports.FrappeWebhookBody.safeParse(parsed);
    if (!res.success) {
        const first = res.error.issues[0];
        const where = first?.path?.length ? first.path.join(".") : "body";
        return { ok: false, message: `${where}: ${first?.message ?? "invalid"}` };
    }
    return { ok: true, body: res.data };
}
/**
 * One id per (event, document, version). Frappe delivers a webhook up to
 * three times when we answer slowly; the same id lands on one sync row.
 */
function frappeEventId(body) {
    const modified = body.doc?.modified != null ? String(body.doc.modified) : "";
    return `frappe:${body.event}:${body.doctype}:${body.name}:${modified}`;
}
/**
 * Has a later delivery for the same document already applied? Replaying
 * an older body would put back what the later one changed. Rows are
 * matched by DocType and name; "later" is the document's `modified`,
 * which Frappe formats so that string order is time order.
 */
function supersededBy(body, rows) {
    const mine = String(body.doc?.modified ?? "");
    for (const r of rows ?? []) {
        if (r?.status !== "success")
            continue;
        const p = r.payload;
        if (!p || p.doctype !== body.doctype || String(p.name) !== body.name)
            continue;
        const theirs = String(p.doc?.modified ?? "");
        if (theirs && mine && theirs > mine)
            return true;
    }
    return false;
}
/**
 * What one webhook means for one mapping.
 *
 * The document's `medusa_sync` says which way it moves. ERPNext → Medusa
 * or Both: an update is upserted (republishing a product we drafted
 * earlier), a trash drafts. None (or a blank from before None existed) —
 * deselected — drafts, since the webhook only fires for such a document
 * when it moved ERPNext → Medusa before this
 * save, so the product is ours. Medusa → ERPNext is Medusa's own record:
 * nothing ERPNext does to its copy touches the product.
 *
 * The key is the raw value of the mapping's ERPNext key field, exactly as
 * the pull uses it; the entity decides how it matches (a handle is derived
 * from an item code by the product entity, not here).
 */
function planFrappeEvent(args) {
    const { event, doc, mapping, link } = args;
    const rawKey = doc?.[mapping.key_erpnext_field];
    const key = rawKey != null && rawKey !== "" ? String(rawKey) : null;
    const direction = (0, selection_1.selectionOf)(doc);
    if (direction === "absent") {
        return { action: "skip", reason: "document carries no medusa_sync field; run Set up ERPNext" };
    }
    if (direction === "medusa_to_erpnext") {
        return {
            action: "skip",
            reason: event === "on_trash"
                ? "ERPNext removed its copy of a Medusa-owned record; product untouched"
                : "record is Medusa → ERPNext; nothing to pull",
        };
    }
    if (event === "on_trash") {
        if (!(0, selection_1.allowsPull)(direction)) {
            return { action: "skip", reason: "trashed, but not selected for ERPNext → Medusa" };
        }
        if (link?.medusa_id)
            return { action: "draft", by: "link", medusa_id: link.medusa_id, key, reason: "trashed in ERPNext" };
        if (key)
            return { action: "draft", by: "key", key, reason: "trashed in ERPNext; no link, matched by key" };
        return { action: "skip", reason: `trashed, but no value for key field '${mapping.key_erpnext_field}'` };
    }
    if (!(0, selection_1.allowsPull)(direction)) {
        // A document that was Medusa-owned and is now unselected: ERPNext
        // stopped syncing it either way, and the product is still Medusa's.
        if (link && (0, selection_1.parseRecordDirection)(link.remote_direction) === "medusa_to_erpnext") {
            return { action: "skip", reason: "was Medusa → ERPNext, now unselected; product untouched" };
        }
        if (link?.medusa_id)
            return { action: "draft", by: "link", medusa_id: link.medusa_id, key, reason: "deselected in ERPNext" };
        if (key)
            return { action: "draft", by: "key", key, reason: "deselected in ERPNext; no link, matched by key" };
        return { action: "skip", reason: "not selected and never synced" };
    }
    if (!key) {
        return { action: "skip", reason: `no value for key field '${mapping.key_erpnext_field}'` };
    }
    const republish = mapping.medusa_entity === "product" && link?.state === "drafted";
    return {
        action: "upsert",
        key,
        republish,
        reason: republish ? "selected again; republishing" : "selected for ERPNext → Medusa",
    };
}
/**
 * The payload a document selected again writes. Republishing takes a
 * product we drafted back on sale, but a status the mapping produced from
 * the document itself (a disabled Item mapped to draft) is the document's
 * own answer and wins.
 */
function withRepublish(payload, republish) {
    if (!republish || payload?.status !== undefined)
        return payload;
    return { ...payload, status: "published" };
}
//# sourceMappingURL=frappe-webhook.js.map