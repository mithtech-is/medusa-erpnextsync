"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CANONICAL_MAPPINGS = void 0;
exports.findCanonicalMapping = findCanonicalMapping;
/**
 * Customer ↔ Customer.
 *
 * Neutral starter mapping against the standard ERPNext Customer
 * doctype. Medusa identifies a customer by email; ERPNext's Customer
 * carries `customer_name` as its required identity field. Adjust the
 * field pairs to whatever your Frappe instance actually exposes.
 */
const CUSTOMER_CUSTOMER = {
    name: "Customer ↔ Customer",
    description: "Example bidirectional Customer sync between Medusa and Frappe. Keyed on email ↔ email_id. Edit the field pairs to match your Frappe Customer doctype (custom fields, KYC, etc.).",
    enabled: true,
    medusa_entity: "customer",
    doctype: "Customer",
    direction: "both",
    events: ["customer.created", "customer.updated", "customer.deleted"],
    pull_filter: [],
    pull_page_size: 200,
    key_medusa_field: "email",
    key_erpnext_field: "email_id",
    field_mappings: [
        { medusa_path: "email", erpnext_field: "email_id", direction: "both", transform: "lowercase" },
        { medusa_path: "phone", erpnext_field: "mobile_no", direction: "both" },
        { medusa_path: "first_name", erpnext_field: "customer_name", direction: "push" },
    ],
};
exports.CANONICAL_MAPPINGS = [
    CUSTOMER_CUSTOMER,
];
/**
 * Lookup helper used by the admin editor's "Suggest field pairs"
 * button. Returns the canonical mapping (if any) for an
 * `(entity, doctype)` pair so the UI can pre-fill `field_mappings`.
 *
 * Doctype match is case-insensitive (Frappe is case-sensitive in
 * URLs but operators often type lowercase). Returns null when no
 * canonical entry exists — the UI then offers a heuristic name-
 * matching fallback.
 */
function findCanonicalMapping(entity, doctype) {
    const e = (entity || "").trim().toLowerCase();
    const d = (doctype || "").trim().toLowerCase();
    return (exports.CANONICAL_MAPPINGS.find((m) => m.medusa_entity.toLowerCase() === e &&
        m.doctype.toLowerCase() === d) ?? null);
}
//# sourceMappingURL=canonical-mappings.js.map