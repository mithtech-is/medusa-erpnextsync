"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PAIR_PREFIX = void 0;
exports.normalizeDirection = normalizeDirection;
exports.scrubDoctype = scrubDoctype;
exports.pairUid = pairUid;
exports.pairUidOf = pairUidOf;
exports.mergeFieldPairs = mergeFieldPairs;
exports.mergeEvents = mergeEvents;
exports.pickKeeper = pickKeeper;
exports.mergeDirection = mergeDirection;
/**
 * A sync is its pair.
 *
 * One Medusa entity and one DocType is one mapping, whatever it is called
 * and however it was created, so the identity is derived from the pair
 * rather than generated. The unique index on `mapping_uid` and the fold
 * rules below keep two rows for one pair from surviving. Everything here
 * is pure.
 */
/** Normalise a stored direction into the canonical vocabulary. */
function normalizeDirection(value) {
    const v = String(value ?? "both").toLowerCase();
    return v === "push" || v === "pull" ? v : "both";
}
exports.PAIR_PREFIX = "pair:";
/** `Sales Invoice (Return)` → `sales_invoice_return`. */
function scrubDoctype(doctype) {
    return String(doctype ?? "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
}
function pairUid(entity, doctype) {
    return `${exports.PAIR_PREFIX}${String(entity ?? "").trim().toLowerCase()}:${scrubDoctype(doctype)}`;
}
function pairUidOf(row) {
    return pairUid(row.medusa_entity, row.doctype);
}
/** Union by target: the Frappe field, or the Medusa path for a pull-fixed
 *  pair that has none. The base wins a collision. */
function mergeFieldPairs(base, extra) {
    const keyOf = (p) => p.erpnext_field
        ? `${String(p.erpnext_doctype ?? "").trim()}:${p.erpnext_field}`
        : p.medusa_path
            ? `medusa:${p.medusa_path}`
            : "";
    const taken = new Set((base ?? []).map(keyOf).filter(Boolean));
    return [
        ...(base ?? []),
        ...(extra ?? []).filter((p) => keyOf(p) && !taken.has(keyOf(p))),
    ];
}
function mergeEvents(a, b) {
    const out = [];
    for (const e of [...(a ?? []), ...(b ?? [])]) {
        if (e && !out.includes(e))
            out.push(e);
    }
    return out;
}
/**
 * Which of several mappings for one pair survives a fold: the higher
 * version, then the one that is switched on, then the older row. Returns
 * the index into `rows`.
 */
function pickKeeper(rows) {
    const ts = (v) => (v ? new Date(v).getTime() : Number.MAX_SAFE_INTEGER);
    let best = 0;
    for (let i = 1; i < rows.length; i++) {
        const a = rows[i];
        const b = rows[best];
        const av = Number(a.version ?? 1);
        const bv = Number(b.version ?? 1);
        if (av !== bv) {
            if (av > bv)
                best = i;
            continue;
        }
        if (Boolean(a.enabled) !== Boolean(b.enabled)) {
            if (a.enabled)
                best = i;
            continue;
        }
        if (ts(a.created_at) < ts(b.created_at))
            best = i;
    }
    return best;
}
/** Two mappings for one pair, folded: the same way stays, a one-way sync
 *  meeting its opposite becomes two-way. */
function mergeDirection(a, b) {
    const x = normalizeDirection(a);
    const y = normalizeDirection(b);
    return x === y ? x : "both";
}
//# sourceMappingURL=pair-identity.js.map