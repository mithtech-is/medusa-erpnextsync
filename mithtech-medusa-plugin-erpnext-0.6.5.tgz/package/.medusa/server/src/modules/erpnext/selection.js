"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_SYNC_DOCTYPES = exports.DEFAULT_CATALOGUE_DOCTYPE = exports.PUSH_VALUES = exports.PULL_VALUES = exports.SELECTION_OPTIONS = exports.DIRECTION_NONE = exports.DIRECTION_BOTH = exports.DIRECTION_MEDUSA_TO_ERPNEXT = exports.DIRECTION_ERPNEXT_TO_MEDUSA = exports.SELECTION_FIELD = void 0;
exports.selectionDefault = selectionDefault;
exports.normalizeSyncDoctypes = normalizeSyncDoctypes;
exports.isSyncDoctype = isSyncDoctype;
exports.withSelectionFilter = withSelectionFilter;
exports.parseRecordDirection = parseRecordDirection;
exports.selectionOf = selectionOf;
exports.allowsPull = allowsPull;
exports.allowsPush = allowsPush;
exports.effectiveDirection = effectiveDirection;
exports.pushAllowedByRecord = pushAllowedByRecord;
exports.reconcileDecision = reconcileDecision;
exports.resolveProductsDoctype = resolveProductsDoctype;
exports.deriveSyncDoctypes = deriveSyncDoctypes;
/** The Frappe fieldname. The Custom Field is named `<DocType>-medusa_sync`. */
exports.SELECTION_FIELD = "medusa_sync";
/** The Select's option strings, exactly as stored on the document. */
exports.DIRECTION_ERPNEXT_TO_MEDUSA = "ERPNext → Medusa";
exports.DIRECTION_MEDUSA_TO_ERPNEXT = "Medusa → ERPNext";
exports.DIRECTION_BOTH = "Both";
/** Stored, not left blank, so a document plainly says it is kept out. */
exports.DIRECTION_NONE = "None";
exports.SELECTION_OPTIONS = [
    exports.DIRECTION_NONE,
    exports.DIRECTION_ERPNEXT_TO_MEDUSA,
    exports.DIRECTION_MEDUSA_TO_ERPNEXT,
    exports.DIRECTION_BOTH,
];
/** Values under which ERPNext → Medusa (webhooks, pull) applies. */
exports.PULL_VALUES = [exports.DIRECTION_ERPNEXT_TO_MEDUSA, exports.DIRECTION_BOTH];
/** Values under which Medusa → ERPNext (push) applies. */
exports.PUSH_VALUES = [exports.DIRECTION_MEDUSA_TO_ERPNEXT, exports.DIRECTION_BOTH];
/** What holds the catalogue when nobody has said otherwise. */
exports.DEFAULT_CATALOGUE_DOCTYPE = "Item";
exports.DEFAULT_SYNC_DOCTYPES = [
    { doctype: exports.DEFAULT_CATALOGUE_DOCTYPE, mode: "allow" },
];
/** The field's default for new documents in each mode. */
function selectionDefault(mode) {
    return mode === "deny" ? exports.DIRECTION_BOTH : exports.DIRECTION_NONE;
}
/** Coerce whatever the settings row or the admin form holds into a clean
 *  list: trimmed doctype names, no duplicates, mode defaulting to allow. */
function normalizeSyncDoctypes(raw) {
    const out = [];
    const seen = new Set();
    const rows = Array.isArray(raw) ? raw : [];
    for (const row of rows) {
        const doctype = typeof row === "string"
            ? row.trim()
            : String(row?.doctype ?? "").trim();
        if (!doctype || seen.has(doctype))
            continue;
        seen.add(doctype);
        const mode = String(row?.mode ?? "allow").toLowerCase() === "deny" ? "deny" : "allow";
        out.push({ doctype, mode });
    }
    return out;
}
function isSyncDoctype(doctype, list) {
    const wanted = String(doctype ?? "").trim();
    return Boolean(wanted) && (list ?? []).some((d) => d.doctype === wanted);
}
/**
 * The pull filter for a selection DocType always carries
 * `["medusa_sync","in",["ERPNext → Medusa","Both"]]`. Nothing is pulled
 * from such a DocType without it — if the field does not exist yet,
 * Frappe refuses the query and the pull reports it, which is the failure
 * we want (run Set up ERPNext), not a page of unselected documents.
 */
function withSelectionFilter(filters, doctype, list) {
    const out = Array.isArray(filters) ? [...filters] : [];
    if (!isSyncDoctype(doctype, list))
        return out;
    const present = out.some((f) => Array.isArray(f) && String(f[0]) === exports.SELECTION_FIELD);
    if (!present)
        out.push([exports.SELECTION_FIELD, "in", [...exports.PULL_VALUES]]);
    return out;
}
/** The stored value → a direction. Anything the Select never offered is "none". */
function parseRecordDirection(value) {
    const v = String(value ?? "").trim();
    if (v === exports.DIRECTION_ERPNEXT_TO_MEDUSA)
        return "erpnext_to_medusa";
    if (v === exports.DIRECTION_MEDUSA_TO_ERPNEXT)
        return "medusa_to_erpnext";
    if (v === exports.DIRECTION_BOTH)
        return "both";
    return "none";
}
function selectionOf(doc) {
    if (!doc || typeof doc !== "object" || !(exports.SELECTION_FIELD in doc))
        return "absent";
    return parseRecordDirection(doc[exports.SELECTION_FIELD]);
}
/** May this document move ERPNext → Medusa? */
function allowsPull(d) {
    return d === "erpnext_to_medusa" || d === "both";
}
/** May this document move Medusa → ERPNext? */
function allowsPush(d) {
    return d === "medusa_to_erpnext" || d === "both";
}
/**
 * What a mapping may do with one document: the mapping's direction
 * narrowed by the document's. A document never widens a mapping.
 *
 * "absent" is a document with no field — a DocType outside selection —
 * and narrows nothing; the mapping alone decides.
 */
function effectiveDirection(mapping, record) {
    const m = String(mapping ?? "both").toLowerCase();
    const canPush = (m === "push" || m === "both") && (record === "absent" || allowsPush(record));
    const canPull = (m === "pull" || m === "both") && (record === "absent" || allowsPull(record));
    if (canPush && canPull)
        return "both";
    if (canPush)
        return "push";
    if (canPull)
        return "pull";
    return "none";
}
/**
 * May a push for this Medusa record leave? The link table remembers the
 * direction ERPNext last showed for the document it became; a record
 * nobody has seen over there yet has no link and is the mapping's and the
 * product policy's to decide.
 */
function pushAllowedByRecord(link) {
    // No link, or a link whose document ERPNext has never shown us a
    // direction for (made by hand, or pulled from a DocType outside
    // selection): nothing to narrow by.
    if (!link || link.remote_direction === null || link.remote_direction === undefined)
        return { allowed: true };
    const d = parseRecordDirection(link.remote_direction);
    if (allowsPush(d))
        return { allowed: true };
    return {
        allowed: false,
        reason: d === "none"
            ? "record-direction: not selected for sync in ERPNext"
            : `record-direction: set to "${exports.DIRECTION_ERPNEXT_TO_MEDUSA}" in ERPNext`,
    };
}
/**
 * What the hourly reconcile does with one linked document, given the
 * `medusa_sync` value ERPNext reports for it now — or `undefined` when
 * ERPNext no longer has a document of that name (trashed, renamed).
 *
 *   keep   — still moving ERPNext → Medusa; note the value, touch nothing
 *   owned  — Medusa → ERPNext: Medusa's own record, never drafted
 *   draft  — deselected or gone: the product comes off sale
 */
function reconcileDecision(value) {
    if (value === undefined)
        return "draft";
    const d = parseRecordDirection(value);
    if (allowsPull(d))
        return "keep";
    if (d === "medusa_to_erpnext")
        return "owned";
    return "draft";
}
/**
 * Which DocType "link this product to an existing document" searches.
 * The enabled product mapping says so; failing that, the first selection
 * DocType; failing that, Item.
 */
function resolveProductsDoctype(list, mappings) {
    const fromMapping = (mappings ?? []).find((m) => m?.medusa_entity === "product" && m?.enabled !== false && m?.doctype);
    if (fromMapping?.doctype)
        return String(fromMapping.doctype);
    if (list?.length)
        return list[0].doctype;
    return exports.DEFAULT_CATALOGUE_DOCTYPE;
}
/**
 * The selection list, derived from the syncs: every mapping with a pull
 * leg puts its DocType under selection, and its own choice of mode
 * (allow: new documents start on None; deny: they start on Both) rides
 * along. Two syncs on one DocType that disagree resolve to allow — the
 * conservative side, since deny switches every existing document on at
 * the first setup. Push-only syncs need no field and no webhooks.
 */
function deriveSyncDoctypes(mappings) {
    const modes = new Map();
    for (const m of mappings ?? []) {
        const doctype = String(m?.doctype ?? "").trim();
        const direction = String(m?.direction ?? "both").toLowerCase();
        if (!doctype || direction === "push")
            continue;
        const mode = String(m?.selection_mode ?? "").toLowerCase() === "deny" ? "deny" : "allow";
        const seen = modes.get(doctype);
        modes.set(doctype, seen === undefined ? mode : seen === "deny" && mode === "deny" ? "deny" : "allow");
    }
    return Array.from(modes.entries())
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([doctype, mode]) => ({ doctype, mode }));
}
//# sourceMappingURL=selection.js.map