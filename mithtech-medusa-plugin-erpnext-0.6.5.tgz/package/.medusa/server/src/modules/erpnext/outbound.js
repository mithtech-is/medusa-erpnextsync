"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OUTBOUND_PAUSED_MESSAGE = exports.OUTBOUND_PAUSED_REASON = exports.OUTBOUND_PAUSED = void 0;
exports.pausedResult = pausedResult;
/**
 * Medusa → ERPNext can be paused.
 *
 * Pushes run over plain Frappe REST. Set `ERPNEXT_PAUSE_PUSH=true` to stop
 * them without touching the mappings: every push mapping is still
 * evaluated (policy, trigger, allowlist, transform) and then stops, on
 * record, so nothing is lost and nothing leaves.
 */
exports.OUTBOUND_PAUSED = process.env.ERPNEXT_PAUSE_PUSH === "true";
exports.OUTBOUND_PAUSED_REASON = "outbound-paused";
exports.OUTBOUND_PAUSED_MESSAGE = "Pushes to ERPNext are paused (ERPNEXT_PAUSE_PUSH=true); ERPNext → Medusa is live.";
function pausedResult() {
    return { ok: true, status: "skipped", reason: exports.OUTBOUND_PAUSED_REASON, message: exports.OUTBOUND_PAUSED_MESSAGE };
}
//# sourceMappingURL=outbound.js.map