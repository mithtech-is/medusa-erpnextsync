"use strict";
/**
 * Registry of Medusa-side entities the mapping UI can target.
 *
 * Each entry describes:
 *   - which Medusa module owns the entity (built-in or custom)
 *   - which event names fire on its lifecycle (used as the default
 *     `events` array suggestion in the admin form)
 *   - the dot-paths the operator can pick from in the left column of
 *     the field-mapper (with types + descriptions, so the UI can
 *     render a sensible picker)
 *   - how to fetch a fully-enriched record by id (used by the push
 *     subscriber + the pull cron's upsert path)
 *   - how to upsert a record by an arbitrary key (used by the pull
 *     cron when applying changes from Frappe back into Medusa)
 *   - whether the underlying module is actually installed on this
 *     Medusa deployment — controls whether the entity shows up in
 *     the admin picker
 *
 * Built-in modules (CUSTOMER, ORDER, PRODUCT, CART, REGION, …) are
 * always available — Medusa wires them into every project. Custom
 * modules only appear if registered in medusa-config.ts. The
 * availability check is a try/catch around
 * `container.resolve(moduleName)` — no separate registration list to
 * keep in sync.
 *
 * Extending the registry: new entry per entity, ideally via the
 * `genericEntity()` builder so the boilerplate stays tiny. The
 * builder derives the standard `fetchById` / `upsertByKey` /
 * `availableInContainer` adapters from a module name + model name.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleFromKey = handleFromKey;
exports.titleFromText = titleFromText;
exports.isEntityAvailable = isEntityAvailable;
exports.listMedusaEntities = listMedusaEntities;
exports.getMedusaEntity = getMedusaEntity;
const utils_1 = require("@medusajs/framework/utils");
const crypto_1 = __importDefault(require("crypto"));
const order_accounting_1 = require("./order-accounting");
/**
 * A Medusa product handle built from a key the other system chose.
 *
 * Medusa requires a URL-safe handle, and an ERP item code is not one:
 * spaces, dots, slashes and brackets are all ordinary in a part number
 * (`BRKT-ASSY 12.5 MM/L (ZN)`). Rejecting those would put most of a
 * real catalogue out of reach, so the handle is derived and
 * the exact code is kept on the variant SKU, where it stays searchable.
 *
 * The result is a pure function of the input: the same item code always
 * yields the same handle, which is what lets the upsert find its own
 * product again instead of creating a second one on every sync.
 */
function handleFromKey(raw) {
    const slug = String(raw ?? "")
        .normalize("NFKD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 120)
        .replace(/-+$/g, "");
    // Two different codes can flatten to the same slug ("A/1" and "A-1"),
    // and an empty one is possible if the code is all punctuation. Both
    // fall back to a digest of the original so the handle stays unique
    // and still deterministic.
    if (!slug)
        return `item-${digestOf(raw)}`;
    return slug;
}
/**
 * A product title built from an ERP description field.
 *
 * ERPNext descriptions are spec text, not names: some arrive wrapped in
 * the rich-text editor's markup (`<div><p>…</p></div>`), and many are hard
 * -wrapped at a fixed column, so the name breaks across lines mid-phrase
 * (`12K HOUR KIT FOR AIR\nCOMPRESSOR`). A storefront cannot show either.
 *
 * Casing is deliberately left alone. Titling this text would turn `GI`,
 * `KVA` and `MS` into `Gi`, `Kva` and `Ms` — the abbreviations are the
 * part of the name a buyer recognises.
 */
function titleFromText(raw) {
    return String(raw ?? "")
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]*>/g, " ")
        .replace(/&nbsp;/gi, " ")
        .replace(/&amp;/gi, "&")
        .replace(/&lt;/gi, "<")
        .replace(/&gt;/gi, ">")
        .replace(/&quot;/gi, '"')
        .replace(/&#39;/g, "'")
        .replace(/\s+/g, " ")
        .trim();
}
function digestOf(raw) {
    return crypto_1.default.createHash("sha1").update(String(raw ?? "")).digest("hex").slice(0, 8);
}
function genericEntity(args) {
    const suffix = args.methodSuffix ?? `${args.modelName}s`;
    const listFn = `list${suffix}`;
    const updateFn = `update${suffix}`;
    const createFn = `create${suffix}`;
    return {
        key: args.key,
        label: args.label,
        moduleName: args.moduleName,
        modelName: args.modelName,
        isCustomModule: args.isCustomModule ?? false,
        events: args.events,
        paths: args.paths,
        default_key_path: args.default_key_path,
        disableByKey: args.disableByKey,
        async fetchById(container, id) {
            const m = container.resolve(args.moduleName);
            // withDeleted so `.deleted` events (which fire after the row is
            // soft-deleted) still enrich to the full record — the mapping key
            // (email/handle) is needed to tell Frappe which doc to disable.
            const opts = { take: 1, withDeleted: true };
            if (args.fetchRelations?.length)
                opts.relations = args.fetchRelations;
            const rows = await m[listFn]({ id }, opts);
            return rows?.[0] ?? null;
        },
        async upsertByKey(container, key_field, key_value, payload) {
            if (args.upsertByKey) {
                return args.upsertByKey(container, key_field, key_value, payload);
            }
            const m = container.resolve(args.moduleName);
            const filter = {};
            filter[key_field] = key_value;
            const [existing] = await m[listFn](filter, { take: 1 });
            if (existing) {
                const [updated] = await m[updateFn]([
                    { id: existing.id, ...payload },
                ]);
                return { ok: true, id: updated.id, created: false };
            }
            if (typeof m[createFn] === "function") {
                const created = await m[createFn]([payload]);
                const row = Array.isArray(created) ? created[0] : created;
                return { ok: true, id: row?.id, created: true };
            }
            return {
                ok: false,
                error: `module '${args.moduleName}' has no ${createFn} helper`,
            };
        },
    };
}
// ─── Built-in Medusa entities (always available) ─────────────────────
const customerEntity = genericEntity({
    key: "customer",
    label: "Customer",
    moduleName: utils_1.Modules.CUSTOMER,
    modelName: "Customer",
    events: [
        "customer.created",
        "customer.updated",
        "customer.deleted",
    ],
    default_key_path: "email",
    fetchRelations: ["addresses"],
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "email", label: "Email", type: "string", suggested_transform: "lowercase" },
        { path: "first_name", label: "First name", type: "string" },
        { path: "last_name", label: "Last name", type: "string" },
        { path: "phone", label: "Phone", type: "string", suggested_transform: "trim" },
        { path: "company_name", label: "Company", type: "string" },
        { path: "has_account", label: "Has account", type: "boolean" },
        { path: "addresses.0.address_1", label: "Primary address line 1", type: "string" },
        { path: "addresses.0.address_2", label: "Primary address line 2", type: "string" },
        { path: "addresses.0.city", label: "Primary city", type: "string" },
        { path: "addresses.0.province", label: "Primary state / province", type: "string" },
        { path: "addresses.0.postal_code", label: "Primary postal code", type: "string" },
        { path: "addresses.0.country_code", label: "Primary country (ISO)", type: "string", suggested_transform: "uppercase" },
        { path: "metadata", label: "Whole metadata blob", type: "json", suggested_transform: "json" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
        { path: "updated_at", label: "Updated at", type: "datetime", suggested_transform: "date_iso" },
    ],
    upsertByKey: async (container, _kf, _kv, payload) => {
        const m = container.resolve(utils_1.Modules.CUSTOMER);
        const email = payload.email;
        if (!email)
            return { ok: false, error: "customer upsert needs `email` on the payload" };
        const existingList = (await m.listCustomers({ email }, { take: 1 })) || [];
        const existing = existingList[0];
        if (existing) {
            // Selector/data form on purpose: the array-with-id form
            // `updateCustomers([{id, ...}])` trips a mikro-orm exception-
            // converter bug on some Medusa builds (masks the real error as
            // "reading '0'"); the selector form is unaffected.
            await m.updateCustomers({ id: existing.id }, payload);
            return { ok: true, id: existing.id, created: false };
        }
        const created = await m.createCustomers([payload]);
        const c = Array.isArray(created) ? created[0] : created;
        return { ok: true, id: c?.id, created: true };
    },
    // Safe inbound delete: mark the customer disabled in metadata rather
    // than destroying the record (reversible). key_value is the mapped
    // key (email by default).
    disableByKey: async (container, _kf, key_value) => {
        const m = container.resolve(utils_1.Modules.CUSTOMER);
        const existingList = (await m.listCustomers({ email: key_value }, { take: 1 })) || [];
        const existing = existingList[0];
        if (!existing)
            return { ok: true, skipped: true, action: "absent" };
        // Selector/data form (see upsertByKey note).
        await m.updateCustomers({ id: existing.id }, { metadata: { ...(existing.metadata || {}), erpnext_disabled: true } });
        return { ok: true, id: existing.id, action: "disabled" };
    },
});
// Enrich the customer record with its B2B company's GSTIN before it is pushed.
// The base fetchById returns the customer + addresses; the linked company (and
// therefore the GSTIN) is not part of the Medusa customer model, so we resolve
// it here — the only place on the push path with a container. The link is read
// from `metadata.company_id` (the mirror the storefront writes; present for
// every company-linked customer on this build) with a fallback to a raw
// `company_id` column if a future model exposes it. Fully guarded: no company
// module, no link, or a failed lookup just ships the customer without a GSTIN.
{
    const baseCustomerFetch = customerEntity.fetchById;
    customerEntity.fetchById = async (container, id) => {
        const rec = await baseCustomerFetch(container, id);
        if (!rec)
            return rec;
        try {
            const companyId = rec.company_id ?? rec.metadata?.company_id;
            if (companyId) {
                const companySvc = container.resolve("company");
                const list = (await companySvc?.listCompanies?.({ id: companyId }, { take: 1 })) || [];
                const co = list[0];
                if (co) {
                    rec.gstin = co.gstin ?? null;
                    rec.company_trade_name = co.trade_name ?? null;
                    // The company's GST-registered billing address (a JSON blob
                    // {line1,line2,city,state,postal_code,country_code}) — carried
                    // through so the augment step can emit it as an Address too.
                    rec.company_billing_address = co.billing_address ?? null;
                    rec.company_id_resolved = companyId;
                }
            }
        }
        catch {
            // No company module (generic deployment) or lookup failed — the
            // customer still syncs, just without GSTIN/company data.
        }
        return rec;
    };
}
const customerGroupEntity = genericEntity({
    key: "customer_group",
    label: "Customer group",
    moduleName: utils_1.Modules.CUSTOMER,
    modelName: "CustomerGroup",
    events: ["customer_group.created", "customer_group.updated", "customer_group.deleted"],
    default_key_path: "name",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "name", label: "Name", type: "string" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
    ],
});
/**
 * What the store actually captured for an order, for ERPNext to book, and
 * every provider the order is paid through (a cash-on-delivery payment is
 * authorised at checkout but captured much later, if at all).
 *
 * Asked of the payment collections on their own: loading payments nested
 * under the order has crashed the order query before, and an order that
 * cannot be enriched is an order that never reaches ERPNext. A failure
 * here leaves the lists empty, so ERPNext books no payment rather than
 * guessing one.
 */
async function orderPayments(query, collections) {
    const ids = (collections ?? []).map((c) => c?.id).filter(Boolean);
    if (!ids.length)
        return { captured: [], providers: [] };
    try {
        const { data } = await query.graph({
            entity: "payment_collection",
            fields: [
                "id",
                "payments.id",
                "payments.amount",
                "payments.currency_code",
                "payments.provider_id",
                "payments.captured_at",
                "payments.data",
                "payments.captures.id",
                "payments.captures.amount",
                "payments.refunds.amount",
                "payment_sessions.provider_id",
                "payment_sessions.status",
            ],
            filters: { id: ids },
        });
        const captured = [];
        const providers = [];
        const provider = (p) => {
            const v = String(p ?? "");
            if (v && !providers.includes(v))
                providers.push(v);
        };
        for (const collection of data ?? []) {
            for (const p of collection?.payments ?? []) {
                provider(p?.provider_id);
                const capturedAmount = (p?.captures ?? []).reduce((sum, c) => sum + (Number(c?.amount) || 0), 0);
                if (!p?.captured_at && !capturedAmount)
                    continue;
                captured.push({
                    id: p.id,
                    // Medusa 2 keeps money in the currency's major unit.
                    amount: capturedAmount || Number(p.amount) || 0,
                    currency: p.currency_code ?? null,
                    provider_id: p.provider_id ?? null,
                    captured_at: p.captured_at ?? new Date().toISOString(),
                    reference: (0, order_accounting_1.transactionReference)(p.data) ?? p.id,
                    refunded: (p?.refunds ?? []).reduce((sum, r) => sum + (Number(r?.amount) || 0), 0),
                });
            }
            if (!(collection?.payments ?? []).length) {
                for (const session of collection?.payment_sessions ?? []) {
                    if (session?.status === "authorized" || session?.status === "captured")
                        provider(session.provider_id);
                }
            }
        }
        return { captured, providers };
    }
    catch (err) {
        console.warn("[erpnext] could not read the order's payments", err);
        return { captured: [], providers: [] };
    }
}
const orderEntity = {
    key: "order",
    label: "Order",
    moduleName: utils_1.Modules.ORDER,
    modelName: "Order",
    isCustomModule: false,
    events: ["order.placed", "order.payment_captured", "order.payment_refunded", "order.fulfillment_created", "order.canceled"],
    default_key_path: "display_id",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "display_id", label: "Display id (#42)", type: "number" },
        { path: "email", label: "Customer email", type: "string", suggested_transform: "lowercase" },
        { path: "currency_code", label: "Currency", type: "string", suggested_transform: "uppercase" },
        { path: "total", label: "Total (minor units)", type: "number" },
        { path: "subtotal", label: "Subtotal (minor units)", type: "number" },
        { path: "tax_total", label: "Tax total (minor units)", type: "number" },
        { path: "discount_total", label: "Discount total (minor units)", type: "number" },
        { path: "payment_status", label: "Payment status", type: "string" },
        { path: "fulfillment_status", label: "Fulfillment status", type: "string" },
        { path: "customer.id", label: "Customer id", type: "id" },
        { path: "shipping_address.address_1", label: "Shipping address line 1", type: "string" },
        { path: "shipping_address.city", label: "Shipping city", type: "string" },
        { path: "shipping_address.country_code", label: "Shipping country (ISO)", type: "string", suggested_transform: "uppercase" },
        { path: "items", label: "Line items (array)", type: "array", suggested_transform: "json" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
        // Which channel the order arrived through. ERPNext keeps this on
        // Sales Order so the storefront can say "placed online" or "placed
        // by our sales team" instead of guessing from the order alone.
        { path: "source", label: "Order source (sales channel)", type: "string" },
        { path: "sales_channel_id", label: "Sales channel id", type: "id" },
    ],
    async fetchById(container, id) {
        // Use query.graph (RemoteQuery), NOT orderModule.listOrders with deep
        // relations: the order module's list throws ('kind'/'targetMeta') or
        // returns degraded rows for cross-module relations
        // (items.variant.product, addresses, payment_collections). query.graph
        // resolves the module links properly.
        // Computed ORDER-level totals (total/tax_total) via query.graph throw
        // "Shipping method version is required to load adjustments" on orders
        // with shipping methods. So take the grand total from `summary`
        // (stored, no computation) and line-level totals from the items — both
        // fetch cleanly. The augment derives tax/shipping/discount from these.
        const query = container.resolve("query");
        const { data } = await query.graph({
            entity: "order",
            fields: [
                "id",
                "display_id",
                "email",
                "customer_id",
                "currency_code",
                "payment_status",
                "fulfillment_status",
                "created_at",
                "shipping_total",
                "shipping_subtotal",
                "shipping_tax_total",
                "discount_total",
                "summary.*",
                "items.id",
                "items.title",
                // In Medusa v2 the order line QUANTITY lives on the item
                // DETAIL (order_item), not the line item — `items.quantity`
                // resolves to null. Fetch `items.detail.quantity` and flatten
                // it below so the augment reads the real qty (a null qty was
                // silently defaulting to 1 and corrupting Sales Order lines).
                "items.detail.quantity",
                "items.quantity",
                "items.unit_price",
                "items.total",
                "items.tax_total",
                "items.adjustments.amount",
                "items.tax_lines.rate",
                "items.variant.id",
                "items.variant.sku",
                "items.variant.product.id",
                "items.variant.product.handle",
                "items.variant.product.title",
                "shipping_address.*",
                "billing_address.*",
                "payment_collections.id",
                "payment_collections.status",
                "sales_channel_id",
                "sales_channel.name",
            ],
            filters: { id },
        });
        const order = data?.[0];
        if (!order)
            return null;
        // Flatten the real line quantity (from the item detail) onto each item
        // so downstream (augmentSalesDocPayload) reads the correct qty. Without
        // this, `items.quantity` is null and the SO line silently became qty 1.
        for (const it of order.items || []) {
            const q = it?.detail?.quantity;
            if (q != null)
                it.quantity = q;
        }
        // Flatten the stored grand total onto the record for the augment.
        order.total =
            order.summary?.current_order_total ??
                order.summary?.original_order_total ??
                0;
        // Flatten the channel to a name a mapping can carry straight into
        // the order's source. A store with no channels at all still came
        // from the web, which is truer than an empty string.
        order.source = order.sales_channel?.name || "web";
        const payments = await orderPayments(query, order.payment_collections);
        order.payments = payments.captured;
        order.payment_providers = payments.providers;
        return order;
    },
    async upsertByKey() {
        return { ok: false, error: "order upsert from ERPNext not supported (Sales Invoices are generated FROM Medusa orders)" };
    },
};
const productEntity = {
    key: "product",
    label: "Product",
    moduleName: utils_1.Modules.PRODUCT,
    modelName: "Product",
    isCustomModule: false,
    events: ["product.created", "product.updated", "product.deleted"],
    // Every Medusa product has a handle, and upsertByKey has the careful
    // path for it — keeps the row published and its SKU in step. A store
    // that identifies products by something of its own points the mapping
    // at that instead; this is only what the picker suggests first.
    default_key_path: "handle",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "title", label: "Title", type: "string" },
        { path: "handle", label: "Handle (URL slug)", type: "string" },
        { path: "subtitle", label: "Subtitle", type: "string" },
        { path: "description", label: "Description", type: "string" },
        { path: "status", label: "Status (draft/published)", type: "string" },
        { path: "thumbnail", label: "Thumbnail URL", type: "string" },
        { path: "external_id", label: "External id", type: "string" },
        // A store's own metadata keys are reached by typing the path;
        // listing anybody's here would only be a guess about their
        // catalogue. The whole blob is offered for a wholesale copy.
        { path: "metadata", label: "Whole metadata blob", type: "json", suggested_transform: "json" },
        { path: "variants.0.sku", label: "First variant SKU", type: "string" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
        { path: "updated_at", label: "Updated at", type: "datetime", suggested_transform: "date_iso" },
    ],
    async fetchById(container, id) {
        const m = container.resolve(utils_1.Modules.PRODUCT);
        const [row] = await m.listProducts({ id }, { take: 1, relations: ["variants"], withDeleted: true });
        return row ?? null;
    },
    options: {
        status: async () => ["draft", "proposed", "published", "rejected"].map((v) => ({ value: v, label: v })),
        sales_channels: async (container) => {
            const sc = container.resolve(utils_1.Modules.SALES_CHANNEL);
            const rows = await sc.listSalesChannels({}, { take: 200, select: ["id", "name"] });
            return (rows ?? []).map((r) => ({ value: r.id, label: r.name ?? r.id }));
        },
        shipping_profile_id: async (container) => {
            const f = container.resolve(utils_1.Modules.FULFILLMENT);
            const rows = await f.listShippingProfiles({}, { take: 200, select: ["id", "name"] });
            return (rows ?? []).map((r) => ({ value: r.id, label: r.name ?? r.id }));
        },
        collection_id: async (container) => {
            const m = container.resolve(utils_1.Modules.PRODUCT);
            const rows = await m.listProductCollections({}, { take: 200, select: ["id", "title", "handle"] });
            return (rows ?? []).map((r) => ({ value: r.id, label: r.title ?? r.handle ?? r.id }));
        },
        type_id: async (container) => {
            const m = container.resolve(utils_1.Modules.PRODUCT);
            const rows = await m.listProductTypes({}, { take: 200, select: ["id", "value"] });
            return (rows ?? []).map((r) => ({ value: r.id, label: r.value ?? r.id }));
        },
    },
    async upsertByKey(container, key_field, key_value, payload) {
        const m = container.resolve(utils_1.Modules.PRODUCT);
        // Sales channels and the shipping profile are relations the product
        // module does not write; they are linked after the upsert.
        const salesChannels = payload.sales_channels;
        const shippingProfile = payload.shipping_profile_id;
        if (salesChannels !== undefined || shippingProfile !== undefined) {
            payload = { ...payload };
            delete payload.sales_channels;
            delete payload.shipping_profile_id;
        }
        const outcome = await upsertProductRecord(m, key_field, key_value, payload);
        if (outcome.ok && outcome.id) {
            await linkProductRelations(container, outcome.id, { salesChannels, shippingProfile });
        }
        return outcome;
    },
    // Safe inbound delete: unpublish (status → draft) rather than destroy.
    async disableByKey(container, key_field, key_value) {
        const m = container.resolve(utils_1.Modules.PRODUCT);
        const isMetaKey = key_field.startsWith("metadata.");
        const filter = isMetaKey
            ? { metadata: { [key_field.slice("metadata.".length)]: key_value } }
            : { [key_field]: key_value };
        const [existing] = await m.listProducts(filter, { select: ["id"], take: 1 });
        if (!existing)
            return { ok: true, skipped: true, action: "absent" };
        await m.upsertProducts([{ id: existing.id, status: "draft" }]);
        return { ok: true, id: existing.id, action: "unpublished" };
    },
};
/**
 * Put a pulled product in its sales channels and on its shipping profile.
 * Values are ids, or names the operator picked from the value picker.
 * Sales channels are added, never removed; the shipping profile is
 * replaced. Never throws: the product is already written, and a missing
 * channel is a warning, not a lost product.
 */
async function linkProductRelations(container, productId, rel) {
    let link;
    let query;
    try {
        link = container.resolve(utils_1.ContainerRegistrationKeys.LINK);
        query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    }
    catch {
        return;
    }
    try {
        const wanted = Array.isArray(rel.salesChannels)
            ? rel.salesChannels
            : typeof rel.salesChannels === "string"
                ? rel.salesChannels.split(",")
                : [];
        const channelIds = [];
        if (wanted.length) {
            const sc = container.resolve(utils_1.Modules.SALES_CHANNEL);
            const all = (await sc.listSalesChannels({}, { take: 500, select: ["id", "name"] })) ?? [];
            for (const w of wanted) {
                const needle = String(w ?? "").trim();
                if (!needle)
                    continue;
                const hit = all.find((c) => c.id === needle || c.name === needle);
                if (hit)
                    channelIds.push(hit.id);
                else
                    console.warn(`[erpnext] sales channel "${needle}" not found for product ${productId}`);
            }
        }
        const profileWanted = rel.shippingProfile != null ? String(rel.shippingProfile).trim() : "";
        let profileId = null;
        if (profileWanted) {
            const f = container.resolve(utils_1.Modules.FULFILLMENT);
            const all = (await f.listShippingProfiles({}, { take: 500, select: ["id", "name"] })) ?? [];
            const hit = all.find((p) => p.id === profileWanted || p.name === profileWanted);
            if (hit)
                profileId = hit.id;
            else
                console.warn(`[erpnext] shipping profile "${profileWanted}" not found for product ${productId}`);
        }
        if (!channelIds.length && !profileId)
            return;
        const { data } = await query.graph({
            entity: "product",
            fields: ["id", "sales_channels.id", "shipping_profile.id"],
            filters: { id: productId },
        });
        const current = data?.[0] ?? {};
        const have = new Set((current.sales_channels ?? []).map((c) => c.id));
        const creates = [];
        for (const id of channelIds) {
            if (!have.has(id)) {
                creates.push({ [utils_1.Modules.PRODUCT]: { product_id: productId }, [utils_1.Modules.SALES_CHANNEL]: { sales_channel_id: id } });
            }
        }
        if (profileId && current.shipping_profile?.id !== profileId) {
            if (current.shipping_profile?.id) {
                await link.dismiss({
                    [utils_1.Modules.PRODUCT]: { product_id: productId },
                    [utils_1.Modules.FULFILLMENT]: { shipping_profile_id: current.shipping_profile.id },
                });
            }
            creates.push({ [utils_1.Modules.PRODUCT]: { product_id: productId }, [utils_1.Modules.FULFILLMENT]: { shipping_profile_id: profileId } });
        }
        if (creates.length)
            await link.create(creates);
    }
    catch (err) {
        console.warn(`[erpnext] relations for product ${productId} not linked:`, err?.message ?? err);
    }
}
/** The product upsert proper: match by key, keep it sellable, write. */
async function upsertProductRecord(m, key_field, key_value, payload) {
    {
        const isMetaKey = key_field.startsWith("metadata.");
        const metaKeyName = isMetaKey ? key_field.slice("metadata.".length) : null;
        // An ERP item code is rarely URL-safe, and Medusa rejects a handle
        // that is not. Derive one, and match on the derived value so the
        // same item finds its own product next time. The exact code still
        // travels, as the variant SKU.
        const handleKey = key_field === "handle" ? handleFromKey(String(key_value)) : null;
        const filter = {};
        if (isMetaKey) {
            filter.metadata = { [metaKeyName]: key_value };
        }
        else if (handleKey) {
            filter.handle = handleKey;
        }
        else {
            filter[key_field] = key_value;
        }
        if (handleKey)
            payload = { ...payload, handle: handleKey };
        // A title carrying editor markup or a hard line break renders as
        // neither on a storefront; the ERP field it comes from routinely
        // has both.
        if (typeof payload.title === "string") {
            payload = { ...payload, title: titleFromText(payload.title) };
        }
        if (typeof payload.description === "string") {
            payload = { ...payload, description: titleFromText(payload.description) };
        }
        // When deduping on a metadata path, GUARANTEE the persisted row
        // carries the key. A pull whose field_mappings don't project the
        // key into its payload (a metadata key that is push-only on the
        // mapping) would otherwise create a fresh row every run — the
        // dedup filter never matches what was written.
        const keyMeta = isMetaKey ? { [metaKeyName]: key_value } : {};
        const existing = await m.listProducts(filter, { select: ["id", "metadata"], take: 1 });
        if (existing?.length) {
            const mergedMeta = { ...(existing[0].metadata || {}), ...(payload.metadata || {}), ...keyMeta };
            const patch = { id: existing[0].id, ...payload, metadata: mergedMeta };
            // Never rename an existing product's handle when the dedup
            // key is something else: the product lives under a human slug
            // and a pull that also maps handle←key would clobber its
            // storefront URL.
            if (key_field !== "handle")
                delete patch.handle;
            // Catalog products (keyed by handle) must stay sellable — keep them
            // published and ensure a variant whose sku == handle exists (a
            // product synced before this fix, or a pull that dropped variants,
            // would otherwise be a variant-less draft that can't be sold or
            // stock-matched).
            if (key_field === "handle") {
                if (patch.status === undefined)
                    patch.status = "published";
                const [full] = await m.listProducts({ id: existing[0].id }, { take: 1, relations: ["variants"] });
                const hasSku = (full?.variants || []).some((v) => v.sku === String(key_value));
                if (!hasSku) {
                    patch.options = [{ title: "Default", values: ["Default"] }];
                    patch.variants = [
                        {
                            title: "Default",
                            sku: String(key_value),
                            manage_inventory: true,
                            options: { Default: "Default" },
                        },
                    ];
                }
            }
            const [updated] = await m.upsertProducts([patch]);
            return { ok: true, id: updated.id, created: false };
        }
        const createPayload = isMetaKey
            ? { ...payload, metadata: { ...(payload.metadata || {}), ...keyMeta } }
            : { ...payload };
        // A catalogue product is a sellable simple product whatever it is
        // keyed by: one "Default" option, one variant carrying the key as its
        // SKU, and published. Keyed by a metadata path — an ERP part number,
        // say — it would otherwise land as a variant-less draft that cannot
        // be sold and that inventory, which matches on SKU, cannot find.
        if (isMetaKey) {
            if (createPayload.status === undefined)
                createPayload.status = "published";
            createPayload.options = createPayload.options ?? [
                { title: "Default", values: ["Default"] },
            ];
            createPayload.variants = createPayload.variants ?? [
                {
                    title: "Default",
                    sku: String(key_value),
                    manage_inventory: true,
                    options: { Default: "Default" },
                },
            ];
            // Medusa derives the handle from the title and requires it
            // unique, but two ERP records routinely share a description —
            // two fuel-water separators for different engines are both
            // the same "VALVE,RELIEF". The second one is refused outright, so
            // the key it is already unique by is folded in.
            if (!createPayload.handle && typeof createPayload.title === "string") {
                const base = handleFromKey(createPayload.title);
                const taken = base
                    ? await m.listProducts({ handle: base }, { select: ["id"], take: 1 })
                    : [];
                createPayload.handle =
                    !base || taken?.length ? `${base ? base + "-" : ""}${handleFromKey(String(key_value))}` : base;
            }
        }
        if (!isMetaKey && key_field === "handle") {
            if (createPayload.status === undefined)
                createPayload.status = "published";
            createPayload.options = createPayload.options ?? [
                { title: "Default", values: ["Default"] },
            ];
            createPayload.variants = createPayload.variants ?? [
                {
                    title: "Default",
                    sku: String(key_value),
                    manage_inventory: true,
                    options: { Default: "Default" },
                },
            ];
        }
        const [created] = await m.upsertProducts([createPayload]);
        return { ok: true, id: created.id, created: true };
    }
}
const productCategoryEntity = genericEntity({
    key: "product_category",
    label: "Product category",
    moduleName: utils_1.Modules.PRODUCT,
    modelName: "ProductCategory",
    methodSuffix: "ProductCategories",
    events: ["product-category.created", "product-category.updated", "product-category.deleted"],
    default_key_path: "handle",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "name", label: "Name", type: "string" },
        { path: "handle", label: "Handle", type: "string" },
        { path: "description", label: "Description", type: "string" },
        { path: "is_active", label: "Active", type: "boolean" },
        { path: "is_internal", label: "Internal-only", type: "boolean" },
        { path: "parent_category_id", label: "Parent category id", type: "id" },
    ],
});
const productCollectionEntity = genericEntity({
    key: "product_collection",
    label: "Product collection",
    moduleName: utils_1.Modules.PRODUCT,
    modelName: "ProductCollection",
    events: ["product-collection.created", "product-collection.updated"],
    default_key_path: "handle",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "title", label: "Title", type: "string" },
        { path: "handle", label: "Handle", type: "string" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const userEntity = genericEntity({
    key: "user",
    label: "User (Medusa admin)",
    moduleName: utils_1.Modules.USER,
    modelName: "User",
    events: ["user.created", "user.updated", "user.deleted"],
    default_key_path: "email",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "email", label: "Email", type: "string", suggested_transform: "lowercase" },
        { path: "first_name", label: "First name", type: "string" },
        { path: "last_name", label: "Last name", type: "string" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
    ],
    upsertByKey: async () => ({ ok: false, error: "admin user pull from ERPNext not supported in v1" }),
});
const cartEntity = genericEntity({
    key: "cart",
    label: "Cart",
    moduleName: utils_1.Modules.CART,
    modelName: "Cart",
    events: ["cart.created", "cart.updated"],
    default_key_path: "id",
    fetchRelations: ["items", "shipping_address", "billing_address"],
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "email", label: "Email", type: "string", suggested_transform: "lowercase" },
        { path: "currency_code", label: "Currency", type: "string", suggested_transform: "uppercase" },
        { path: "region_id", label: "Region id", type: "id" },
        { path: "customer_id", label: "Customer id", type: "id" },
        { path: "sales_channel_id", label: "Sales channel id", type: "id" },
        { path: "items", label: "Line items", type: "array", suggested_transform: "json" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
        { path: "completed_at", label: "Completed at", type: "datetime", suggested_transform: "date_iso" },
        { path: "created_at", label: "Created at", type: "datetime", suggested_transform: "date_iso" },
    ],
    upsertByKey: async () => ({ ok: false, error: "cart upsert from ERPNext not supported (carts are storefront-owned)" }),
});
const regionEntity = genericEntity({
    key: "region",
    label: "Region",
    moduleName: utils_1.Modules.REGION,
    modelName: "Region",
    events: ["region.created", "region.updated", "region.deleted"],
    default_key_path: "name",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "name", label: "Name", type: "string" },
        { path: "currency_code", label: "Currency", type: "string", suggested_transform: "uppercase" },
        { path: "automatic_taxes", label: "Automatic taxes", type: "boolean" },
        { path: "countries", label: "Countries", type: "array", suggested_transform: "json" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const salesChannelEntity = genericEntity({
    key: "sales_channel",
    label: "Sales channel",
    moduleName: utils_1.Modules.SALES_CHANNEL,
    modelName: "SalesChannel",
    events: ["sales-channel.created", "sales-channel.updated"],
    default_key_path: "name",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "name", label: "Name", type: "string" },
        { path: "description", label: "Description", type: "string" },
        { path: "is_disabled", label: "Disabled", type: "boolean" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const promotionEntity = genericEntity({
    key: "promotion",
    label: "Promotion",
    moduleName: utils_1.Modules.PROMOTION,
    modelName: "Promotion",
    events: ["promotion.created", "promotion.updated", "promotion.deleted"],
    default_key_path: "code",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "code", label: "Code", type: "string", suggested_transform: "uppercase" },
        { path: "is_automatic", label: "Automatic", type: "boolean" },
        { path: "type", label: "Type (standard / buyget)", type: "string" },
        { path: "campaign_id", label: "Campaign id", type: "id" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const stockLocationEntity = genericEntity({
    key: "stock_location",
    label: "Stock location",
    moduleName: utils_1.Modules.STOCK_LOCATION,
    modelName: "StockLocation",
    events: ["stock-location.created", "stock-location.updated"],
    default_key_path: "name",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "name", label: "Name", type: "string" },
        { path: "address.address_1", label: "Address line 1", type: "string" },
        { path: "address.city", label: "City", type: "string" },
        { path: "address.country_code", label: "Country (ISO)", type: "string", suggested_transform: "uppercase" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const inventoryItemEntity = genericEntity({
    key: "inventory_item",
    label: "Inventory item",
    moduleName: utils_1.Modules.INVENTORY,
    modelName: "InventoryItem",
    events: ["inventory-item.created", "inventory-item.updated"],
    default_key_path: "sku",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "sku", label: "SKU", type: "string" },
        { path: "title", label: "Title", type: "string" },
        { path: "description", label: "Description", type: "string" },
        { path: "weight", label: "Weight", type: "number" },
        { path: "hs_code", label: "HS code", type: "string" },
        { path: "origin_country", label: "Origin country (ISO)", type: "string", suggested_transform: "uppercase" },
        { path: "material", label: "Material", type: "string" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
const currencyEntity = genericEntity({
    key: "currency",
    label: "Currency",
    moduleName: utils_1.Modules.CURRENCY,
    modelName: "Currency",
    events: ["currency.created", "currency.updated"],
    default_key_path: "code",
    paths: [
        { path: "code", label: "Code (ISO 4217)", type: "string", suggested_transform: "uppercase" },
        { path: "symbol", label: "Symbol", type: "string" },
        { path: "symbol_native", label: "Symbol (native)", type: "string" },
        { path: "name", label: "Name", type: "string" },
    ],
    upsertByKey: async () => ({ ok: false, error: "currencies are Medusa-seeded; ERPNext-driven inserts not supported" }),
});
const apiKeyEntity = genericEntity({
    key: "api_key",
    label: "API key",
    moduleName: utils_1.Modules.API_KEY,
    modelName: "ApiKey",
    events: ["api-key.created", "api-key.updated", "api-key.deleted"],
    default_key_path: "title",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "title", label: "Title", type: "string" },
        { path: "type", label: "Type (publishable / secret)", type: "string" },
        { path: "redacted", label: "Redacted preview", type: "string" },
    ],
    upsertByKey: async () => ({ ok: false, error: "API keys must be created in Medusa admin, not synced from ERPNext" }),
});
const paymentCollectionEntity = genericEntity({
    key: "payment_collection",
    label: "Payment collection",
    moduleName: utils_1.Modules.PAYMENT,
    modelName: "PaymentCollection",
    events: ["payment-collection.created", "payment-collection.updated"],
    default_key_path: "id",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "amount", label: "Amount (minor units)", type: "number" },
        { path: "currency_code", label: "Currency", type: "string", suggested_transform: "uppercase" },
        { path: "status", label: "Status", type: "string" },
    ],
    upsertByKey: async () => ({ ok: false, error: "payment collections are storefront-owned; ERPNext-driven inserts not supported" }),
});
const fulfillmentEntity = genericEntity({
    key: "fulfillment",
    label: "Fulfillment",
    moduleName: utils_1.Modules.FULFILLMENT,
    modelName: "Fulfillment",
    events: ["fulfillment.created", "fulfillment.shipment_created", "fulfillment.canceled"],
    default_key_path: "id",
    paths: [
        { path: "id", label: "Medusa id", type: "id" },
        { path: "location_id", label: "Stock location id", type: "id" },
        { path: "shipped_at", label: "Shipped at", type: "datetime", suggested_transform: "date_iso" },
        { path: "delivered_at", label: "Delivered at", type: "datetime", suggested_transform: "date_iso" },
        { path: "canceled_at", label: "Canceled at", type: "datetime", suggested_transform: "date_iso" },
        { path: "metadata", label: "Metadata", type: "json", suggested_transform: "json" },
    ],
});
// ─── Registry ─────────────────────────────────────────────────────────
const REGISTRY = {
    // Built-in Medusa modules (always available)
    customer: customerEntity,
    customer_group: customerGroupEntity,
    order: orderEntity,
    product: productEntity,
    product_category: productCategoryEntity,
    product_collection: productCollectionEntity,
    user: userEntity,
    cart: cartEntity,
    region: regionEntity,
    sales_channel: salesChannelEntity,
    promotion: promotionEntity,
    stock_location: stockLocationEntity,
    inventory_item: inventoryItemEntity,
    currency: currencyEntity,
    api_key: apiKeyEntity,
    payment_collection: paymentCollectionEntity,
    fulfillment: fulfillmentEntity,
    // No wallet_settlement entry, deliberately. Both ends of it are gone
    // — the Medusa module was a sandbox demo and the ERPNext doctype
    // belonged to a custom app that was uninstalled — so offering it in
    // the picker only let an operator build a mapping that could never
    // succeed. The wallet contract this connector wants is in
    // pending_work, waiting on the applications being written for it.
};
/**
 * Resolve whether one entity is actually usable in this Medusa
 * process. For built-in modules the check is trivial (core modules
 * are always wired). For custom modules we try `container.resolve()`
 * — if the module isn't registered in medusa-config.ts the resolve
 * throws and the entity is hidden from the picker.
 */
function isEntityAvailable(entity, container) {
    if (entity.availableInContainer) {
        try {
            return entity.availableInContainer(container);
        }
        catch {
            return false;
        }
    }
    if (!entity.isCustomModule) {
        // Built-in modules — Medusa wires them universally.
        return true;
    }
    try {
        const resolved = container.resolve(entity.moduleName);
        return Boolean(resolved);
    }
    catch {
        return false;
    }
}
function listMedusaEntities(container) {
    const all = Object.values(REGISTRY);
    if (!container)
        return all;
    return all.filter((e) => isEntityAvailable(e, container));
}
function getMedusaEntity(key) {
    return REGISTRY[key] ?? null;
}
//# sourceMappingURL=registry.js.map