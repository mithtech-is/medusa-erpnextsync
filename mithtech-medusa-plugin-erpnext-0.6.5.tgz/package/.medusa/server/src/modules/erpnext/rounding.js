"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUNDING_REFERENCE = void 0;
exports.planCartRounding = planCartRounding;
const erpnext_arithmetic_1 = require("./erpnext-arithmetic");
const push_rest_1 = require("./push-rest");
/**
 * The store's total, rounded the way ERPNext will round the invoice.
 *
 * ERPNext rounds a sales document's grand total to the rupee and the
 * customer owes the rounded figure. The store charges the same by keeping
 * one cart credit line, reference `erpnext-rounding`, worth the difference
 * between Medusa's total and ERPNext's rounded total (negative when
 * ERPNext rounds up). The figure comes from ERPNext's own arithmetic over
 * the lines the push will send, so it also absorbs a paisa Medusa's own
 * tax sum may differ by.
 */
exports.ROUNDING_REFERENCE = "erpnext-rounding";
/** More than this between Medusa's total and ERPNext's means the two
 *  disagree on something real (a rate not synced yet); rounding must not
 *  paper over it, and the cart goes unrounded. */
const MAX_GAP = 1;
function sum(rows, pick) {
    return (Array.isArray(rows) ? rows : []).reduce((s, r) => s + (0, push_rest_1.money)(pick(r)), 0);
}
/**
 * What the rounding line should be for a cart. `companyState` is the
 * seller's two-digit GST state; the supply's state is the billing
 * address's, else the shipping address's, as India Compliance reads it.
 */
function planCartRounding(args) {
    const cart = args.cart ?? {};
    const items = Array.isArray(cart.items) ? cart.items : [];
    if (!args.roundTotal)
        return { action: "clear", reason: "ERPNext does not round" };
    if (!items.length)
        return { action: "clear", reason: "empty cart" };
    const currency = String(cart.currency_code ?? "").toLowerCase();
    if (args.companyCurrency && currency !== String(args.companyCurrency).toLowerCase()) {
        return { action: "clear", reason: `cart in ${currency}, company books ${args.companyCurrency}` };
    }
    if (items.some((li) => li?.is_tax_inclusive))
        return { action: "clear", reason: "tax-inclusive prices are not estimated" };
    if (!cart.shipping_address)
        return { action: "clear", reason: "no address yet, so no tax yet" };
    if (items.some((li) => !(Array.isArray(li?.tax_lines) && li.tax_lines.length))) {
        return { action: "clear", reason: "a line has no tax yet" };
    }
    const lines = items.map((li) => {
        const l = (0, push_rest_1.salesLine)(li);
        return { rate: l.rate, qty: l.qty, gstRate: sum(li.tax_lines, (t) => t?.rate) };
    });
    const shipping = sum(cart.shipping_methods, (m) => m?.amount) - sum((cart.shipping_methods ?? []).flatMap((m) => m?.adjustments ?? []), (a) => a?.amount);
    const supply = (0, push_rest_1.gstStateCodeOf)(cart.billing_address?.province) ?? (0, push_rest_1.gstStateCodeOf)(cart.shipping_address?.province) ?? null;
    const interState = Boolean(supply && args.companyState && supply !== args.companyState);
    const estimate = (0, erpnext_arithmetic_1.estimateSalesTotals)({ lines, shipping: (0, erpnext_arithmetic_1.frappeRound)(shipping, 2), interState, roundTotal: true, rounding: args.rounding });
    // The goods, shipping and GST before any credit line: other credit
    // lines (a gift card, a wallet) are payments ERPNext's grand total does
    // not know, and they come off the rounded total unchanged.
    const credits = sum(cart.credit_lines, (c) => c?.amount);
    const before = Number(cart.total ?? 0) + credits;
    if (Math.abs(before - estimate.grandTotal) > MAX_GAP) {
        return {
            action: "clear",
            reason: `store total ${(0, erpnext_arithmetic_1.frappeRound)(before, 2)} and ERPNext's ${estimate.grandTotal} differ by more than ${MAX_GAP}`,
        };
    }
    // Not rounded to the paisa: a shipping share's tax can leave Medusa's
    // total a fraction of a paisa off, and the line must take that too.
    return { action: "set", amount: Number((before - estimate.payable).toFixed(9)), estimate, interState };
}
//# sourceMappingURL=rounding.js.map