"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeSecondaryDoctypes = normalizeSecondaryDoctypes;
exports.doctypeOfPair = doctypeOfPair;
exports.pairsForDoctype = pairsForDoctype;
exports.splitPairsByDoctype = splitPairsByDoctype;
exports.pairsForPull = pairsForPull;
exports.secondaryLookupFilters = secondaryLookupFilters;
exports.secondaryLinkPayload = secondaryLinkPayload;
exports.mainNameFromSecondaryDoc = mainNameFromSecondaryDoc;
exports.linkFieldFilled = linkFieldFilled;
function normalizeSecondaryDoctypes(raw, mainDoctype) {
    if (!Array.isArray(raw))
        return [];
    const main = String(mainDoctype ?? "").trim();
    const out = [];
    const seen = new Set();
    for (const r of raw) {
        const doctype = String(r?.doctype ?? "").trim();
        if (!doctype || doctype === main || seen.has(doctype))
            continue;
        const kind = String(r?.link_kind ?? "").toLowerCase() === "dynamic_links" ? "dynamic_links" : "field";
        const link_field = String(r?.link_field ?? "").trim();
        if (kind === "field" && !link_field)
            continue;
        seen.add(doctype);
        out.push({ doctype, link_kind: kind, link_field: kind === "field" ? link_field : null });
    }
    return out;
}
/** The DocType a pair targets. */
function doctypeOfPair(pair, main) {
    const dt = String(pair?.erpnext_doctype ?? "").trim();
    return dt || main;
}
function pairsForDoctype(pairs, main, doctype) {
    return (pairs ?? []).filter((p) => doctypeOfPair(p, main) === doctype);
}
/** Pairs grouped by the DocType they target; the main one first. */
function splitPairsByDoctype(pairs, main) {
    const out = new Map([[main, []]]);
    for (const p of pairs ?? []) {
        const dt = doctypeOfPair(p, main);
        if (!out.has(dt))
            out.set(dt, []);
        out.get(dt).push(p);
    }
    return out;
}
/**
 * The pairs as the pull reads them: a secondary pair's ERPNext side
 * becomes a dot path into the linked document laid under the main one
 * (`Contact.first_name`). A pair with no ERPNext field is left alone.
 */
function pairsForPull(pairs, main) {
    return (pairs ?? []).map((p) => {
        const dt = doctypeOfPair(p, main);
        if (dt === main || !p.erpnext_field)
            return p;
        const { erpnext_doctype: _dt, ...rest } = p;
        return { ...rest, erpnext_field: `${dt}.${p.erpnext_field}` };
    });
}
/** Frappe list filters that find the secondary document tied to the main one. */
function secondaryLookupFilters(sec, mainDoctype, mainName) {
    if (sec.link_kind === "dynamic_links") {
        return [
            ["Dynamic Link", "link_doctype", "=", mainDoctype],
            ["Dynamic Link", "link_name", "=", mainName],
        ];
    }
    return [[String(sec.link_field), "=", mainName]];
}
/** What a new secondary document carries so ERPNext ties it to the main one. */
function secondaryLinkPayload(sec, mainDoctype, mainName) {
    if (sec.link_kind === "dynamic_links") {
        return { links: [{ link_doctype: mainDoctype, link_name: mainName }] };
    }
    return { [String(sec.link_field)]: mainName };
}
/** The main document a secondary document points at, from its own fields. */
function mainNameFromSecondaryDoc(sec, mainDoctype, doc) {
    if (sec.link_kind === "dynamic_links") {
        const rows = Array.isArray(doc?.links) ? doc.links : [];
        const hit = rows.find((r) => String(r?.link_doctype ?? "") === mainDoctype && r?.link_name);
        return hit ? String(hit.link_name) : null;
    }
    const v = doc?.[String(sec.link_field)];
    return v == null || v === "" ? null : String(v);
}
/** The field the plugin fills on a secondary document to tie it to the main one. */
function linkFieldFilled(sec) {
    return sec.link_kind === "dynamic_links" ? "links" : String(sec.link_field);
}
//# sourceMappingURL=secondary-doctypes.js.map