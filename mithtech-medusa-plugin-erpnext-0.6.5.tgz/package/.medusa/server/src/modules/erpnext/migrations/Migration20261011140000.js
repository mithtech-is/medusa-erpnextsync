"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20261011140000 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/** Whether gateway settlements are booked, into which bank account, and from which supplier. */
class Migration20261011140000 extends migrations_1.Migration {
    async up() {
        this.addSql(`ALTER TABLE "erpnext_setting" ADD COLUMN IF NOT EXISTS "book_settlements" boolean NOT NULL DEFAULT false;`);
        this.addSql(`ALTER TABLE "erpnext_setting" ADD COLUMN IF NOT EXISTS "settlement_bank_account" text NULL;`);
        this.addSql(`ALTER TABLE "erpnext_setting" ADD COLUMN IF NOT EXISTS "create_settlement_bank_account" boolean NOT NULL DEFAULT false;`);
        this.addSql(`ALTER TABLE "erpnext_setting" ADD COLUMN IF NOT EXISTS "gateway_suppliers" jsonb NULL;`);
    }
    async down() {
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "gateway_suppliers";`);
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "create_settlement_bank_account";`);
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "settlement_bank_account";`);
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "book_settlements";`);
    }
}
exports.Migration20261011140000 = Migration20261011140000;
//# sourceMappingURL=Migration20261011140000.js.map