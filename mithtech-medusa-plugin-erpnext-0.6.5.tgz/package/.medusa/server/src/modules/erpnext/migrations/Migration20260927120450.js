"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260927120450 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/** A sync may span several DocTypes: the secondary ones and their links. */
class Migration20260927120450 extends migrations_1.Migration {
    async up() {
        this.addSql(`ALTER TABLE "erpnext_mapping" ADD COLUMN IF NOT EXISTS "secondary_doctypes" jsonb NULL;`);
    }
    async down() {
        this.addSql(`ALTER TABLE "erpnext_mapping" DROP COLUMN IF EXISTS "secondary_doctypes";`);
    }
}
exports.Migration20260927120450 = Migration20260927120450;
//# sourceMappingURL=Migration20260927120450.js.map