"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260812114233 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/**
 * `erpnext_setting.push_allowlist` — outbound safety valve.
 *
 * Additive and nullable, so existing deployments keep their current
 * behaviour: NULL / empty means "no restriction", which is what every
 * row has the moment this runs.
 *
 * Purpose: pointing a production Medusa at a non-production ERPNext is
 * a normal step while integrating, but without a valve it streams every
 * customer's personal data onto that box. This column lets an operator
 * say "push only these records" without switching sync off entirely.
 *
 * NB the class name is deliberately NOT a round timestamp. There is one
 * shared `mikro_orm_migrations` table across every module and mikro-orm
 * tracks by CLASS NAME, so two modules that both pick e.g.
 * Migration20260812110000 collide and one is silently skipped while
 * `db:migrate` still reports success.
 */
class Migration20260812114233 extends migrations_1.Migration {
    async up() {
        this.addSql(`
            ALTER TABLE "erpnext_setting"
                ADD COLUMN IF NOT EXISTS "push_allowlist" TEXT NULL;
        `);
    }
    async down() {
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "push_allowlist";`);
    }
}
exports.Migration20260812114233 = Migration20260812114233;
//# sourceMappingURL=Migration20260812114233.js.map