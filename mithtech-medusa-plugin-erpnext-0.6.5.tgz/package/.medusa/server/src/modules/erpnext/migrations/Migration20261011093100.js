"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20261011093100 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/** Which ERPNext Mode of Payment each Medusa payment provider books to. */
class Migration20261011093100 extends migrations_1.Migration {
    async up() {
        this.addSql(`ALTER TABLE "erpnext_setting" ADD COLUMN IF NOT EXISTS "payment_modes" jsonb NULL;`);
    }
    async down() {
        this.addSql(`ALTER TABLE "erpnext_setting" DROP COLUMN IF EXISTS "payment_modes";`);
    }
}
exports.Migration20261011093100 = Migration20261011093100;
//# sourceMappingURL=Migration20261011093100.js.map