"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20261011093000 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/** The pull watermark keeps Frappe's `modified` exactly, microseconds included. */
class Migration20261011093000 extends migrations_1.Migration {
    async up() {
        this.addSql(`ALTER TABLE "erpnext_mapping" ADD COLUMN IF NOT EXISTS "last_pull_modified" text NULL;`);
    }
    async down() {
        this.addSql(`ALTER TABLE "erpnext_mapping" DROP COLUMN IF EXISTS "last_pull_modified";`);
    }
}
exports.Migration20261011093000 = Migration20261011093000;
//# sourceMappingURL=Migration20261011093000.js.map