"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260824000000 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/**
 * Configurable Frappe receive method.
 *
 * Additive nullable column on the `erpnext_setting` singleton. NULL
 * means "use ERPNEXT_RECEIVE_METHOD env, else the built-in default
 * (`medusync.api.receive`)", so existing rows keep pushing to the same
 * endpoint they did before. Set it per deployment to point the plugin
 * at whatever whitelisted method the target Frappe app exposes.
 */
class Migration20260824000000 extends migrations_1.Migration {
    async up() {
        this.addSql(`
            ALTER TABLE "erpnext_setting"
                ADD COLUMN IF NOT EXISTS "frappe_receive_method" TEXT NULL;
        `);
    }
    async down() {
        this.addSql(`
            ALTER TABLE "erpnext_setting"
                DROP COLUMN IF EXISTS "frappe_receive_method";
        `);
    }
}
exports.Migration20260824000000 = Migration20260824000000;
//# sourceMappingURL=Migration20260824000000.js.map