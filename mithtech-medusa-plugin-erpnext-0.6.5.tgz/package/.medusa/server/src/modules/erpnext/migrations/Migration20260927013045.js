"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260927013045 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
/**
 * Phase 3: stock and prices, ERPNext → Medusa. Both off until switched
 * on in Settings; the warehouse and stock location name where levels
 * come from and go to.
 */
class Migration20260927013045 extends migrations_1.Migration {
    async up() {
        this.addSql(`
            ALTER TABLE "erpnext_setting"
                ADD COLUMN IF NOT EXISTS "sync_stock" boolean NOT NULL DEFAULT false,
                ADD COLUMN IF NOT EXISTS "sync_prices" boolean NOT NULL DEFAULT false,
                ADD COLUMN IF NOT EXISTS "erpnext_warehouse" text NULL,
                ADD COLUMN IF NOT EXISTS "medusa_stock_location_id" text NULL,
                ADD COLUMN IF NOT EXISTS "erpnext_safety_stock" integer NOT NULL DEFAULT 0;
        `);
    }
    async down() {
        this.addSql(`
            ALTER TABLE "erpnext_setting"
                DROP COLUMN IF EXISTS "sync_stock",
                DROP COLUMN IF EXISTS "sync_prices",
                DROP COLUMN IF EXISTS "erpnext_warehouse",
                DROP COLUMN IF EXISTS "medusa_stock_location_id",
                DROP COLUMN IF EXISTS "erpnext_safety_stock";
        `);
    }
}
exports.Migration20260927013045 = Migration20260927013045;
//# sourceMappingURL=Migration20260927013045.js.map