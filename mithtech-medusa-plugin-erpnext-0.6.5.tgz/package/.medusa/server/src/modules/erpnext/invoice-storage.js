"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3InvoiceStorage = exports.LocalInvoiceStorage = void 0;
exports.safeKey = safeKey;
exports.invoiceKey = invoiceKey;
exports.storageProblem = storageProblem;
exports.storageFor = storageFor;
const fs_1 = require("fs");
const path_1 = __importDefault(require("path"));
/** Keys are built from ids we generate; this refuses anything else. */
function safeKey(key) {
    const clean = String(key ?? "").trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9._\/-]{0,300}$/.test(clean) || clean.includes("..")) {
        throw new Error(`invalid invoice storage key: ${JSON.stringify(key)}`);
    }
    return clean;
}
function invoiceKey(orderId, number) {
    const part = (v) => String(v)
        .replace(/[^A-Za-z0-9._-]+/g, "_")
        .replace(/\.{2,}/g, "_")
        .replace(/^[._-]+/, "");
    return safeKey(`invoices/${part(orderId)}/${part(number)}.pdf`);
}
class LocalInvoiceStorage {
    root;
    kind = "local";
    constructor(root) {
        this.root = root;
    }
    resolve(key) {
        const full = path_1.default.resolve(this.root, safeKey(key));
        if (!full.startsWith(path_1.default.resolve(this.root) + path_1.default.sep)) {
            throw new Error("invoice key escapes the storage directory");
        }
        return full;
    }
    async put(key, bytes) {
        const full = this.resolve(key);
        await fs_1.promises.mkdir(path_1.default.dirname(full), { recursive: true, mode: 0o700 });
        await fs_1.promises.writeFile(full, bytes, { mode: 0o600 });
    }
    async get(key) {
        const full = this.resolve(key);
        try {
            const stat = await fs_1.promises.stat(full);
            return { body: (0, fs_1.createReadStream)(full), contentType: "application/pdf", size: stat.size };
        }
        catch (e) {
            if (e?.code === "ENOENT")
                return null;
            throw e;
        }
    }
    async remove(key) {
        await fs_1.promises.rm(this.resolve(key), { force: true });
    }
}
exports.LocalInvoiceStorage = LocalInvoiceStorage;
class S3InvoiceStorage {
    cfg;
    kind = "s3";
    client;
    constructor(cfg) {
        this.cfg = cfg;
    }
    async s3() {
        if (!this.client) {
            const { S3Client } = await import("@aws-sdk/client-s3");
            this.client = new S3Client({
                region: this.cfg.s3_region || "auto",
                endpoint: this.cfg.s3_endpoint || undefined,
                forcePathStyle: Boolean(this.cfg.s3_force_path_style),
                credentials: this.cfg.s3_access_key_id && this.cfg.s3_secret_access_key
                    ? {
                        accessKeyId: this.cfg.s3_access_key_id,
                        secretAccessKey: this.cfg.s3_secret_access_key,
                    }
                    : undefined,
            });
        }
        return this.client;
    }
    objectKey(key) {
        const prefix = String(this.cfg.s3_prefix ?? "").replace(/^\/+|\/+$/g, "");
        return prefix ? `${prefix}/${safeKey(key)}` : safeKey(key);
    }
    async put(key, bytes, contentType) {
        const { PutObjectCommand } = await import("@aws-sdk/client-s3");
        const client = await this.s3();
        await client.send(new PutObjectCommand({
            Bucket: this.cfg.s3_bucket,
            Key: this.objectKey(key),
            Body: bytes,
            ContentType: contentType,
            // Private regardless of the bucket's default ACL setting.
            ACL: "private",
        }));
    }
    async get(key) {
        const { GetObjectCommand } = await import("@aws-sdk/client-s3");
        const client = await this.s3();
        try {
            const out = await client.send(new GetObjectCommand({ Bucket: this.cfg.s3_bucket, Key: this.objectKey(key) }));
            return {
                body: out.Body,
                contentType: out.ContentType || "application/pdf",
                size: typeof out.ContentLength === "number" ? out.ContentLength : null,
            };
        }
        catch (e) {
            if (e?.name === "NoSuchKey" || e?.$metadata?.httpStatusCode === 404)
                return null;
            throw e;
        }
    }
    async remove(key) {
        const { DeleteObjectCommand } = await import("@aws-sdk/client-s3");
        const client = await this.s3();
        await client.send(new DeleteObjectCommand({ Bucket: this.cfg.s3_bucket, Key: this.objectKey(key) }));
    }
}
exports.S3InvoiceStorage = S3InvoiceStorage;
/** A problem that stops invoices being stored, or null when the settings work. */
function storageProblem(cfg) {
    if ((cfg.invoice_storage || "local") === "s3") {
        if (!cfg.s3_bucket)
            return "S3 storage needs a bucket";
        if (!cfg.s3_access_key_id || !cfg.s3_secret_access_key)
            return "S3 storage needs an access key and secret";
        return null;
    }
    return null;
}
function storageFor(cfg) {
    const problem = storageProblem(cfg);
    if (problem)
        throw new Error(problem);
    if ((cfg.invoice_storage || "local") === "s3") {
        return new S3InvoiceStorage({ ...cfg, s3_bucket: cfg.s3_bucket });
    }
    // Deliberately outside `static/`, which Medusa serves to anyone.
    const root = cfg.invoice_local_dir || path_1.default.join(process.cwd(), "private", "erpnext-invoices");
    return new LocalInvoiceStorage(root);
}
//# sourceMappingURL=invoice-storage.js.map