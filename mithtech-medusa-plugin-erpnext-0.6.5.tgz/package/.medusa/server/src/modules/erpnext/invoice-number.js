"use strict";
/**
 * The store's own invoice numbers, for stores that number invoices
 * themselves rather than letting ERPNext do it.
 *
 * `prefix` + a zero-padded running number, e.g. WEB-INV-00042. The number
 * is allocated by the caller in a single UPDATE; this only formats it and
 * reads back what an order already holds.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_PAD = void 0;
exports.formatInvoiceNumber = formatInvoiceNumber;
exports.storeNumbers = storeNumbers;
exports.receivesErpInvoices = receivesErpInvoices;
exports.DEFAULT_PAD = 5;
function formatInvoiceNumber(prefix, n, pad = exports.DEFAULT_PAD) {
    const cleanPrefix = String(prefix ?? "").trim();
    if (!cleanPrefix)
        throw new Error("the store invoice series has no prefix");
    if (!Number.isInteger(n) || n < 1)
        throw new Error(`invalid invoice sequence ${n}`);
    return `${cleanPrefix}${String(n).padStart(pad, "0")}`;
}
function storeNumbers(choices) {
    return choices?.invoice_numbering === "store";
}
/** Whether ERPNext will send invoices here for customers to download. */
function receivesErpInvoices(choices) {
    return !storeNumbers(choices) && Boolean(choices?.send_invoice_to_store);
}
//# sourceMappingURL=invoice-number.js.map