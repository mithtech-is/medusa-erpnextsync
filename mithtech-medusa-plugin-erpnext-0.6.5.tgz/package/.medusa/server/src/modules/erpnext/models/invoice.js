"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErpnextInvoice = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * `erpnext_invoice` — an invoice a customer can see for one order.
 *
 * Two kinds, depending on who numbers invoices for this store:
 *   - source "erpnext": ERPNext issued it and sent it here; the PDF is
 *     fetched from ERPNext and kept privately (see ../invoice-storage.ts).
 *   - source "store": this store issued the number itself and sent it to
 *     ERPNext. ERPNext books it and sends nothing back.
 *
 * The file is never public. `object_key` names it inside the configured
 * storage and is only ever read through the authenticated store route,
 * which checks the order belongs to the customer asking.
 */
exports.ErpnextInvoice = utils_1.model
    .define("erpnext_invoice", {
    id: utils_1.model.id().primaryKey(),
    order_id: utils_1.model.text().index(),
    customer_id: utils_1.model.text().nullable(),
    number: utils_1.model.text(),
    source: utils_1.model.text().default("erpnext"),
    invoice_date: utils_1.model.text().nullable(),
    total: utils_1.model.number().nullable(),
    currency: utils_1.model.text().nullable(),
    status: utils_1.model.text().nullable(),
    storage: utils_1.model.text().nullable(),
    object_key: utils_1.model.text().nullable(),
    content_type: utils_1.model.text().nullable(),
    size_bytes: utils_1.model.number().nullable(),
    fetched_at: utils_1.model.dateTime().nullable(),
    fetch_error: utils_1.model.text().nullable(),
});
//# sourceMappingURL=invoice.js.map