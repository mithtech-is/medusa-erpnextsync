"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErpnextSyncEvent = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * `erpnext_sync_event` — durable log of every sync attempt, both ways.
 *
 * Outbound rows are Medusa events the push path handled (paused today,
 * see ../outbound.ts). Inbound rows are Frappe Webhook deliveries and
 * the hourly selection reconcile. The admin lists them and can replay
 * one; the retry job replays failed ones.
 *
 * Identity:
 *   `event_id` is Medusa's `event.id` on an outbound row and
 *   `frappe:<event>:<doctype>:<name>:<modified>` on an inbound one, so
 *   Frappe's own retries of one delivery land on one row.
 *
 * Lifecycle:
 *   pending  → row created right before the HTTP POST
 *   success  → 2xx response within 15s
 *   failed   → non-2xx, network error, or timeout
 *   skipped  → ERPNEXT_URL / ERPNEXT_WEBHOOK_SECRET not configured at
 *              forward time (we don't even attempt the POST)
 *
 * `attempts` counts every retry (including the initial send). The admin
 * "retry" route increments it and resets the row to `pending` before
 * re-attempting.
 */
exports.ErpnextSyncEvent = utils_1.model.define("erpnext_sync_event", {
    id: utils_1.model.id().primaryKey(),
    /**
     * `<entity>:<id>` of the Medusa record an INBOUND write touched.
     *
     * This is the breadcrumb that stops a sync loop. An inbound write
     * lands as an ordinary module write; the event it triggers reaches the
     * forward subscriber moments later, in another request, where no
     * in-memory flag survives. Finding a recent inbound row for the same
     * entity tells the push it is an echo, and it is stamped so the far
     * side drops it.
     */
    entity_ref: utils_1.model.text().nullable(),
    /** Medusa event name, e.g. "customer.created", "order.placed". */
    event: utils_1.model.text().index(),
    /** Medusa's event.id — unique per event firing. Indexed for dedupe
     *  lookups in `forwardEvent`. */
    event_id: utils_1.model.text().searchable(),
    /** Enriched payload as forwarded — kept verbatim so a future retry
     *  doesn't have to re-fetch from the customer/order modules (which
     *  may have changed shape since the original fire). */
    payload: utils_1.model.json().nullable(),
    /**
     * One of: "pending" | "success" | "failed" | "skipped".
     * Stored as text rather than enum so adding new states later (e.g.
     * "rate_limited") doesn't require a migration.
     */
    status: utils_1.model.text().default("pending"),
    /** Total attempt count. Incremented on every send + every retry. */
    attempts: utils_1.model.number().default(0),
    /** Timestamp of the most recent attempt (success or fail). */
    last_attempt_at: utils_1.model.dateTime().nullable(),
    /** Timestamp of the first 2xx response. Stays set on subsequent
     *  retries that no-op (idempotent on the Frappe side). */
    succeeded_at: utils_1.model.dateTime().nullable(),
    /** Truncated to 1KB. HTTP status + response body, or the JS error
     *  message if the request never completed. */
    last_error: utils_1.model.text().nullable(),
    /** The full URL we POSTed to. Mostly for debugging when ERPNEXT_URL
     *  changes — old failed rows still show what they were aimed at. */
    target_url: utils_1.model.text().nullable(),
    /** Mapping row that produced this forward. NULL for legacy-path
     *  forwards (where no mapping matched and the subscriber used the
     *  catch-all enriched payload). Indexed via partial unique. */
    mapping_id: utils_1.model.text().nullable(),
    /**
     * Sync direction. "outbound" = Medusa→Frappe; "inbound" =
     * Frappe→Medusa, POSTed by a Frappe core Webhook. The
     * retry and reconciliation crons scan by (status, direction), so
     * this column is indexed in the migration.
     */
    direction: utils_1.model.text().default("outbound"),
    /**
     * What the sync actually DID on the far side — "created",
     * "updated", "skipped" or null when it never got that far. The
     * status column says whether the call succeeded; this says what it
     * changed, which is the question an operator triaging "why is this
     * customer missing in ERPNext" is really asking.
     */
    action: utils_1.model.text().nullable(),
    /**
     * SHA-256 of the transformed payload. Lets a mapping with
     * `skip_unchanged` recognise a repeat of a push it already made,
     * without keeping the previous document around. Indexed with
     * mapping_id because that is how the lookup queries it.
     */
    payload_hash: utils_1.model.text().nullable(),
    /**
     * This row is a rehearsal from the mapping studio, not real traffic.
     *
     * Everything that reads this table skips marked rows. The retry job
     * would otherwise send a fabricated payload for real; the
     * `skip_unchanged` guard would let a rehearsed success suppress a
     * genuine push as a duplicate; and both failures are invisible from
     * either end, which is the worst kind.
     */
    is_test: utils_1.model.boolean().default(false),
});
//# sourceMappingURL=sync-event.js.map