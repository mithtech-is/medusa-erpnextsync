"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * POST /store/carts/:id/erpnext-rounding
 *
 * Brings the cart's rounding line to what makes its total the one ERPNext
 * will invoice (see modules/erpnext/rounding.ts), and its payment
 * collection with it. The storefront calls it before showing the checkout
 * summary and before taking payment. The cart id is the credential, as for
 * every other store cart route.
 */
const POST = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const out = await erpnext.roundCart(req.scope, String(req.params.id));
    res.status(out.ok ? 200 : 404).json({ rounding: out });
};
exports.POST = POST;
//# sourceMappingURL=route.js.map