"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../../../modules/erpnext");
const route_1 = require("../invoices/route");
/**
 * GET /store/erpnext/orders/:id/gst
 *
 * The GST on a signed-in customer's order as ERPNext computed it: the
 * Sales Invoice when there is one, else the Sales Order. The storefront's
 * proforma quotes these rows instead of working tax out itself.
 */
const GET = async (req, res) => {
    const order = await (0, route_1.ownOrder)(req);
    if (!order)
        return res.status(404).json({ message: "Order not found" });
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    res.json({ gst: await erpnext.gstForOrder(order.id) });
};
exports.GET = GET;
//# sourceMappingURL=route.js.map