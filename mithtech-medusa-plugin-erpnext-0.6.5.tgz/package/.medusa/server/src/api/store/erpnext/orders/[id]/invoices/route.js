"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
exports.ownOrder = ownOrder;
const erpnext_1 = require("../../../../../../modules/erpnext");
/**
 * GET /store/erpnext/orders/:id/invoices
 *
 * The invoices a signed-in customer can see for one of their orders.
 * An order that is not theirs answers 404, not 403: whether an order id
 * exists is itself something a stranger should not learn.
 */
const GET = async (req, res) => {
    const order = await ownOrder(req);
    if (!order)
        return res.status(404).json({ message: "Order not found" });
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    res.json({ invoices: await erpnext.invoicesForOrder(order.id) });
};
exports.GET = GET;
async function ownOrder(req) {
    const customerId = req.auth_context?.actor_id;
    if (!customerId)
        return null;
    const orderSvc = req.scope.resolve("order");
    const [order] = await orderSvc.listOrders({ id: req.params.id, customer_id: customerId }, { take: 1, select: ["id", "customer_id"] });
    return order ?? null;
}
//# sourceMappingURL=route.js.map