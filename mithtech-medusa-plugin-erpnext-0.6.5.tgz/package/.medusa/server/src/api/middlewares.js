"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = require("@medusajs/framework/http");
const erpnext_1 = require("../modules/erpnext");
/**
 * After a saved address is deleted, retire its ERPNext Address and push the
 * customer. The delete workflow hard-deletes the address before its hook
 * runs, so the customer is taken from the request here instead.
 */
function afterAddressDelete(customerOf) {
    return (req, res, next) => {
        res.on("finish", () => {
            // Read at the end: the route's own authentication may run after this.
            const customerId = customerOf(req);
            const addressId = req.params?.address_id;
            if (res.statusCode >= 300 || !customerId || !addressId)
                return;
            const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
            void erpnext.addressRemoved(req.scope, String(customerId), String(addressId)).catch((err) => {
                console.warn("[erpnext] deleted address not retired:", err?.message ?? err);
            });
        });
        next();
    };
}
/**
 * Plugin-local middlewares.
 *
 * A Frappe core Webhook signs the exact bytes it sends, so the inbound
 * route verifies over `req.rawBody`, never over a re-serialised
 * `req.body`. Medusa keeps the raw body only for requests its JSON,
 * text or form parser handled — and only when asked, so it is asked here
 * for every POST under `/webhooks/*`. (Frappe sends no Content-Type of
 * its own; the header row "Set up ERPNext" adds is what makes the parser
 * run.) An Item with its child tables can be tens of kilobytes, hence the
 * limit.
 */
exports.default = (0, http_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/webhooks/*",
            method: ["POST"],
            bodyParser: { preserveRawBody: true, sizeLimit: "2mb" },
        },
        {
            // A customer's invoices are theirs alone; no guest access.
            matcher: "/store/erpnext/*",
            middlewares: [(0, http_1.authenticate)("customer", ["session", "bearer"])],
        },
        {
            matcher: "/store/customers/me/addresses/:address_id",
            method: ["DELETE"],
            middlewares: [afterAddressDelete((req) => req.auth_context?.actor_id)],
        },
        {
            matcher: "/admin/customers/:id/addresses/:address_id",
            method: ["DELETE"],
            middlewares: [afterAddressDelete((req) => req.params?.id)],
        },
    ],
});
//# sourceMappingURL=middlewares.js.map