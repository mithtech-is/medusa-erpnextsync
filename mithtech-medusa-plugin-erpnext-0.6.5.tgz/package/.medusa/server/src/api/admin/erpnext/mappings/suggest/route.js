"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * GET /admin/erpnext/mappings/suggest?entity=customer&doctype=Customer
 *
 * Returns the canonical mapping suggestion (if any) for the picked
 * (entity, doctype) pair. The admin Mapping editor calls this when
 * the operator clicks "Suggest field pairs" — it pre-fills the form
 * so the operator doesn't have to remember every store-specific
 * Custom Field name.
 *
 * Response shape:
 *   - { ok: true, canonical: true,  suggestion: {...} } — exact match found
 *   - { ok: true, canonical: false, suggestion: null  } — no entry; UI may
 *                                                          fall back to a
 *                                                          name-similarity
 *                                                          heuristic
 */
const GET = async (req, res) => {
    const entity = String(req.query.entity ?? "").trim();
    const doctype = String(req.query.doctype ?? "").trim();
    if (!entity || !doctype) {
        res.status(400).json({
            ok: false,
            message: "entity and doctype query params are required",
        });
        return;
    }
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const result = await erpnext.suggestMappingForPair(entity, doctype);
        res.json(result);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "suggest_failed",
        });
    }
};
exports.GET = GET;
//# sourceMappingURL=route.js.map