"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const zod_1 = require("zod");
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * POST /admin/erpnext/pull/items
 *
 * Pull a page of Items from ERPNext using Frappe's REST resource API.
 * This endpoint READS the remote list — it does NOT write to Medusa
 * yet. Treat the response as a preview / connectivity check; the
 * write-back-to-Medusa step is intentionally separate (operator must
 * decide what fields map to Product / variants / options for their
 * specific Frappe customisations).
 *
 * Body:
 *   - limit?: number          — default 50, max 500
 *   - filters?: any           — Frappe filter spec passed through
 *   - fields?: string[]       — Frappe fields list passed through
 *   - doctype?: string        — default "Item"; allow override for
 *                               Sales Invoice / Customer pulls in the
 *                               same shape.
 */
const BodySchema = zod_1.z.object({
    limit: zod_1.z.number().int().positive().max(500).optional(),
    filters: zod_1.z.any().optional(),
    fields: zod_1.z.array(zod_1.z.string()).optional(),
    doctype: zod_1.z.string().min(1).max(100).optional(),
});
const POST = async (req, res) => {
    const parsed = BodySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            ok: false,
            message: "Invalid input",
            errors: parsed.error.flatten(),
        });
        return;
    }
    const { limit, filters, fields, doctype } = parsed.data;
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const result = await erpnext.pullDoctype(doctype ?? "Item", {
            limit,
            filters,
            fields,
        });
        res.json(result);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "pull_failed",
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=route.js.map