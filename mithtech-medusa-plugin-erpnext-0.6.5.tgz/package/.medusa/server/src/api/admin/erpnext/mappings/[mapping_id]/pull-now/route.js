"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const erpnext_1 = require("../../../../../../modules/erpnext");
/**
 * POST /admin/erpnext/mappings/:mapping_id/pull-now
 *
 * Trigger a one-shot pull for this mapping immediately (instead of
 * waiting for the next cron tick). Useful for verifying a fresh
 * mapping does what the operator expects.
 *
 * Body: optional { full?: boolean } — when true, clears `last_pull_at`
 * before running so the pull does a complete scan instead of an
 * incremental one.
 */
const POST = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { mapping_id } = req.params;
    const body = (req.body ?? {});
    try {
        const mapping = await erpnext.getMapping(mapping_id);
        if (!mapping) {
            res.status(404).json({ ok: false, message: "mapping not found" });
            return;
        }
        if (body.full) {
            // Clear the watermark so this pull is a full scan. Written
            // directly: `saveMapping` does not carry `last_pull_at`.
            await erpnext.updateErpnextMappings([{ id: mapping_id, last_pull_at: null }]);
            mapping.last_pull_at = null;
        }
        const outcome = await erpnext.pullFromMapping({
            mapping,
            container: req.scope,
        });
        res.json(outcome);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "pull_now_failed",
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=route.js.map