"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * GET /admin/erpnext/products/unlinked
 *
 * Catalogue entries in ERPNext that no Medusa product claims yet — what
 * the operator picks from when attaching a product created here to the
 * one that already exists over there.
 *
 * Query:
 *   - search?: string   substring of the item code
 *   - limit?:  number   default 20, max 200
 *
 * Reads through the Frappe REST proxy, so it needs the API key/secret
 * rather than the webhook secret, and it never writes anything.
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { search, limit } = req.query;
    const result = await erpnext.listUnlinkedCatalogueItems({
        search,
        limit: limit ? Number(limit) : undefined,
    });
    if (!result.ok) {
        // A missing API key is operator configuration, not a server fault:
        // say which doctype was searched so the message is actionable.
        res.status(502).json({
            ok: false,
            doctype: result.doctype,
            message: result.message,
        });
        return;
    }
    res.json(result);
};
exports.GET = GET;
//# sourceMappingURL=route.js.map