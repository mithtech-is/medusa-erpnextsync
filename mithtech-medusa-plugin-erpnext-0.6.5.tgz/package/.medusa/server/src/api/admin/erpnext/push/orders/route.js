"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const utils_1 = require("@medusajs/framework/utils");
const zod_1 = require("zod");
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * POST /admin/erpnext/push/orders
 *
 * Manually push orders to ERPNext (event: `order.synced`).
 *
 * Body:
 *   - order_ids?: string[]   — explicit ids; empty/omitted = all
 *   - limit?: number         — cap (default 200, max 1000)
 */
const BodySchema = zod_1.z.object({
    order_ids: zod_1.z.array(zod_1.z.string()).optional(),
    limit: zod_1.z.number().int().positive().max(1000).optional(),
});
const POST = async (req, res) => {
    const parsed = BodySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            ok: false,
            message: "Invalid input",
            errors: parsed.error.flatten(),
        });
        return;
    }
    const { order_ids, limit } = parsed.data;
    const orderModule = req.scope.resolve(utils_1.Modules.ORDER);
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const filter = {};
    if (order_ids && order_ids.length > 0) {
        filter.id = order_ids;
    }
    const take = order_ids?.length ? order_ids.length : (limit ?? 200);
    const rows = await orderModule
        .listOrders(filter, {
        take,
        relations: [
            "items",
            "items.variant",
            "items.variant.product",
            "shipping_address",
            "billing_address",
            "payment_collections",
        ],
    })
        .catch(() => []);
    if (rows.length === 0) {
        res.json({
            ok: true,
            total: 0,
            success: 0,
            failed: 0,
            skipped: 0,
            results: [],
        });
        return;
    }
    const result = await erpnext.bulkPush({
        container: req.scope,
        event: "order.synced",
        entity: "order",
        items: rows.map((o) => ({ id: o.id, payload: o })),
    });
    res.json({ ok: true, ...result });
};
exports.POST = POST;
//# sourceMappingURL=route.js.map