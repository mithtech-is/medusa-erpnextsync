"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const erpnext_1 = require("../../../../modules/erpnext");
/**
 * POST /admin/erpnext/seed-mappings
 *
 * Idempotent — looks up each canonical mapping by `name`, skips
 * ones that already exist, creates the rest. Returns the lists
 * for the admin UI to surface (so the operator sees exactly
 * what changed).
 *
 * Wired to the "Reseed canonical mappings" button on the Settings
 * tab (F4). Also called once at plugin migration time so first-
 * install deployments have a usable starter set.
 */
const POST = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const result = await erpnext.seedCanonicalMappings();
        res.json(result);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "seed_failed",
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=route.js.map