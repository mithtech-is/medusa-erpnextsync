"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../modules/erpnext");
/**
 * GET /admin/erpnext/events
 *
 * List rows from `erpnext_sync_event`. Supports:
 *   ?status=pending|success|failed|skipped   (default: all)
 *   ?is_test=1|0                             (default: both)
 *   ?event=customer.created                  (exact match on event name)
 *   ?limit=50  (default 50, max 500)
 *   ?offset=0
 *
 * Sorted by `last_attempt_at DESC` so the freshest activity is first
 * — same view an operator wants when investigating "why didn't this
 * just-placed order show up in ERPNext".
 */
const GET = async (req, res) => {
    const q = req.query;
    const limit = Math.max(1, Math.min(500, Number(q.limit ?? 50)));
    const offset = Math.max(0, Number(q.offset ?? 0));
    const filters = {};
    if (q.status && ["pending", "success", "failed", "skipped"].includes(q.status)) {
        filters.status = q.status;
    }
    // Rehearsals look exactly like real traffic in this list, which is the
    // point of marking them. `?is_test=1` shows only those, `0` hides
    // them, and no parameter shows everything as it always did.
    if (q.is_test === "1" || q.is_test === "true") {
        filters.is_test = true;
    }
    else if (q.is_test === "0" || q.is_test === "false") {
        filters.is_test = false;
    }
    if (q.event) {
        filters.event = q.event;
    }
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const [items, count] = await erpnext.listAndCountErpnextSyncEvents(filters, {
        take: limit,
        skip: offset,
        order: { last_attempt_at: "DESC" },
    });
    res.json({
        items: items.map((r) => ({
            id: r.id,
            event: r.event,
            event_id: r.event_id,
            status: r.status,
            attempts: r.attempts,
            last_attempt_at: r.last_attempt_at,
            succeeded_at: r.succeeded_at,
            last_error: r.last_error,
            target_url: r.target_url,
            // payload is intentionally NOT included in the list view —
            // can be large. Fetch a single row to get it (future
            // GET /admin/erpnext/events/:id endpoint).
        })),
        count,
        limit,
        offset,
    });
};
exports.GET = GET;
//# sourceMappingURL=route.js.map