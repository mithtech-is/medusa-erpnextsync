"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const utils_1 = require("@medusajs/framework/utils");
const zod_1 = require("zod");
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * POST /admin/erpnext/push/products
 *
 * Manually push Medusa Products to ERPNext (event: `product.synced`).
 * The Frappe side maps Product → Item on whatever key the mapping
 * names — `handle` by default, or a metadata path for a store that
 * identifies its catalogue by something of its own.
 *
 * Body:
 *   - product_ids?: string[]
 *   - limit?: number  (default 200, max 1000)
 */
const BodySchema = zod_1.z.object({
    product_ids: zod_1.z.array(zod_1.z.string()).optional(),
    limit: zod_1.z.number().int().positive().max(1000).optional(),
});
const POST = async (req, res) => {
    const parsed = BodySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            ok: false,
            message: "Invalid input",
            errors: parsed.error.flatten(),
        });
        return;
    }
    const { product_ids, limit } = parsed.data;
    const productModule = req.scope.resolve(utils_1.Modules.PRODUCT);
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const filter = {};
    if (product_ids && product_ids.length > 0) {
        filter.id = product_ids;
    }
    const take = product_ids?.length ? product_ids.length : (limit ?? 200);
    const rows = await productModule
        .listProducts(filter, {
        take,
        relations: ["variants", "variants.options", "options", "tags"],
    })
        .catch(() => []);
    if (rows.length === 0) {
        res.json({
            ok: true,
            total: 0,
            success: 0,
            failed: 0,
            skipped: 0,
            results: [],
        });
        return;
    }
    const result = await erpnext.bulkPush({
        event: "product.synced",
        entity: "product",
        items: rows.map((p) => ({ id: p.id, payload: p })),
    });
    res.json({ ok: true, ...result });
};
exports.POST = POST;
//# sourceMappingURL=route.js.map