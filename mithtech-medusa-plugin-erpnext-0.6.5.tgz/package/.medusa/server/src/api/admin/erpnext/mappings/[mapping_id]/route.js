"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = exports.POST = exports.GET = void 0;
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * GET    /admin/erpnext/mappings/:mapping_id   — single row, full payload
 * POST   /admin/erpnext/mappings/:mapping_id   — update
 * DELETE /admin/erpnext/mappings/:mapping_id   — soft-delete (Medusa default)
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { mapping_id } = req.params;
    try {
        const row = await erpnext.getMapping(mapping_id);
        if (!row) {
            res.status(404).json({ ok: false, message: "mapping not found" });
            return;
        }
        res.json({ mapping: row });
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "mapping_load_failed",
        });
    }
};
exports.GET = GET;
const POST = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { mapping_id } = req.params;
    const body = (req.body ?? {});
    try {
        const userId = req?.auth_context?.actor_id ?? null;
        const saved = await erpnext.saveMapping({
            ...body,
            id: mapping_id,
            updated_by_user_id: body.updated_by_user_id ?? userId,
        });
        res.json({ ok: true, mapping: saved });
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "mapping_save_failed",
        });
    }
};
exports.POST = POST;
const DELETE = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { mapping_id } = req.params;
    try {
        const result = await erpnext.deleteMapping(mapping_id);
        res.json(result);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "mapping_delete_failed",
        });
    }
};
exports.DELETE = DELETE;
//# sourceMappingURL=route.js.map