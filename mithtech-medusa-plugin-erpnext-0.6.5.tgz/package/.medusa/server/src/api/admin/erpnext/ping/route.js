"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const erpnext_1 = require("../../../../modules/erpnext");
/**
 * POST /admin/erpnext/ping
 *
 * Verify the stored ERPNext URL + api_key / api_secret reach a real
 * Frappe instance. Hits Frappe's built-in
 *   GET /api/method/frappe.auth.get_logged_user
 * which echoes the user the keys belong to. The admin "Test connection"
 * button calls this.
 */
const POST = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const result = await erpnext.pingErpnext();
        res.json(result);
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "ping_failed",
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=route.js.map