"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../modules/erpnext");
/**
 * GET /admin/erpnext/reconcile
 *
 * On-demand reconciliation report across the reconcilable entities
 * (customer / product / order). For each, compares the live Medusa ids
 * (with a natural-key fallback) against what ERPNext has, and returns
 * the divergence — `missing_on_frappe` (in Medusa, not in ERPNext) and
 * `frappe_orphans` (stamped with a Medusa id ERPNext still has but Medusa
 * no longer does). Report-only; makes no changes on either side.
 *
 * Query: ?limit=<n> (per-side row cap, default 2000) & ?sample=<n>
 * (max ids listed per bucket, default 100).
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const q = req.query;
    const limit = q.limit ? Math.max(1, Math.min(10000, Number(q.limit))) : undefined;
    const sample = q.sample ? Math.max(1, Math.min(1000, Number(q.sample))) : undefined;
    try {
        const report = await erpnext.reconcileAll(req.scope, { limit, sample });
        res.json(report);
    }
    catch (err) {
        res.status(500).json({ ok: false, error: err?.message ?? "reconcile failed" });
    }
};
exports.GET = GET;
//# sourceMappingURL=route.js.map