"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const zod_1 = require("zod");
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * POST /admin/erpnext/stock-prices/refresh
 *
 * Re-read stock and selling prices from ERPNext now: for the Item codes
 * given, or for every linked Item when none are. What the hourly
 * reconcile does, on demand.
 */
const Body = zod_1.z.object({ item_codes: zod_1.z.array(zod_1.z.string().min(1)).max(500).optional() });
const POST = async (req, res) => {
    const parsed = Body.safeParse(req.body ?? {});
    if (!parsed.success) {
        return res.status(400).json({ ok: false, message: parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ") });
    }
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const codes = parsed.data.item_codes ?? [];
    const result = codes.length
        ? await erpnext.refreshStockAndPrices(req.scope, codes)
        : await erpnext.reconcileStockAndPrices(req.scope);
    return res.json({ ok: (result?.failed ?? 0) === 0, ...result });
};
exports.POST = POST;
//# sourceMappingURL=route.js.map