"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../../../modules/erpnext");
/**
 * GET /admin/erpnext/medusa-entities/:entity/options?path=status
 *
 * The known values for a Medusa target path, for the mapper's fixed and
 * default value pickers: a product's status, the store's sales channels,
 * shipping profiles, collections and types. `options: null` means the
 * path takes free text.
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { entity } = req.params;
    const path = String(req.query?.path ?? "").trim();
    if (!path) {
        res.status(400).json({ ok: false, message: "path is required" });
        return;
    }
    try {
        const options = await erpnext.medusaOptions(entity, path, req.scope);
        res.json({ ok: true, entity, path, options });
    }
    catch (err) {
        res.status(500).json({ ok: false, message: err?.message ?? "options_failed" });
    }
};
exports.GET = GET;
//# sourceMappingURL=route.js.map