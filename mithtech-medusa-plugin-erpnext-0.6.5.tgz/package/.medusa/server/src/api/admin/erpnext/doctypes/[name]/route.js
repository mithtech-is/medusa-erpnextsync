"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const erpnext_1 = require("../../../../../modules/erpnext");
/**
 * GET /admin/erpnext/doctypes/:name
 *
 * Return the field meta for one doctype via Frappe's
 * `frappe.client.get_meta`. The admin field-mapper calls this when
 * the operator picks a doctype on the right side of the editor —
 * the response populates the per-field dropdown.
 *
 * Response shape:
 *   {
 *     ok: boolean,
 *     fields: Array<{ fieldname, label, fieldtype, reqd, options, ... }>,
 *     filled_by_push: string[],   // mandatory fields the push fills itself
 *     message?: string
 *   }
 *
 * Results are cached server-side per process for 5 minutes — see
 * the meta cache in modules/erpnext/index.ts.
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    const { name } = req.params;
    if (!name) {
        res.status(400).json({ ok: false, message: "doctype name is required" });
        return;
    }
    try {
        const result = await erpnext.getDoctypeMeta(name);
        if (!result.ok) {
            res.status(502).json(result);
            return;
        }
        const filled_by_push = await erpnext.transportFilledFor(name).catch(() => []);
        res.json({ ...result, filled_by_push });
    }
    catch (err) {
        res.status(500).json({
            ok: false,
            message: err?.message ?? "doctype_meta_failed",
        });
    }
};
exports.GET = GET;
//# sourceMappingURL=route.js.map