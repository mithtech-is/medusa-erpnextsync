"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_flows_1 = require("@medusajs/medusa/core-flows");
const utils_1 = require("@medusajs/framework/utils");
/**
 * A customer's address book changing is a change to the customer: Medusa
 * emits no event of its own for it, so these hooks announce
 * `customer.updated` for the customers touched, and the customer push
 * brings ERPNext's Addresses along. A deleted address is handled by the
 * delete routes' middleware (see api/middlewares.ts): by the time the
 * delete workflow's hook runs, the address and its customer id are gone.
 * An announcement that fails is logged; it never fails the address save.
 */
async function announce(container, customerIds) {
    const ids = Array.from(new Set(customerIds.filter(Boolean)));
    if (!ids.length)
        return;
    try {
        const eventBus = container.resolve(utils_1.Modules.EVENT_BUS);
        await eventBus.emit(ids.map((id) => ({ name: "customer.updated", data: { id } })));
    }
    catch (err) {
        console.warn("[erpnext] address change not announced:", err?.message ?? err);
    }
}
core_flows_1.createCustomerAddressesWorkflow.hooks.addressesCreated(async ({ addresses }, { container }) => {
    await announce(container, (addresses ?? []).map((a) => a?.customer_id));
});
core_flows_1.updateCustomerAddressesWorkflow.hooks.addressesUpdated(async ({ addresses }, { container }) => {
    await announce(container, (addresses ?? []).map((a) => a?.customer_id));
});
//# sourceMappingURL=customer-addresses.js.map