"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = erpnextForwardHandler;
const erpnext_1 = require("../modules/erpnext");
const outbound_1 = require("../modules/erpnext/outbound");
const registry_1 = require("../modules/erpnext/registry");
const order_accounting_1 = require("../modules/erpnext/order-accounting");
/**
 * Mapping-driven Medusa → ERPNext forwarder.
 *
 * Lifecycle per event:
 *   1. Match the event name against the static event-registry to find
 *      the corresponding Medusa entity key (customer / order / product
 *      / user). Events that don't map to a registered entity are
 *      dropped silently — the operator can't have configured a mapping
 *      for them anyway.
 *   2. Pull every enabled mapping for that entity whose `events` array
 *      includes this event name (and whose direction is push or both).
 *   3. Fetch the enriched record once via the entity's registry
 *      `fetchById` adapter — shared across all mappings on the same
 *      entity so we don't re-fetch the customer/order N times.
 *   4. For each mapping: call `pushViaMapping` which runs the
 *      transform engine and logs into erpnext_sync_event tagged with
 *      mapping_id.
 *
 * While pushes are paused (../modules/erpnext/outbound.ts) the handler
 * returns before enriching anything: a paused push is not worth a
 * record fetch and a log row per event.
 *
 * Backpressure / errors:
 *   Each `pushViaMapping` call is awaited sequentially so a slow
 *   Frappe doesn't fan out N parallel HTTP requests per event. The
 *   service swallows HTTP errors and records them on the per-event
 *   row, so order placement on the storefront is never blocked.
 */
async function erpnextForwardHandler({ event, container, }) {
    const eventName = event?.name;
    if (!eventName)
        return;
    if (outbound_1.OUTBOUND_PAUSED)
        return;
    // A captured or refunded payment is an order event in disguise: the
    // order's push mappings run for `order.payment_captured`, which is
    // when a Sales Invoice can be raised and paid, and for
    // `order.payment_refunded`, which may cancel it.
    const orderEvent = PAYMENT_EVENTS[eventName];
    if (orderEvent) {
        const orderId = await orderIdForPayment(container, event?.data?.id);
        if (!orderId)
            return;
        return erpnextForwardHandler({
            event: { ...event, name: orderEvent, data: { ...(event?.data ?? {}), id: orderId } },
            container,
        });
    }
    const entityId = event?.data?.id;
    // Idempotency key for the far side. Medusa's event envelope does not
    // reliably carry a top-level `id` (workflow-emitted events often omit
    // it), so fall back to a synthesised, per-emission id rather than
    // dropping the event — otherwise create/delete events silently never
    // sync. A real `id`, when present, still wins so genuine retries dedupe.
    const eventId = event?.id ??
        event?.metadata?.eventId ??
        event?.metadata?.id ??
        (entityId
            ? `medusa:${eventName}:${entityId}:${Date.now()}`
            : undefined);
    if (!eventId) {
        console.warn(`[erpnext-forward] skipping ${eventName}: no event id and no entity id`);
        return;
    }
    const entityKey = resolveEntityKey(eventName);
    const erpnext = container.resolve(erpnext_1.ERPNEXT_MODULE);
    let enriched = event?.data ?? {};
    let mappings = [];
    if (entityKey) {
        const descriptor = (0, registry_1.getMedusaEntity)(entityKey);
        if (descriptor && entityId) {
            try {
                enriched = (await descriptor.fetchById(container, entityId)) ?? enriched;
            }
            catch (err) {
                console.warn(`[erpnext-forward] enrichment failed for ${eventName}:`, err);
            }
        }
        try {
            mappings = await erpnext.listEnabledPushMappingsForEvent(entityKey, eventName);
        }
        catch (err) {
            console.warn(`[erpnext-forward] mapping lookup failed for ${eventName}:`, err);
        }
    }
    // NB there is no KYC gate here any more.
    //
    // This used to hard-code "skip customer.* unless
    // metadata.kyc_fully_approved_at is set" for every customer mapping,
    // whether or not the operator wanted it, with no way to see or
    // change it from the admin. That rule now lives on the mapping row
    // as a trigger condition (see modules/erpnext/trigger.ts) and is
    // enforced inside pushViaMapping, so it applies to the bulk-push
    // routes and scripted pushes too — not just to live events.
    //
    // The migration moves every existing customer mapping onto the
    // "KYC fully verified" preset, so behaviour is unchanged until an
    // operator deliberately picks something else.
    //
    // The legacy fallback below is NOT trigger-gated, because it runs
    // only when no mapping matched at all — there is no mapping to read
    // a condition from. It keeps its own KYC check.
    if (mappings.length > 0) {
        for (const m of mappings) {
            const result = await erpnext.pushViaMapping({
                mapping: m,
                event: eventName,
                event_id: `${eventId}:${m.id}`,
                record: enriched,
                container,
            });
            // ERPNext's message can name the customer; it is kept on the
            // sync event, and the log carries identifiers only.
            if (!result.ok) {
                console.error(`[erpnext-forward] ${eventName} for ${entityKey}:${entityId ?? "?"} via mapping ${m.id} failed; see sync event ${eventId}:${m.id}`);
            }
        }
        return;
    }
    // No mapping matched this event → nothing to sync. The connector is
    // mapping-driven: an operator enables a doctype by creating a mapping
    // row for it. (The old pre-mapping "legacy full-payload forward" for
    // unmapped customer.*/order.* events was removed — it pushed to the
    // domain-specific `receive` handler pack and produced noisy failures for
    // events like `customer.synced` that were never meant to sync.)
    return;
}
const PAYMENT_EVENTS = {
    "payment.captured": "order.payment_captured",
    "payment.refunded": order_accounting_1.ORDER_REFUNDED_EVENT,
};
/** The order a payment belongs to, through its payment collection. */
async function orderIdForPayment(container, paymentId) {
    if (!paymentId)
        return null;
    try {
        const query = container.resolve("query");
        const { data: payments } = await query.graph({
            entity: "payment",
            fields: ["id", "payment_collection_id"],
            filters: { id: paymentId },
        });
        const collectionId = payments?.[0]?.payment_collection_id;
        if (!collectionId)
            return null;
        const { data: orders } = await query.graph({
            entity: "order",
            fields: ["id"],
            filters: { payment_collections: { id: collectionId } },
        });
        return orders?.[0]?.id ?? null;
    }
    catch (err) {
        console.warn(`[erpnext-forward] could not resolve the order for payment ${paymentId}:`, err?.message);
        return null;
    }
}
/**
 * Map an event name to the Medusa entity key it concerns. Drives the
 * mapping-lookup query — without this we'd have to ask the database
 * "give me every mapping with this event in its array", which is fine
 * but more expensive than scoping by entity first.
 *
 * Built from the registry so adding a new entity automatically wires
 * up its events as well — no double bookkeeping. Doesn't filter by
 * availability here; the mapping lookup is cheap and any mapping that
 * references an unavailable entity simply finds nothing.
 */
function resolveEntityKey(eventName) {
    for (const e of (0, registry_1.listMedusaEntities)()) {
        if (e.events.includes(eventName))
            return e.key;
    }
    // Also accept any custom event prefix the operator put on the
    // mapping (e.g. `app.kyc.verified`). Fall through and let
    // the mapping lookup figure it out — those don't need
    // pre-enrichment.
    const dotIdx = eventName.indexOf(".");
    if (dotIdx > 0)
        return eventName.slice(0, dotIdx);
    return null;
}
/**
 * Subscribe to every Medusa event a registered entity declares. The
 * resulting array is computed at import time so the framework's
 * subscriber loader sees a static config. Adding an entity to the
 * registry instantly extends this list — no extra wiring.
 */
function buildSubscribedEvents() {
    const set = new Set(Object.keys(PAYMENT_EVENTS));
    for (const e of (0, registry_1.listMedusaEntities)()) {
        for (const ev of e.events)
            set.add(ev);
    }
    return Array.from(set);
}
exports.config = {
    event: buildSubscribedEvents(),
};
//# sourceMappingURL=erpnext-forward.js.map