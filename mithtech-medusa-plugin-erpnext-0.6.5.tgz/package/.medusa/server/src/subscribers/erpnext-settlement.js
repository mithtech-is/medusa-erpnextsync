"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = erpnextSettlementHandler;
const erpnext_1 = require("../modules/erpnext");
const gateway_settlements_1 = require("../modules/erpnext/gateway-settlements");
/**
 * A payment gateway paid out (`payment_gateway.settlement_recorded`, emitted
 * by a payment plugin such as @mithtech-medusa/cashfree). The service books
 * it in ERPNext when Settings say so, and records the outcome on the
 * settlement's sync event; a failure waits there for the retry job.
 */
async function erpnextSettlementHandler({ event, container }) {
    const erpnext = container.resolve(erpnext_1.ERPNEXT_MODULE);
    const eventId = (0, gateway_settlements_1.settlementEventId)(event?.data);
    try {
        const result = await erpnext.bookSettlement(event?.data);
        if (!result.ok)
            console.error(`[erpnext-settlement] not booked; see sync event ${eventId}`);
    }
    catch (err) {
        console.error(`[erpnext-settlement] ${eventId} crashed: ${err?.message ?? err}`);
    }
}
exports.config = {
    event: gateway_settlements_1.SETTLEMENT_EVENT,
};
//# sourceMappingURL=erpnext-settlement.js.map