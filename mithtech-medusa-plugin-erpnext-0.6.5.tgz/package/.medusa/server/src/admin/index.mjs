import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import React, { useState, useCallback, useEffect, useMemo, useRef } from "react";
import { defineRouteConfig } from "@medusajs/admin-sdk";
import { Container, Heading, StatusBadge, Text, Button, Label, Switch, Input, Textarea, Select, Badge } from "@medusajs/ui";
import { ArrowsPointingOut, Plus, Trash } from "@medusajs/icons";
const TEXT_TYPES = /* @__PURE__ */ new Set([
  "Data",
  "Small Text",
  "Text",
  "Long Text",
  "Text Editor",
  "Markdown Editor",
  "HTML Editor",
  "Code",
  "Link",
  "Dynamic Link",
  "Select",
  "Read Only",
  "Autocomplete",
  "Phone",
  "Barcode",
  "Color",
  "Attach",
  "Attach Image",
  "Signature",
  "Password",
  "Rating",
  "Icon",
  "Geolocation"
]);
function frappeTypeGroup(fieldtype) {
  const t = String(fieldtype ?? "").trim();
  if (!t) return "unknown";
  if (TEXT_TYPES.has(t)) return "text";
  if (t === "Float" || t === "Currency" || t === "Percent" || t === "Duration") return "float";
  if (t === "Int") return "int";
  if (t === "Check") return "check";
  if (t === "Date") return "date";
  if (t === "Datetime") return "datetime";
  if (t === "Time") return "time";
  if (t === "JSON") return "json";
  if (t === "Table" || t === "Table MultiSelect") return "table";
  return "unknown";
}
const none = { kind: "none" };
const safe = (transform, why) => ({ kind: "safe", transform, why });
const review = (transform, why) => ({ kind: "review", transform, why });
const unmappable = (why) => ({ kind: "unmappable", why });
function suggestConversion(args) {
  const m = String(args.medusaType ?? "string");
  const f = frappeTypeGroup(args.frappeType);
  if (f === "table") return unmappable("a child table needs a dedicated handler");
  if (f === "unknown") return none;
  if (args.direction === "push") return pushVerdict(m, f);
  return pullVerdict(m, f);
}
function pushVerdict(m, f) {
  switch (m) {
    case "string":
    case "id":
      switch (f) {
        case "text":
        case "time":
          return none;
        case "float":
          return safe("number", "text into a number; a value that is not numeric is skipped");
        case "int":
          return review("integer", "text into an Int truncates any decimals");
        case "check":
          return review("check", "text into a tick box: only yes/no/true/false/0/1 convert");
        case "date":
          return review("date_yyyy_mm_dd", "text into a Date: only a parseable date converts");
        case "datetime":
          return review("datetime_frappe", "text into a Datetime: only a parseable datetime converts");
        case "json":
          return review("json", "text into a JSON field is stored as a JSON string");
      }
      break;
    case "number":
      switch (f) {
        case "float":
          return none;
        case "int":
          return review("integer", "a number into an Int truncates any decimals");
        case "text":
          return safe("text", "a number written as text");
        case "check":
          return review("check", "a number into a tick box: 0 is off, anything else on");
        default:
          return unmappable(`a number cannot become a ${f}`);
      }
    case "boolean":
      switch (f) {
        case "check":
          return safe("check", "true/false as 1/0");
        case "text":
          return safe("text", "true/false written as text");
        case "int":
        case "float":
          return review("check", "true/false as 1/0 into a numeric field");
        default:
          return unmappable(`a boolean cannot become a ${f}`);
      }
    case "datetime":
      switch (f) {
        case "datetime":
          return safe("datetime_frappe", "in the ERPNext site's timezone");
        case "date":
          return safe("date_yyyy_mm_dd", "the date part, in the ERPNext site's timezone");
        case "text":
          return safe("date_iso", "as an ISO timestamp");
        default:
          return unmappable(`a datetime cannot become a ${f}`);
      }
    case "array":
      switch (f) {
        case "json":
          return safe("json", "the list as JSON");
        case "text":
          return review("join:,", "a list into text needs a separator; comma is a guess");
        default:
          return unmappable(`a list cannot become a ${f}`);
      }
    case "json":
      switch (f) {
        case "json":
        case "text":
          return safe("json", "the object as a JSON string");
        default:
          return unmappable(`an object cannot become a ${f}`);
      }
  }
  return none;
}
function pullVerdict(m, f) {
  switch (m) {
    case "string":
    case "id":
      switch (f) {
        case "text":
        case "time":
        case "date":
        case "datetime":
          return none;
        case "float":
        case "int":
        case "check":
          return safe("text", "a number written as text");
        case "json":
          return none;
      }
      break;
    case "number":
      switch (f) {
        case "float":
        case "int":
        case "check":
          return none;
        case "text":
          return safe("number", "text into a number; a value that is not numeric is skipped");
        default:
          return unmappable(`a ${f} cannot become a number`);
      }
    case "boolean":
      switch (f) {
        case "check":
          return safe("boolean", "1/0 as true/false");
        case "int":
        case "float":
          return review("boolean", "a number into true/false: 0 is false, anything else true");
        case "text":
          return review("boolean", "text into true/false: only yes/no/true/false/0/1 convert");
        default:
          return unmappable(`a ${f} cannot become a boolean`);
      }
    case "datetime":
      switch (f) {
        case "datetime":
        case "date":
          return safe("date_iso", "from the ERPNext site's timezone");
        case "text":
          return review("date_iso", "text into a datetime: only a parseable value converts");
        default:
          return unmappable(`a ${f} cannot become a datetime`);
      }
    case "array":
      switch (f) {
        case "json":
          return safe("parse_json", "the JSON list");
        case "text":
          return review("split:,", "text into a list needs a separator; comma is a guess");
        default:
          return unmappable(`a ${f} cannot become a list`);
      }
    case "json":
      switch (f) {
        case "json":
          return safe("parse_json", "the JSON object");
        case "text":
          return review("parse_json", "text into an object: only valid JSON converts");
        default:
          return unmappable(`a ${f} cannot become an object`);
      }
  }
  return none;
}
function gatewayRowsOf(gateways) {
  return Object.entries(gateways ?? {}).map(([provider, g]) => ({
    provider,
    supplier: g.supplier ?? "",
    item: g.item ?? "",
    gst_hsn_code: g.gst_hsn_code ?? "",
    mode_of_payment: g.mode_of_payment ?? ""
  }));
}
function modeRowsOf(modes) {
  return Object.entries(modes ?? {}).map(([provider, mode]) => ({ provider, mode }));
}
const SETUP_KIND_LABELS = {
  custom_field: "Custom Field",
  webhook: "Webhook",
  supplier: "Supplier",
  item: "Item",
  account: "Account"
};
const TABS = [
  { key: "settings", label: "Settings" },
  // Mappings — Medusa-side `erpnext_mapping` rows, edited via the
  // doctype-introspection mapper at the bottom of this file.
  // Replaces the earlier Frappe-proxy MappingsTab (dead code retained
  // briefly below the new component for reference; remove once the
  // new editor is battle-tested).
  { key: "mappings", label: "Mappings" },
  { key: "documents", label: "Documents" },
  { key: "pull", label: "Pull" },
  { key: "events", label: "Events" },
  { key: "reconcile", label: "Reconcile" }
];
const ErpnextPage = () => {
  const [tab, setTab] = useState("settings");
  const [view, setView] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/admin/erpnext/settings", {
        credentials: "include"
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || "load_failed");
      setView(body);
    } catch (e) {
      setError(e instanceof Error ? e.message : "failed");
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    refresh();
  }, [refresh]);
  return /* @__PURE__ */ jsxs(Container, { children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(ArrowsPointingOut, {}),
      /* @__PURE__ */ jsx(Heading, { level: "h1", children: "ERPNext sync" }),
      view?.enable_sync ? /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: "on" }) : /* @__PURE__ */ jsx(StatusBadge, { color: "grey", children: "off" })
    ] }),
    /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle mb-4", children: [
      "ERPNext → Medusa through Frappe's own webhooks and a scheduled pull: set ",
      /* @__PURE__ */ jsx("strong", { children: "Sync to Medusa" }),
      " on a document to ERPNext → Medusa or Both and it lands here; clear it or delete the document and its product goes to draft. Set up ERPNext, under Settings, installs the field and the webhooks."
    ] }),
    error && /* @__PURE__ */ jsx("div", { className: "mb-4 rounded border border-red-200 bg-red-50 px-3 py-2 text-red-700", children: /* @__PURE__ */ jsx(Text, { children: error }) }),
    view?.outbound_paused && /* @__PURE__ */ jsx("div", { className: "mb-4 rounded border border-ui-tag-orange-border bg-ui-tag-orange-bg px-3 py-2", children: /* @__PURE__ */ jsx(Text, { size: "small", children: "Pushes to ERPNext are paused (ERPNEXT_PAUSE_PUSH is set): push mappings are evaluated and logged, nothing leaves. ERPNext → Medusa is live." }) }),
    /* @__PURE__ */ jsx("div", { className: "mb-6 flex flex-wrap gap-2", children: TABS.map((t) => /* @__PURE__ */ jsx(
      Button,
      {
        variant: tab === t.key ? "primary" : "secondary",
        onClick: () => setTab(t.key),
        children: t.label
      },
      t.key
    )) }),
    !view && loading && /* @__PURE__ */ jsx(Text, { children: "Loading…" }),
    view && tab === "settings" && /* @__PURE__ */ jsx(SettingsTab, { view, onSaved: (v) => setView(v) }),
    view && tab === "mappings" && /* @__PURE__ */ jsx(MappingsTab, { onJumpToTab: setTab }),
    view && tab === "pull" && /* @__PURE__ */ jsx(PullTab, {}),
    view && tab === "events" && /* @__PURE__ */ jsx(EventsTab, {}),
    view && tab === "reconcile" && /* @__PURE__ */ jsx(ReconcileTab, {}),
    view && tab === "documents" && /* @__PURE__ */ jsx(DocumentsTab, { erpnextUrl: view.erpnext_url ?? view.env_fallback?.erpnext_url ?? null })
  ] });
};
const SettingsTab = ({ view, onSaved }) => {
  const [enableSync, setEnableSync] = useState(view.enable_sync);
  const [url, setUrl] = useState(view.erpnext_url ?? "");
  const [publicUrl, setPublicUrl] = useState(view.medusa_public_url ?? "");
  const [syncDoctypes, setSyncDoctypes] = useState(view.sync_doctypes ?? []);
  const [frappeWebhookSecret, setFrappeWebhookSecret] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [timeoutMs, setTimeoutMs] = useState(view.request_timeout_ms);
  const [autoRetry, setAutoRetry] = useState(view.auto_retry_failed);
  const [retryMax, setRetryMax] = useState(view.auto_retry_max_attempts);
  const [retryInterval, setRetryInterval] = useState(
    view.auto_retry_min_interval_minutes
  );
  const [pushAllowlist, setPushAllowlist] = useState(view.push_allowlist ?? "");
  const [logRetentionDays, setLogRetentionDays] = useState(
    view.log_retention_days ?? 180
  );
  const [sendInvoice, setSendInvoice] = useState(Boolean(view.send_invoice_to_store));
  const [recordPayments, setRecordPayments] = useState(Boolean(view.record_payments));
  const [paymentModes, setPaymentModes] = useState(modeRowsOf(view.payment_modes));
  const [bookSettlements, setBookSettlements] = useState(Boolean(view.book_settlements));
  const [settlementBank, setSettlementBank] = useState(view.settlement_bank_account ?? "");
  const [createSettlementBank, setCreateSettlementBank] = useState(Boolean(view.create_settlement_bank_account));
  const [gatewayRows, setGatewayRows] = useState(gatewayRowsOf(view.gateway_suppliers));
  const [pushCfg, setPushCfg] = useState({
    erpnext_company: view.erpnext_company ?? "",
    erpnext_price_list: view.erpnext_price_list ?? "",
    erpnext_customer_group: view.erpnext_customer_group ?? "",
    erpnext_territory: view.erpnext_territory ?? "",
    erpnext_shipping_account: view.erpnext_shipping_account ?? "",
    erpnext_taxes_template: view.erpnext_taxes_template ?? ""
  });
  const [orderDocument, setOrderDocument] = useState(view.order_document ?? "Sales Order and Sales Invoice");
  const [stockCfg, setStockCfg] = useState({
    sync_stock: Boolean(view.sync_stock),
    sync_prices: Boolean(view.sync_prices),
    erpnext_warehouse: view.erpnext_warehouse ?? "",
    medusa_stock_location_id: view.medusa_stock_location_id ?? "",
    erpnext_safety_stock: String(view.erpnext_safety_stock ?? 0)
  });
  const [freshSecret, setFreshSecret] = useState(null);
  const generateSecret = () => {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    setFrappeWebhookSecret(hex);
    setFreshSecret(hex);
  };
  const [settingUp, setSettingUp] = useState(false);
  const [setupResult, setSetupResult] = useState(null);
  const [invoiceStorage, setInvoiceStorage] = useState(view.invoice_storage ?? "local");
  const [localDir, setLocalDir] = useState(view.invoice_local_dir ?? "");
  const [s3Bucket, setS3Bucket] = useState(view.s3_bucket ?? "");
  const [s3Region, setS3Region] = useState(view.s3_region ?? "");
  const [s3Endpoint, setS3Endpoint] = useState(view.s3_endpoint ?? "");
  const [s3Prefix, setS3Prefix] = useState(view.s3_prefix ?? "");
  const [s3PathStyle, setS3PathStyle] = useState(Boolean(view.s3_force_path_style));
  const [s3KeyId, setS3KeyId] = useState("");
  const [s3Secret, setS3Secret] = useState("");
  const [notes, setNotes] = useState(view.notes ?? "");
  const [saving, setSaving] = useState(false);
  const [flash, setFlash] = useState(null);
  const [err, setErr] = useState(null);
  const [pingResult, setPingResult] = useState(null);
  const [pinging, setPinging] = useState(false);
  useEffect(() => {
    setEnableSync(view.enable_sync);
    setUrl(view.erpnext_url ?? "");
    setPublicUrl(view.medusa_public_url ?? "");
    setSyncDoctypes(view.sync_doctypes ?? []);
    setFrappeWebhookSecret("");
    setApiKey("");
    setApiSecret("");
    setTimeoutMs(view.request_timeout_ms);
    setAutoRetry(view.auto_retry_failed);
    setRetryMax(view.auto_retry_max_attempts);
    setRetryInterval(view.auto_retry_min_interval_minutes);
    setPushAllowlist(view.push_allowlist ?? "");
    setLogRetentionDays(view.log_retention_days ?? 180);
    setSendInvoice(Boolean(view.send_invoice_to_store));
    setRecordPayments(Boolean(view.record_payments));
    setPaymentModes(modeRowsOf(view.payment_modes));
    setBookSettlements(Boolean(view.book_settlements));
    setSettlementBank(view.settlement_bank_account ?? "");
    setCreateSettlementBank(Boolean(view.create_settlement_bank_account));
    setGatewayRows(gatewayRowsOf(view.gateway_suppliers));
    setPushCfg({
      erpnext_company: view.erpnext_company ?? "",
      erpnext_price_list: view.erpnext_price_list ?? "",
      erpnext_customer_group: view.erpnext_customer_group ?? "",
      erpnext_territory: view.erpnext_territory ?? "",
      erpnext_shipping_account: view.erpnext_shipping_account ?? "",
      erpnext_taxes_template: view.erpnext_taxes_template ?? ""
    });
    setOrderDocument(view.order_document ?? "Sales Order and Sales Invoice");
    setStockCfg({
      sync_stock: Boolean(view.sync_stock),
      sync_prices: Boolean(view.sync_prices),
      erpnext_warehouse: view.erpnext_warehouse ?? "",
      medusa_stock_location_id: view.medusa_stock_location_id ?? "",
      erpnext_safety_stock: String(view.erpnext_safety_stock ?? 0)
    });
    setInvoiceStorage(view.invoice_storage ?? "local");
    setLocalDir(view.invoice_local_dir ?? "");
    setS3Bucket(view.s3_bucket ?? "");
    setS3Region(view.s3_region ?? "");
    setS3Endpoint(view.s3_endpoint ?? "");
    setS3Prefix(view.s3_prefix ?? "");
    setS3PathStyle(Boolean(view.s3_force_path_style));
    setS3KeyId("");
    setS3Secret("");
    setNotes(view.notes ?? "");
  }, [view]);
  const save = async () => {
    setSaving(true);
    setErr(null);
    setFlash(null);
    try {
      const body = {
        enable_sync: enableSync,
        erpnext_url: url.trim() || null,
        medusa_public_url: publicUrl.trim() || null,
        request_timeout_ms: timeoutMs,
        auto_retry_failed: autoRetry,
        auto_retry_max_attempts: retryMax,
        auto_retry_min_interval_minutes: retryInterval,
        push_allowlist: pushAllowlist.trim() || null,
        log_retention_days: Number(logRetentionDays) || 0,
        ...Object.fromEntries(Object.entries(pushCfg).map(([k, v]) => [k, v.trim() || null])),
        order_document: orderDocument,
        send_invoice_to_store: sendInvoice,
        record_payments: recordPayments,
        payment_modes: Object.fromEntries(
          paymentModes.map((r) => [r.provider.trim(), r.mode.trim()]).filter(([provider, mode]) => provider && mode)
        ),
        book_settlements: bookSettlements,
        settlement_bank_account: settlementBank.trim() || null,
        create_settlement_bank_account: createSettlementBank,
        gateway_suppliers: Object.fromEntries(
          gatewayRows.filter((r) => r.provider.trim() && r.supplier.trim()).map((r) => [
            r.provider.trim().toLowerCase(),
            {
              supplier: r.supplier.trim(),
              item: r.item.trim() || void 0,
              gst_hsn_code: r.gst_hsn_code.trim() || void 0,
              mode_of_payment: r.mode_of_payment.trim() || null
            }
          ])
        ),
        sync_stock: stockCfg.sync_stock,
        sync_prices: stockCfg.sync_prices,
        erpnext_warehouse: stockCfg.erpnext_warehouse.trim() || null,
        medusa_stock_location_id: stockCfg.medusa_stock_location_id.trim() || null,
        erpnext_safety_stock: Math.max(0, Math.floor(Number(stockCfg.erpnext_safety_stock) || 0)),
        invoice_storage: invoiceStorage,
        invoice_local_dir: localDir.trim() || null,
        s3_bucket: s3Bucket.trim() || null,
        s3_region: s3Region.trim() || null,
        s3_endpoint: s3Endpoint.trim() || null,
        s3_prefix: s3Prefix.trim() || null,
        s3_force_path_style: s3PathStyle,
        notes: notes.trim() || null
      };
      if (s3KeyId) body.s3_access_key_id = s3KeyId;
      if (s3Secret) body.s3_secret_access_key = s3Secret;
      if (frappeWebhookSecret) body.frappe_webhook_secret = frappeWebhookSecret;
      if (apiKey) body.erpnext_api_key = apiKey;
      if (apiSecret) body.erpnext_api_secret = apiSecret;
      const res = await fetch("/admin/erpnext/settings", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "save_failed");
      onSaved(data);
      setFlash("Saved");
      setTimeout(() => setFlash(null), 2500);
      return true;
    } catch (e) {
      setErr(e instanceof Error ? e.message : "save_failed");
      return false;
    } finally {
      setSaving(false);
    }
  };
  const setupErpnext = async () => {
    setSetupResult(null);
    if (!await save()) return;
    setSettingUp(true);
    try {
      const res = await fetch("/admin/erpnext/setup", {
        method: "POST",
        credentials: "include"
      });
      const body = await res.json();
      setSetupResult(body);
      const again = await fetch("/admin/erpnext/settings", { credentials: "include" });
      if (again.ok) onSaved(await again.json());
    } catch (e) {
      setSetupResult({ ok: false, message: e instanceof Error ? e.message : "setup_failed" });
    } finally {
      setSettingUp(false);
    }
  };
  const [refreshing, setRefreshing] = useState(false);
  const [refreshResult, setRefreshResult] = useState(null);
  const refreshStockPrices = async () => {
    setRefreshResult(null);
    if (!await save()) return;
    setRefreshing(true);
    try {
      const res = await fetch("/admin/erpnext/stock-prices/refresh", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: "{}"
      });
      const body = await res.json();
      setRefreshResult(
        body.skipped ? `Nothing refreshed: ${body.skipped === "off" ? "both switches are off" : body.skipped}` : `${body.items ?? 0} linked item(s): ${body.stock ?? 0} level(s) and ${body.prices ?? 0} price(s) changed, ${body.failed ?? 0} failed` + (Array.isArray(body.notes) && body.notes.length ? ` — ${body.notes.slice(0, 5).join("; ")}` : "")
      );
    } catch (e) {
      setRefreshResult(e instanceof Error ? e.message : "refresh_failed");
    } finally {
      setRefreshing(false);
    }
  };
  const setupBlocker = !(url.trim() || view.env_fallback.erpnext_url) ? "Set the ERPNext URL first" : !(view.erpnext_api_key_masked || apiKey) ? "Set the API key and secret first (System Manager)" : !syncDoctypes.length ? "Add a sync that pulls from ERPNext first (Mappings)" : null;
  const ping = async () => {
    setPinging(true);
    setPingResult(null);
    try {
      const res = await fetch("/admin/erpnext/ping", {
        method: "POST",
        credentials: "include"
      });
      const body = await res.json();
      setPingResult(body);
    } catch (e) {
      setPingResult({
        ok: false,
        message: e instanceof Error ? e.message : "ping_failed"
      });
    } finally {
      setPinging(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Connection" }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-subtle", children: "Sync enabled" }),
          /* @__PURE__ */ jsx(Switch, { checked: enableSync, onCheckedChange: setEnableSync })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "ERPNext URL" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: url,
              onChange: (e) => setUrl(e.target.value),
              placeholder: "https://erp.example.com"
            }
          ),
          view.env_fallback.erpnext_url && /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
            "Env fallback: ",
            view.env_fallback.erpnext_url
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Medusa public URL" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: publicUrl,
              onChange: (e) => setPublicUrl(e.target.value),
              placeholder: view.env_fallback.medusa_public_url ?? "https://shop.example.com"
            }
          ),
          /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
            "Where ERPNext reaches this store. The webhooks POST to",
            " ",
            /* @__PURE__ */ jsxs("code", { children: [
              (publicUrl.trim() || view.env_fallback.medusa_public_url || "<url>").replace(/\/+$/, ""),
              "/webhooks/erpnext-inbound"
            ] }),
            view.env_fallback.medusa_public_url && !publicUrl.trim() ? ". Blank uses MEDUSA_BACKEND_URL." : "."
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Frappe webhook secret" }),
                view.frappe_webhook_secret_masked ? /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: "set" }) : view.env_fallback.frappe_webhook_secret_present ? /* @__PURE__ */ jsx(StatusBadge, { color: "blue", children: "from env" }) : /* @__PURE__ */ jsx(StatusBadge, { color: "grey", children: "not set" })
              ] }),
              /* @__PURE__ */ jsx(Button, { size: "small", variant: "transparent", onClick: generateSecret, children: "Generate" })
            ] }),
            /* @__PURE__ */ jsx(
              Input,
              {
                type: "password",
                placeholder: view.frappe_webhook_secret_masked ?? "Not set — Set up ERPNext generates one",
                value: frappeWebhookSecret,
                onChange: (e) => setFrappeWebhookSecret(e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Signs every webhook ERPNext sends here. Set up ERPNext generates it when empty and writes it into the Webhook rows itself; copy it only if you maintain the webhooks by hand." })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "API key" }),
              view.erpnext_api_key_masked ? /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: "set" }) : /* @__PURE__ */ jsx(StatusBadge, { color: "grey", children: "not set" })
            ] }),
            /* @__PURE__ */ jsx(
              Input,
              {
                placeholder: view.erpnext_api_key_masked ?? "Not set",
                value: apiKey,
                onChange: (e) => setApiKey(e.target.value)
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "mt-2 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "API secret" }),
              view.erpnext_api_secret_masked ? /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: "set" }) : /* @__PURE__ */ jsx(StatusBadge, { color: "grey", children: "not set" })
            ] }),
            /* @__PURE__ */ jsx(
              Input,
              {
                type: "password",
                placeholder: view.erpnext_api_secret_masked ?? "Not set",
                value: apiSecret,
                onChange: (e) => setApiSecret(e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Token auth for the pull, field reads and Set up ERPNext (which needs the System Manager role)." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-4 flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsx(Button, { onClick: save, disabled: saving, variant: "primary", children: saving ? "Saving…" : "Save" }),
        /* @__PURE__ */ jsx(Button, { onClick: ping, disabled: pinging, variant: "secondary", children: pinging ? "Pinging…" : "Test connection" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            onClick: async () => {
              setErr(null);
              const r = await fetch("/admin/erpnext/seed-mappings", {
                method: "POST",
                credentials: "include"
              });
              const b = await r.json();
              setFlash(
                `Mappings seeded: ${b.seeded?.length ?? 0}, skipped: ${b.skipped?.length ?? 0}, errors: ${b.errors?.length ?? 0}`
              );
            },
            variant: "secondary",
            children: "Reseed canonical mappings"
          }
        ),
        flash && /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: flash }),
        err && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-red-600", children: err })
      ] }),
      pingResult && /* @__PURE__ */ jsx(
        "div",
        {
          className: `mt-3 rounded border px-3 py-2 ${pingResult.ok ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`,
          children: /* @__PURE__ */ jsx(Text, { size: "small", children: pingResult.ok ? `OK · authenticated as ${pingResult.user ?? "(unknown)"}` : `Failed${pingResult.httpStatus ? ` (HTTP ${pingResult.httpStatus})` : ""}: ${pingResult.message}` })
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-3 flex items-center justify-between", children: /* @__PURE__ */ jsx(Heading, { level: "h2", children: "ERPNext setup" }) }),
      /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: [
        /* @__PURE__ */ jsx("strong", { children: "Set up ERPNext" }),
        " installs, on the ERPNext side, what a sync that reads ",
        /* @__PURE__ */ jsx("em", { children: "from" }),
        " ERPNext needs: a ",
        /* @__PURE__ */ jsx("strong", { children: "Sync to Medusa" }),
        " field on that DocType (a person sets it to ERPNext → Medusa, Medusa → ERPNext or Both on each document — that is how you choose which Items reach the store) and two webhooks that deliver changes. Only DocTypes that some sync pulls from are listed: a sync that only writes ",
        /* @__PURE__ */ jsx("em", { children: "to" }),
        " ERPNext (Customers, Orders) goes over REST and needs nothing installed. Whether a ",
        /* @__PURE__ */ jsx("em", { children: "new" }),
        " ERPNext document starts on None (nothing syncs until someone picks a direction) or on Both (everything syncs unless someone sets it to None) is set on the sync itself, under",
        " ",
        /* @__PURE__ */ jsx("strong", { children: "Mappings" }),
        ". Press Set up ERPNext after adding or changing a sync."
      ] }),
      syncDoctypes.length ? /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "text-left text-ui-fg-subtle", children: [
          /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "ERPNext DocType" }),
          /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "Read by sync" }),
          /* @__PURE__ */ jsx("th", { className: "py-1", children: "A new document there" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: syncDoctypes.map((row) => {
          const src = (view.selection_sources ?? []).find((s) => s.doctype === row.doctype);
          return /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "py-1 pr-2 font-mono", children: row.doctype }),
            /* @__PURE__ */ jsx("td", { className: "py-1 pr-2", children: src?.syncs?.length ? src.syncs.join(", ") : "—" }),
            /* @__PURE__ */ jsx("td", { className: "py-1", children: row.mode === "deny" ? "starts on Both — syncs unless someone sets it to None" : "starts on None — syncs only once someone picks a direction" })
          ] }, row.doctype);
        }) })
      ] }) : /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "No sync pulls from ERPNext yet, so nothing needs the field. Add one under Mappings." }),
      /* @__PURE__ */ jsxs("div", { className: "mt-4 flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsx(
          Button,
          {
            onClick: setupErpnext,
            disabled: settingUp || saving || Boolean(setupBlocker),
            variant: "primary",
            children: settingUp ? "Setting up…" : "Set up ERPNext"
          }
        ),
        setupBlocker && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: setupBlocker }),
        view.erpnext_setup_at && /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "Last set up ",
          new Date(view.erpnext_setup_at).toLocaleString(),
          view.erpnext_setup_report?.inbound_url ? ` · ${view.erpnext_setup_report.inbound_url}` : ""
        ] })
      ] }),
      (setupResult ?? (view.erpnext_setup_report ? { ok: view.erpnext_setup_report.ok, report: view.erpnext_setup_report } : null)) && (() => {
        const shown = setupResult ?? { ok: view.erpnext_setup_report.ok, report: view.erpnext_setup_report };
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: `mt-3 rounded border px-3 py-2 ${shown.ok ? "border-ui-tag-green-border bg-ui-tag-green-bg text-ui-fg-base" : "border-ui-tag-red-border bg-ui-tag-red-bg text-ui-fg-base"}`,
            children: [
              shown.message && /* @__PURE__ */ jsx(Text, { size: "small", children: shown.message }),
              shown.report && /* @__PURE__ */ jsxs("table", { className: "w-full text-xs", children: [
                /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "text-left text-ui-fg-subtle", children: [
                  /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "Kind" }),
                  /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "Name" }),
                  /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "Result" }),
                  /* @__PURE__ */ jsx("th", { className: "py-1", children: "Detail" })
                ] }) }),
                /* @__PURE__ */ jsx("tbody", { children: shown.report.items.map((it, i) => /* @__PURE__ */ jsxs("tr", { children: [
                  /* @__PURE__ */ jsx("td", { className: "py-1 pr-2", children: SETUP_KIND_LABELS[it.kind] ?? it.kind }),
                  /* @__PURE__ */ jsx("td", { className: "py-1 pr-2 font-mono", children: it.name }),
                  /* @__PURE__ */ jsx("td", { className: "py-1 pr-2", children: /* @__PURE__ */ jsx(
                    StatusBadge,
                    {
                      color: it.action === "error" ? "red" : it.action === "unchanged" ? "grey" : "green",
                      children: it.action
                    }
                  ) }),
                  /* @__PURE__ */ jsx("td", { className: "py-1", children: it.error ?? it.detail ?? "" })
                ] }, i)) })
              ] })
            ]
          }
        );
      })()
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-3", children: "Retry & timeouts" }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Request timeout (ms)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              type: "number",
              min: 1e3,
              max: 12e4,
              value: timeoutMs,
              onChange: (e) => setTimeoutMs(Number(e.target.value) || 0)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Auto-retry max attempts" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              type: "number",
              min: 1,
              max: 100,
              value: retryMax,
              onChange: (e) => setRetryMax(Number(e.target.value) || 0)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Auto-retry interval (min)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              type: "number",
              min: 1,
              max: 1440,
              value: retryInterval,
              onChange: (e) => setRetryInterval(Number(e.target.value) || 0)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-subtle", children: "Auto-retry failed events" }),
        /* @__PURE__ */ jsx(Switch, { checked: autoRetry, onCheckedChange: setAutoRetry })
      ] })
    ] }),
    freshSecret && /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-tag-green-border bg-ui-tag-green-bg p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-2", children: "New secret generated" }),
      /* @__PURE__ */ jsx(Text, { className: "mb-2 text-xs", children: "Shown once; it is stored masked. Save, then run Set up ERPNext and it is written into every Webhook row for you. Copy it only if you maintain the webhooks by hand (Webhook → Webhook Secret)." }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Input, { readOnly: true, value: freshSecret, className: "font-mono text-xs" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            onClick: () => navigator.clipboard?.writeText(freshSecret),
            children: "Copy"
          }
        ),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "transparent", onClick: () => setFreshSecret(null), children: "Done" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-3", children: "Sync log retention" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(
          Input,
          {
            type: "number",
            min: 0,
            max: 1825,
            value: logRetentionDays,
            onChange: (e) => setLogRetentionDays(Number(e.target.value)),
            className: "w-32"
          }
        ),
        /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-subtle", children: "days" })
      ] }),
      /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: "How long every sync attempt — succeeded, failed and skipped — stays queryable in the Events tab. Default 180 days. Set 0 to keep forever, but note these rows carry the synced payload, so on a Customer mapping that is a second copy of personal data." })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-3", children: "Outbound allowlist" }),
      /* @__PURE__ */ jsxs(Text, { className: "mb-2 text-xs text-ui-fg-subtle", children: [
        "Leave empty to sync every record — that is the normal setting. When this has entries, ONLY records matching one of them are pushed to ERPNext; everything else is skipped and shown in the Events tab as ",
        /* @__PURE__ */ jsx("code", { children: "not_in_allowlist" }),
        ". Use it when this Medusa points at a non-production ERPNext and you want the real path exercised on a few records without sending everyone's personal data there. One per line — a customer id, email, product handle, order display id, or external id. Decoy records are always excluded regardless of this setting."
      ] }),
      /* @__PURE__ */ jsx(
        Textarea,
        {
          rows: 4,
          value: pushAllowlist,
          onChange: (e) => setPushAllowlist(e.target.value),
          placeholder: "cus_01ABC…\nsomeone@example.com\nINE0DJ201029"
        }
      ),
      pushAllowlist.trim() && /* @__PURE__ */ jsxs(Text, { className: "mt-2 text-xs text-ui-tag-orange-text", children: [
        "Restricted: only",
        " ",
        pushAllowlist.split(/[\n,;]+/).filter((x) => x.trim()).length,
        " ",
        "record(s) will sync outbound. Clear this box to resume full sync."
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-3", children: "Notes" }),
      /* @__PURE__ */ jsx(
        Textarea,
        {
          rows: 3,
          value: notes,
          onChange: (e) => setNotes(e.target.value),
          placeholder: "Anything ops should know about this Frappe instance…"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Pushing to ERPNext" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: "Where a document the store writes lands. Every field is optional: blank means ERPNext's own default (the default Company, the Selling Settings price list, no customer group or territory). GST is ERPNext's: India Compliance picks the taxes template for the place of supply, and each line is taxed at its Item Tax Template. Shipping goes on the shipping account ahead of the GST rows, so it is taxed at the rates of the goods it carries; without a shipping account it is not booked and the sync row says so." }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-3", children: [
        [
          ["erpnext_company", "Company", "Global Defaults → Default Company"],
          ["erpnext_price_list", "Selling price list", "Selling Settings → Default Price List"],
          ["erpnext_customer_group", "Customer group for new customers", "ERPNext default"],
          ["erpnext_territory", "Territory for new customers", "ERPNext default"],
          ["erpnext_shipping_account", "Shipping account head", "not booked"]
        ].map(([key, label, fallback]) => /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: label }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: pushCfg[key],
              onChange: (e) => setPushCfg((c) => ({ ...c, [key]: e.target.value })),
              placeholder: fallback
            }
          )
        ] }, key)),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "A store order becomes" }),
          /* @__PURE__ */ jsxs(Select, { value: orderDocument, onValueChange: (v) => setOrderDocument(v), children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
            /* @__PURE__ */ jsxs(Select.Content, { children: [
              /* @__PURE__ */ jsx(Select.Item, { value: "Sales Order", children: "Sales Order only" }),
              /* @__PURE__ */ jsx(Select.Item, { value: "Sales Order and Sales Invoice", children: "Sales Order, and a Sales Invoice once paid" }),
              /* @__PURE__ */ jsx(Select.Item, { value: "Sales Invoice", children: "Sales Invoice only, once paid" })
            ] })
          ] }),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Documents are created as drafts; an ERPNext user submits them, unless payments are recorded (below)." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Stock and prices from ERPNext" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: "ERPNext owns both. A store may sell what is on hand at its warehouse less what Sales Orders already promise less a safety buffer; the level lands on the stock location below. A selling price on the price list above becomes the variant's price in that currency. Both arrive on Webhooks that Set up ERPNext creates once switched on, and the hourly reconcile re-reads every linked Item." }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Switch, { checked: stockCfg.sync_stock, onCheckedChange: (v) => setStockCfg((c) => ({ ...c, sync_stock: Boolean(v) })) }),
          /* @__PURE__ */ jsx(Label, { children: "Move stock levels" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Switch, { checked: stockCfg.sync_prices, onCheckedChange: (v) => setStockCfg((c) => ({ ...c, sync_prices: Boolean(v) })) }),
          /* @__PURE__ */ jsx(Label, { children: "Move selling prices" })
        ] }),
        /* @__PURE__ */ jsx("div", {}),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "ERPNext warehouse" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: stockCfg.erpnext_warehouse,
              onChange: (e) => setStockCfg((c) => ({ ...c, erpnext_warehouse: e.target.value })),
              placeholder: "Stores - ABC"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Medusa stock location id" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: stockCfg.medusa_stock_location_id,
              onChange: (e) => setStockCfg((c) => ({ ...c, medusa_stock_location_id: e.target.value })),
              placeholder: "sloc_…"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Safety stock held back" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              type: "number",
              min: 0,
              value: stockCfg.erpnext_safety_stock,
              onChange: (e) => setStockCfg((c) => ({ ...c, erpnext_safety_stock: e.target.value }))
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "An Item's own safety stock wins when it has one." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", onClick: refreshStockPrices, isLoading: refreshing, disabled: !stockCfg.sync_stock && !stockCfg.sync_prices, children: "Refresh stock and prices now" }),
        refreshResult ? /* @__PURE__ */ jsx(Text, { size: "small", children: refreshResult }) : null
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Invoices for customers" }),
      /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: [
        "What an order becomes in ERPNext is set above under ",
        /* @__PURE__ */ jsx("strong", { children: "Pushing to ERPNext" }),
        " ",
        "(currently: ",
        /* @__PURE__ */ jsx("strong", { children: orderDocument }),
        "). ERPNext numbers its invoices. This switch gives customers the ERPNext invoice: once ERPNext submits it, the PDF in Sales Invoice's default print format is fetched, kept in the storage set below, and served only to the signed-in customer whose order it is. A draft is never offered. Press Set up ERPNext after switching it on, so the invoice's submit and cancel reach the store at once."
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Switch, { checked: sendInvoice, onCheckedChange: (v) => setSendInvoice(Boolean(v)) }),
        /* @__PURE__ */ jsx(Label, { children: "Customers can download ERPNext invoices" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Payments into ERPNext" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: "When on, an order paid online has its Sales Order and Sales Invoice submitted once the payment is captured, and a submitted Payment Entry books the payment to the Mode of Payment below; ERPNext takes the account from that mode's default for the company. A cash-on-delivery order has its Sales Order submitted when placed; its invoice stays a draft until the cash is recorded in ERPNext. A cancelled order, or a payment refunded in full, cancels the Payment Entry, the invoice and the order. A partial refund is noted on the sync event and left to ERPNext." }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
        /* @__PURE__ */ jsx(Switch, { checked: recordPayments, onCheckedChange: (v) => setRecordPayments(Boolean(v)) }),
        /* @__PURE__ */ jsx(Label, { children: "Record payments in ERPNext" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
        paymentModes.map((row, i) => /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-2 md:grid-cols-3", children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              value: row.provider,
              placeholder: "Payment provider id, e.g. pp_cashfree-pg",
              onChange: (e) => setPaymentModes((rows) => rows.map((r, j) => j === i ? { ...r, provider: e.target.value } : r))
            }
          ),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: row.mode,
              placeholder: "Mode of Payment, e.g. Cashfree",
              onChange: (e) => setPaymentModes((rows) => rows.map((r, j) => j === i ? { ...r, mode: e.target.value } : r))
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: "transparent",
              onClick: () => setPaymentModes((rows) => rows.filter((_, j) => j !== i)),
              children: "Remove"
            }
          )
        ] }, i)),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            onClick: () => setPaymentModes((rows) => [...rows, { provider: "", mode: "" }]),
            children: "Add a provider"
          }
        ) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Gateway settlements into ERPNext" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: "When on, each payout a gateway reports (Cashfree's settlement) clears the account its payments were received into, the default account of the gateway's Mode of Payment: a Purchase Invoice from the gateway for its fee and the GST on it, paid from that account, and a Journal Entry moving the net payout to the bank account below, with the UTR as reference. ERPNext picks the GST from the supplier's GSTIN and address, so fill both on the supplier for the input tax credit. A settlement with chargebacks or adjustments books nothing and fails its sync event; book it by hand. Set up ERPNext creates the supplier, the service item and the expense account when they are missing." }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
        /* @__PURE__ */ jsx(Switch, { checked: bookSettlements, onCheckedChange: (v) => setBookSettlements(Boolean(v)) }),
        /* @__PURE__ */ jsx(Label, { children: "Book gateway settlements in ERPNext" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2 mb-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Bank account the payouts land in" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              value: settlementBank,
              placeholder: "ERPNext Account, e.g. IDFC Current - SGPL",
              onChange: (e) => setSettlementBank(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 pt-5", children: [
          /* @__PURE__ */ jsx(Switch, { checked: createSettlementBank, onCheckedChange: (v) => setCreateSettlementBank(Boolean(v)) }),
          /* @__PURE__ */ jsx(Label, { children: "Set up ERPNext creates it under Bank Accounts when missing" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
        gatewayRows.map((row, i) => {
          const set = (patch) => setGatewayRows((rows) => rows.map((r, j) => j === i ? { ...r, ...patch } : r));
          return /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-2 md:grid-cols-6", children: [
            /* @__PURE__ */ jsx(Input, { value: row.provider, placeholder: "Gateway, e.g. cashfree", onChange: (e) => set({ provider: e.target.value }) }),
            /* @__PURE__ */ jsx(Input, { value: row.supplier, placeholder: "Supplier", onChange: (e) => set({ supplier: e.target.value }) }),
            /* @__PURE__ */ jsx(Input, { value: row.item, placeholder: "Service item", onChange: (e) => set({ item: e.target.value }) }),
            /* @__PURE__ */ jsx(Input, { value: row.gst_hsn_code, placeholder: "HSN/SAC", onChange: (e) => set({ gst_hsn_code: e.target.value }) }),
            /* @__PURE__ */ jsx(
              Input,
              {
                value: row.mode_of_payment,
                placeholder: "Mode of Payment (from the map above)",
                onChange: (e) => set({ mode_of_payment: e.target.value })
              }
            ),
            /* @__PURE__ */ jsx(Button, { size: "small", variant: "transparent", onClick: () => setGatewayRows((rows) => rows.filter((_, j) => j !== i)), children: "Remove" })
          ] }, i);
        }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            onClick: () => setGatewayRows((rows) => [...rows, { provider: "", supplier: "", item: "", gst_hsn_code: "", mode_of_payment: "" }]),
            children: "Add a gateway"
          }
        ) }),
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "The HSN/SAC is put on the service item only when Set up ERPNext creates it; 997158 is a placeholder to confirm against the gateway's tax invoices." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Invoice storage" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: "Invoice PDFs are never public. They are served only to the signed-in customer whose order they belong to." }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Keep invoices in" }),
          /* @__PURE__ */ jsxs(Select, { value: invoiceStorage, onValueChange: (v) => setInvoiceStorage(v), children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
            /* @__PURE__ */ jsxs(Select.Content, { children: [
              /* @__PURE__ */ jsx(Select.Item, { value: "local", children: "A private folder on this server" }),
              /* @__PURE__ */ jsx(Select.Item, { value: "s3", children: "S3-compatible bucket" })
            ] })
          ] })
        ] }),
        invoiceStorage === "local" ? /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Folder" }),
          /* @__PURE__ */ jsx(Input, { value: localDir, onChange: (e) => setLocalDir(e.target.value), placeholder: "private/erpnext-invoices" }),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Must not be inside the public static folder. Blank uses private/erpnext-invoices." })
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { children: "Bucket" }),
            /* @__PURE__ */ jsx(Input, { value: s3Bucket, onChange: (e) => setS3Bucket(e.target.value) })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { children: "Region" }),
            /* @__PURE__ */ jsx(Input, { value: s3Region, onChange: (e) => setS3Region(e.target.value), placeholder: "ap-south-1" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { children: "Endpoint" }),
            /* @__PURE__ */ jsx(Input, { value: s3Endpoint, onChange: (e) => setS3Endpoint(e.target.value), placeholder: "Blank for AWS" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { children: "Key prefix" }),
            /* @__PURE__ */ jsx(Input, { value: s3Prefix, onChange: (e) => setS3Prefix(e.target.value), placeholder: "invoices" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Access key id" }),
              /* @__PURE__ */ jsx(StatusBadge, { color: view.s3_access_key_id_masked ? "green" : "grey", children: view.s3_access_key_id_masked ? "set" : "not set" })
            ] }),
            /* @__PURE__ */ jsx(Input, { value: s3KeyId, onChange: (e) => setS3KeyId(e.target.value), placeholder: view.s3_access_key_id_masked ?? "Not set" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Secret access key" }),
              /* @__PURE__ */ jsx(StatusBadge, { color: view.s3_secret_access_key_masked ? "green" : "grey", children: view.s3_secret_access_key_masked ? "set" : "not set" })
            ] }),
            /* @__PURE__ */ jsx(Input, { type: "password", value: s3Secret, onChange: (e) => setS3Secret(e.target.value), placeholder: view.s3_secret_access_key_masked ?? "Not set" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Switch, { checked: s3PathStyle, onCheckedChange: setS3PathStyle }),
            /* @__PURE__ */ jsx(Label, { children: "Path-style addressing (MinIO and some S3-compatible services)" })
          ] })
        ] })
      ] })
    ] })
  ] });
};
const PULL_DOCTYPE_CHOICES = ["Customer", "Item", "Sales Order"];
const DOCTYPE_ALIASES = {
  customer: "Customer",
  customers: "Customer",
  item: "Item",
  items: "Item",
  product: "Item",
  products: "Item",
  "sales order": "Sales Order",
  salesorder: "Sales Order",
  "sales orders": "Sales Order",
  order: "Sales Order",
  orders: "Sales Order"
};
function normalizeDoctype(raw) {
  const trimmed = raw.trim();
  return DOCTYPE_ALIASES[trimmed.toLowerCase()] ?? trimmed;
}
const PullTab = () => {
  const [doctype, setDoctype] = useState("Customer");
  const [customDoctype, setCustomDoctype] = useState(false);
  const [limit, setLimit] = useState(50);
  const [fields, setFields] = useState("");
  const [filters, setFilters] = useState("");
  const [running, setRunning] = useState(false);
  const [items, setItems] = useState(null);
  const [err, setErr] = useState(null);
  const [doctypes, setDoctypes] = useState([]);
  const [dtSearch, setDtSearch] = useState("");
  const [dtLoading, setDtLoading] = useState(false);
  const [dtError, setDtError] = useState(null);
  const loadDoctypes = async (search) => {
    setDtLoading(true);
    setDtError(null);
    try {
      const url = search ? `/admin/erpnext/doctypes?search=${encodeURIComponent(search)}&limit=200` : `/admin/erpnext/doctypes?limit=5000`;
      const res = await fetch(url, { credentials: "include" });
      const body = await res.json();
      if (!res.ok || body?.ok === false) {
        setDoctypes([]);
        setDtError(friendlyErpError(body?.message || `HTTP ${res.status}`));
        return;
      }
      setDoctypes((body.items ?? []).map((i) => i.name));
    } catch (e) {
      setDoctypes([]);
      setDtError(friendlyErpError(e?.message));
    } finally {
      setDtLoading(false);
    }
  };
  useEffect(() => {
    loadDoctypes("");
  }, []);
  const run = async () => {
    setRunning(true);
    setErr(null);
    setItems(null);
    try {
      const body = { doctype: normalizeDoctype(doctype), limit };
      if (fields.trim()) {
        body.fields = fields.split(",").map((s) => s.trim()).filter(Boolean);
      }
      if (filters.trim()) {
        try {
          body.filters = JSON.parse(filters);
        } catch {
          throw new Error("filters must be valid JSON");
        }
      }
      const res = await fetch("/admin/erpnext/pull/items", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok || data.ok === false) {
        throw new Error(data.message || "pull_failed");
      }
      setItems(data.items ?? []);
    } catch (e) {
      setErr(friendlyErpError(e instanceof Error ? e.message : "pull_failed"));
    } finally {
      setRunning(false);
    }
  };
  return /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
    /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Pull from ERPNext" }),
    /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle mb-3", children: [
      "Read-only preview against",
      " ",
      /* @__PURE__ */ jsxs("code", { className: "font-mono", children: [
        "/api/resource/",
        `<doctype>`
      ] }),
      ". Uses the API key/secret from settings. Response is shown raw — the write- back-to-Medusa step is intentionally separate (operator decides the field mapping)."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-3 md:grid-cols-3", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Doctype" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: dtLoading ? "loading doctypes…" : doctypes.length ? "search doctypes…" : "—",
            value: dtSearch,
            disabled: !doctypes.length && !dtLoading,
            onChange: (e) => {
              setDtSearch(e.target.value);
              loadDoctypes(e.target.value);
            }
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "mt-1 w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm disabled:opacity-50",
            value: customDoctype ? "__other__" : doctype,
            disabled: !doctypes.length && !dtLoading,
            onChange: (e) => {
              if (e.target.value === "__other__") {
                setCustomDoctype(true);
                setDoctype("");
              } else {
                setCustomDoctype(false);
                setDoctype(e.target.value);
              }
            },
            children: [
              /* @__PURE__ */ jsx("optgroup", { label: "Common", children: PULL_DOCTYPE_CHOICES.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, `c-${d}`)) }),
              doctypes.length > 0 && /* @__PURE__ */ jsx("optgroup", { label: "All doctypes on this site", children: doctypes.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, d)) }),
              /* @__PURE__ */ jsx("option", { value: "__other__", children: "Other… (type exact name)" })
            ]
          }
        ),
        customDoctype && /* @__PURE__ */ jsx(
          Input,
          {
            className: "mt-2",
            value: doctype,
            onChange: (e) => setDoctype(e.target.value),
            placeholder: "Exact Frappe doctype, e.g. Address"
          }
        ),
        dtError && /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-error", children: dtError })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Limit" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            type: "number",
            min: 1,
            max: 500,
            value: limit,
            onChange: (e) => setLimit(Number(e.target.value) || 0)
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Fields (comma-separated, optional)" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: fields,
            onChange: (e) => setFields(e.target.value),
            placeholder: "name, item_code, item_name"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-3", children: [
      /* @__PURE__ */ jsx(Label, { children: "Filters (Frappe JSON, optional)" }),
      /* @__PURE__ */ jsx(
        Textarea,
        {
          rows: 2,
          value: filters,
          onChange: (e) => setFilters(e.target.value),
          placeholder: '[["disabled","=",0]]'
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center gap-2", children: [
      /* @__PURE__ */ jsx(Button, { onClick: run, disabled: running, variant: "primary", children: running ? "Pulling…" : "Pull" }),
      items && /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
        items.length,
        " row(s)"
      ] }),
      err && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-red-600", children: err })
    ] }),
    items && items.length > 0 && /* @__PURE__ */ jsx("pre", { className: "mt-4 max-h-96 overflow-auto rounded bg-ui-bg-subtle p-3 text-xs", children: JSON.stringify(items, null, 2) })
  ] });
};
const EventsTab = () => {
  const [status, setStatus] = useState("");
  const [showTests, setShowTests] = useState("real");
  const [rows, setRows] = useState(null);
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);
  const [retryingId, setRetryingId] = useState(null);
  const refresh = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      const qs = new URLSearchParams();
      if (status) qs.set("status", status);
      if (showTests === "real") qs.set("is_test", "0");
      if (showTests === "tests") qs.set("is_test", "1");
      qs.set("limit", "100");
      const res = await fetch(`/admin/erpnext/events?${qs}`, {
        credentials: "include"
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "load_failed");
      setRows(data.items);
      setCount(data.count);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "load_failed");
    } finally {
      setLoading(false);
    }
  }, [status, showTests]);
  useEffect(() => {
    refresh();
  }, [refresh]);
  const retry = async (eventId) => {
    setRetryingId(eventId);
    try {
      const res = await fetch(
        `/admin/erpnext/events/${encodeURIComponent(eventId)}/retry`,
        { method: "POST", credentials: "include" }
      );
      await res.json().catch(() => ({}));
    } finally {
      setRetryingId(null);
      refresh();
    }
  };
  return /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Sync events" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        ["real", "all", "tests"].map((s) => /* @__PURE__ */ jsx(
          Button,
          {
            variant: showTests === s ? "primary" : "secondary",
            size: "small",
            onClick: () => setShowTests(s),
            children: s === "real" ? "Real" : s === "tests" ? "Rehearsals" : "Both"
          },
          s
        )),
        /* @__PURE__ */ jsx("span", { className: "mx-1 text-ui-fg-muted", children: "|" }),
        ["", "pending", "success", "failed", "skipped"].map(
          (s) => /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: status === s ? "primary" : "secondary",
              onClick: () => setStatus(s),
              children: s || "all"
            },
            s || "all"
          )
        ),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", onClick: refresh, children: "↻" })
      ] })
    ] }),
    loading && /* @__PURE__ */ jsx(Text, { children: "Loading…" }),
    err && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-red-600", children: err }),
    rows && rows.length === 0 && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-subtle", children: "No events." }),
    rows && rows.length > 0 && /* @__PURE__ */ jsxs("div", { className: "overflow-auto", children: [
      /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b border-ui-border-base text-ui-fg-subtle", children: [
          /* @__PURE__ */ jsx("th", { className: "py-2 text-left", children: "Event" }),
          /* @__PURE__ */ jsx("th", { className: "py-2 text-left", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "py-2 text-left", children: "Attempts" }),
          /* @__PURE__ */ jsx("th", { className: "py-2 text-left", children: "Last attempt" }),
          /* @__PURE__ */ jsx("th", { className: "py-2 text-left", children: "Last error" }),
          /* @__PURE__ */ jsx("th", { className: "py-2 text-right", children: "Action" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: rows.map((r) => /* @__PURE__ */ jsxs("tr", { className: "border-b border-ui-border-base", children: [
          /* @__PURE__ */ jsxs("td", { className: "py-2", children: [
            /* @__PURE__ */ jsx("code", { className: "font-mono text-xs", children: r.event }),
            /* @__PURE__ */ jsx("div", { className: "text-ui-fg-subtle text-xs", children: r.event_id })
          ] }),
          /* @__PURE__ */ jsx("td", { className: "py-2", children: /* @__PURE__ */ jsx(StatusBadge, { color: statusColor(r.status), children: r.status }) }),
          /* @__PURE__ */ jsx("td", { className: "py-2", children: r.attempts }),
          /* @__PURE__ */ jsx("td", { className: "py-2", children: r.last_attempt_at ? new Date(r.last_attempt_at).toLocaleString() : "—" }),
          /* @__PURE__ */ jsx("td", { className: "py-2 max-w-xs truncate", title: r.last_error ?? "", children: r.last_error ?? "—" }),
          /* @__PURE__ */ jsx("td", { className: "py-2 text-right", children: /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: "secondary",
              disabled: retryingId === r.event_id,
              onClick: () => retry(r.event_id),
              children: retryingId === r.event_id ? "…" : "Retry"
            }
          ) })
        ] }, r.id)) })
      ] }),
      /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle mt-2", children: [
        "Showing ",
        rows.length,
        " of ",
        count
      ] })
    ] })
  ] });
};
function statusColor(s) {
  switch (s) {
    case "success":
      return "green";
    case "failed":
      return "red";
    case "pending":
      return "orange";
    default:
      return "grey";
  }
}
const FILTER_OPS = [
  { value: "=", label: "is" },
  { value: "!=", label: "is not" },
  { value: "like", label: "contains" },
  { value: "not like", label: "does not contain" },
  { value: ">", label: "is after / greater than" },
  { value: "<", label: "is before / less than" },
  { value: ">=", label: "is at least" },
  { value: "<=", label: "is at most" },
  { value: "in", label: "is one of (comma separated)" },
  { value: "not in", label: "is none of (comma separated)" },
  { value: "is", label: "is set / not set" }
];
const PullFilterBuilder = ({ value, fields, onChange }) => {
  const rows = Array.isArray(value) ? value : [];
  const write = (next) => onChange(next.length ? next : null);
  const setCell = (i, pos, v) => {
    const next = rows.map((r, j) => j === i ? [...r] : r);
    next[i][pos] = v;
    write(next);
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
    rows.map((r, i) => {
      const op = String(r?.[1] ?? "=");
      const isSetOp = op === "is";
      return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("div", { className: "flex-1", children: /* @__PURE__ */ jsxs(Select, { value: String(r?.[0] ?? ""), onValueChange: (v) => setCell(i, 0, v), children: [
          /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "Field" }) }),
          /* @__PURE__ */ jsx(Select.Content, { children: fields.map((f) => /* @__PURE__ */ jsxs(Select.Item, { value: f.fieldname, children: [
            f.label || f.fieldname,
            " · ",
            f.fieldname
          ] }, f.fieldname)) })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "w-56", children: /* @__PURE__ */ jsxs(Select, { value: op, onValueChange: (v) => setCell(i, 1, v), children: [
          /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "is" }) }),
          /* @__PURE__ */ jsx(Select.Content, { children: FILTER_OPS.map((o) => /* @__PURE__ */ jsx(Select.Item, { value: o.value, children: o.label }, o.value)) })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "flex-1", children: isSetOp ? /* @__PURE__ */ jsxs(Select, { value: String(r?.[2] ?? "set"), onValueChange: (v) => setCell(i, 2, v), children: [
          /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "set" }) }),
          /* @__PURE__ */ jsxs(Select.Content, { children: [
            /* @__PURE__ */ jsx(Select.Item, { value: "set", children: "set" }),
            /* @__PURE__ */ jsx(Select.Item, { value: "not set", children: "not set" })
          ] })
        ] }) : /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: "Value",
            value: String(r?.[2] ?? ""),
            onChange: (e) => setCell(i, 2, e.target.value)
          }
        ) }),
        /* @__PURE__ */ jsx(
          Button,
          {
            variant: "secondary",
            size: "small",
            onClick: () => write(rows.filter((_, j) => j !== i)),
            children: "Remove"
          }
        )
      ] }, i);
    }),
    /* @__PURE__ */ jsx(
      Button,
      {
        variant: "secondary",
        size: "small",
        onClick: () => write([...rows, ["", "=", ""]]),
        children: "Add a condition"
      }
    )
  ] });
};
function cleanPairs(pairs) {
  const out = [];
  for (const p of pairs) {
    if (p.constant !== void 0 && !constantHasValue(p.constant)) continue;
    const next = { ...p };
    if (next.constant_pull !== void 0 && !constantHasValue(next.constant_pull)) delete next.constant_pull;
    for (const k of ["transform", "transform_push", "transform_pull"]) {
      if (next[k] !== void 0 && String(next[k] ?? "").trim() === "") delete next[k];
    }
    if (!next.medusa_path && !next.erpnext_field && next.constant === void 0 && next.constant_pull === void 0) continue;
    out.push(next);
  }
  return out;
}
function requiredCoverage(direction, pairs, mappingDirection, required) {
  const covered = /* @__PURE__ */ new Set();
  for (const p of pairs ?? []) {
    const effective = String(p.direction ?? mappingDirection);
    if (!(effective === "both" || effective === direction)) continue;
    const fixed = direction === "push" ? p.constant : p.constant_pull;
    const fallback = (direction === "push" ? p.default_push : p.default_pull) ?? p.default;
    const hasSource = fixed !== void 0 ? constantHasValue(fixed) : fallback !== void 0 || Boolean(direction === "push" ? p.medusa_path : p.erpnext_field);
    if (!hasSource) continue;
    const target = direction === "push" ? p.erpnext_field : p.medusa_path;
    if (target) covered.add(target);
  }
  return required.map((f) => ({ ...f, covered: covered.has(f.name) }));
}
const RequiredBoxes = ({ direction, pairs, erpRequired, medusaRequired, storeKnown, doctype, onAddErp, onAddMedusa }) => {
  const toErp = direction === "push" || direction === "both";
  const toMedusa = direction === "pull" || direction === "both";
  if (!toErp && !toMedusa) return null;
  const box = (title, rows, emptyNote, onAdd) => {
    const missing = rows.filter((r) => !r.covered);
    return /* @__PURE__ */ jsxs("div", { className: "rounded border border-ui-border-base p-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Text, { weight: "plus", children: title }),
        /* @__PURE__ */ jsx(Text, { className: "text-xs text-ui-fg-subtle", children: rows.length === 0 ? "" : missing.length ? `${missing.length} missing` : "all covered" })
      ] }),
      rows.length === 0 ? /* @__PURE__ */ jsx(Text, { className: "text-xs text-ui-fg-subtle", children: emptyNote }) : rows.map(
        (r) => r.covered ? /* @__PURE__ */ jsxs("div", { className: "flex gap-2 text-sm text-ui-fg-base", children: [
          /* @__PURE__ */ jsx("span", { children: "✓" }),
          /* @__PURE__ */ jsxs("span", { children: [
            r.label,
            " ",
            /* @__PURE__ */ jsxs("span", { className: "text-ui-fg-subtle", children: [
              "· ",
              r.name
            ] })
          ] })
        ] }, r.name) : (
          // A missing field is a button: one click adds that one pair.
          /* @__PURE__ */ jsxs(
            "button",
            {
              type: "button",
              title: "Add this field to the mapping",
              onClick: () => onAdd([r.name]),
              className: "my-0.5 flex w-full gap-2 rounded border border-dashed border-ui-border-base px-2 py-0.5 text-left text-sm text-ui-fg-error hover:border-solid hover:bg-ui-bg-base-hover",
              children: [
                /* @__PURE__ */ jsx("span", { children: "＋" }),
                /* @__PURE__ */ jsxs("span", { children: [
                  r.label,
                  " ",
                  /* @__PURE__ */ jsxs("span", { className: "text-ui-fg-subtle", children: [
                    "· ",
                    r.name
                  ] })
                ] })
              ]
            },
            r.name
          )
        )
      ),
      missing.length > 1 && /* @__PURE__ */ jsxs(
        Button,
        {
          size: "small",
          variant: "secondary",
          className: "mt-2",
          onClick: () => onAdd(missing.map((m) => m.name)),
          children: [
            "Add all ",
            missing.length
          ]
        }
      )
    ] });
  };
  return /* @__PURE__ */ jsxs("div", { className: "mt-6 grid gap-3 md:grid-cols-2", children: [
    toErp && box(
      "Required in ERPNext",
      requiredCoverage("push", pairs, direction, erpRequired),
      `${doctype || "This doctype"} has no mandatory field this mapping has to fill.`,
      onAddErp
    ),
    toMedusa && box(
      "Required in Medusa",
      requiredCoverage("pull", pairs, direction, medusaRequired),
      storeKnown ? "The store reports no field it cannot create this record without." : "The store's model could not be read, so what it requires is unknown.",
      onAddMedusa
    )
  ] });
};
function groupForPicker(fields, opts) {
  const visible = fields.filter((f) => opts.showAll || !f.advanced || f.path === opts.keep);
  const groups = [];
  const add = (label, f) => {
    let g = groups.find((x) => x.label === label);
    if (!g) {
      g = { label, fields: [] };
      groups.push(g);
    }
    g.fields.push(f);
  };
  for (const f of visible) if (f.required) add("Required", f);
  for (const f of visible) if (!f.required) add(f.group || opts.ownLabel, f);
  return groups;
}
const CONFIDENCE_META = {
  canonical: { label: "canonical", color: "green" },
  composite: { label: "combined", color: "blue" },
  exact: { label: "exact", color: "green" },
  synonym: { label: "synonym", color: "blue" },
  strong: { label: "likely", color: "grey" },
  weak: { label: "check this", color: "orange" },
  none: { label: "no match", color: "red" }
};
const CONSTANT_OPTIONS_LIMIT = 200;
function constantHasValue(constant) {
  if (constant === void 0) return false;
  if (typeof constant === "string") return constant.trim() !== "";
  return true;
}
async function fetchConstantOptions(doctype, field) {
  try {
    const r = await fetch(
      `/admin/erpnext/doctypes/${encodeURIComponent(doctype)}/options?` + new URLSearchParams({ field }).toString(),
      { credentials: "include" }
    );
    const b = await r.json();
    return b?.ok ? {
      options: b.options ?? [],
      fieldtype: b.fieldtype,
      truncated: b.truncated
    } : { options: [], error: b?.message ?? "unreachable" };
  } catch (err) {
    return { options: [], error: err?.message ?? "unreachable" };
  }
}
function useConstantOptions(doctype) {
  const [options, setOptions] = useState({});
  const generation = useRef(0);
  const asked = useRef({
    doctype: "",
    fields: /* @__PURE__ */ new Set()
  });
  const request = useCallback(
    (field) => {
      if (!field || !doctype) return;
      if (asked.current.doctype !== doctype) {
        asked.current = { doctype, fields: /* @__PURE__ */ new Set() };
        generation.current += 1;
        setOptions({});
      }
      if (asked.current.fields.has(field)) return;
      asked.current.fields.add(field);
      const mine = generation.current;
      setOptions((prev) => ({ ...prev, [field]: { options: [], loading: true } }));
      void fetchConstantOptions(doctype, field).then((meta) => {
        if (generation.current !== mine) return;
        setOptions((prev) => ({ ...prev, [field]: meta }));
      });
    },
    [doctype]
  );
  return { options, request };
}
const ConstantValueControl = ({ value, meta, hasField = true, hint, placeholder, onChange }) => {
  if (!hasField) {
    return /* @__PURE__ */ jsx("div", { className: "rounded border border-ui-border-base px-2 py-1.5 text-xs text-ui-fg-subtle", children: "Pick the ERPNext field first — the values on offer are that field's." });
  }
  const options = meta?.options ?? [];
  const orphan = Boolean(value) && options.length > 0 && !options.includes(value);
  const listed = meta?.fieldtype === "Link" || meta?.fieldtype === "Select";
  if (options.length) {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Select, { value, onValueChange: onChange, children: [
        /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "Choose from this ERPNext" }) }),
        /* @__PURE__ */ jsxs(Select.Content, { children: [
          orphan && /* @__PURE__ */ jsxs(Select.Item, { value, children: [
            value,
            " — not on this site"
          ] }),
          options.map((o) => /* @__PURE__ */ jsx(Select.Item, { value: o, children: o }, o))
        ] })
      ] }),
      (hint || orphan || meta?.truncated) && /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
        hint ? `${hint} ` : "",
        orphan ? "Saved earlier, and this ERPNext has no such record now. Syncs using it will fail until it exists or you pick another. " : "",
        meta?.truncated ? `Showing the first ${CONSTANT_OPTIONS_LIMIT}.` : ""
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      Input,
      {
        placeholder: placeholder ?? "Fixed value, sent every time",
        value,
        onChange: (e) => onChange(e.target.value)
      }
    ),
    /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
      hint ? `${hint} ` : "",
      meta?.loading ? "Reading the choices from ERPNext…" : meta?.error ? `Could not read the choices from ERPNext (${meta.error}) — type the value instead.` : listed ? "This ERPNext has no records to choose from yet, so it has to be created there first." : meta ? "This field takes free text." : ""
    ] })
  ] });
};
const DIRECTION_HELP = {
  push: "Medusa events write into ERPNext over the REST API with the API key in Settings. Customers get their Addresses; orders become a Sales Order and, once paid, a Sales Invoice, as drafts.",
  pull: "The webhooks Set up ERPNext installs deliver each selected document (ERPNext → Medusa or Both) as it changes, and a cron polls every 5 min for selected rows changed since the last run. Needs only the API key.",
  both: "Both of the above on the same record. Per-field overrides below decide which side owns each field — set a field to one-way to stop the other side overwriting it."
};
const TRIGGER_PRESETS = [
  {
    value: "always",
    label: "Always — every matching event",
    condition: "",
    help: "Sync on every event listed above, with no further filtering."
  },
  {
    value: "kyc_verified",
    label: "Only once KYC is fully verified",
    condition: "metadata.kyc_fully_approved_at is set",
    help: "Holds the record back until an admin has signed off every KYC check."
  },
  {
    value: "has_purchased",
    label: "Only once they have bought something",
    condition: "orders_count > 0",
    help: "Waits for a completed order — keeps browsers and abandoned signups out of ERPNext."
  },
  {
    value: "has_value",
    label: "Only once the key field has a value",
    condition: "",
    help: "Fires as soon as the key field is populated. Pair with ‘skip when nothing changed’ to sync each value as it is entered."
  },
  {
    value: "custom",
    label: "Custom condition",
    condition: "",
    help: 'Dot-paths are read off the record. e.g. metadata.kyc_status == "approved" and email is not empty'
  }
];
const TRANSFORM_OPTIONS = [
  { value: "", label: "(no transform)" },
  { value: "lowercase", label: "lowercase" },
  { value: "uppercase", label: "uppercase" },
  { value: "trim", label: "trim whitespace" },
  { value: "text", label: "→ text" },
  { value: "number", label: "→ number (skips what will not convert)" },
  { value: "integer", label: "→ integer (truncates)" },
  { value: "decimal:2", label: "→ decimal, 2 places" },
  { value: "boolean", label: "→ true/false" },
  { value: "check", label: "→ 1/0 (Frappe Check)" },
  { value: "phone", label: "→ phone in +91… form" },
  { value: "map:a=b,c=d", label: "translate values a→b, c→d (reversed on the way back)" },
  { value: "json", label: "→ JSON text" },
  { value: "parse_json", label: "JSON text → object" },
  { value: "split:,", label: "split by comma → array" },
  { value: "join:,", label: "join array by comma → string" },
  { value: "date_iso", label: "→ ISO datetime" },
  { value: "date_yyyy_mm_dd", label: "→ YYYY-MM-DD (site timezone)" },
  { value: "datetime_frappe", label: "→ YYYY-MM-DD HH:mm:ss (site timezone)" }
];
const MedusaValueControl = ({ entity, path, value, placeholder, onChange }) => {
  const [options, setOptions] = useState(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    let cancelled = false;
    setOptions(null);
    if (!entity || !path) return;
    setLoading(true);
    fetch(`/admin/erpnext/medusa-entities/${encodeURIComponent(entity)}/options?path=${encodeURIComponent(path)}`, {
      credentials: "include"
    }).then((r) => r.json()).then((b) => {
      if (!cancelled) setOptions(Array.isArray(b?.options) ? b.options : null);
    }).catch(() => {
      if (!cancelled) setOptions(null);
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [entity, path]);
  if (!path) {
    return /* @__PURE__ */ jsx("div", { className: "rounded border border-ui-border-base px-2 py-1.5 text-xs text-ui-fg-subtle", children: "Pick the store field first — the values on offer are that field's." });
  }
  if (options && options.length) {
    const orphan = Boolean(value) && !options.some((o) => o.value === value);
    return /* @__PURE__ */ jsxs(Select, { value, onValueChange: onChange, children: [
      /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "Choose from this store" }) }),
      /* @__PURE__ */ jsxs(Select.Content, { children: [
        orphan && /* @__PURE__ */ jsxs(Select.Item, { value, children: [
          value,
          " — not in this store"
        ] }),
        options.map((o) => /* @__PURE__ */ jsx(Select.Item, { value: o.value, children: o.label }, o.value))
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Input, { placeholder: placeholder ?? "Value", value, onChange: (e) => onChange(e.target.value) }),
    /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: loading ? "Reading the choices from the store…" : "This field takes free text." })
  ] });
};
const SYNC_PRESETS = [
  {
    key: "customers",
    emoji: "👤",
    title: "Customers",
    blurb: "Keep buyer accounts in step — the name and the link back to your store.",
    doctype: "Customer",
    medusa_entity: "customer",
    events: ["customer.created", "customer.updated", "customer.deleted"],
    // Keyed on the link field, not on email. ERPNext keeps `email_id` on
    // the linked Contact and refills the column from it, so a key built on
    // email changes underneath the mapping the moment a Contact is set.
    key_medusa_field: "email",
    key_erpnext_field: "email_id",
    defaultDirection: "both",
    directions: ["both", "push", "pull"],
    note: "A customer is matched by email. On the way out the name, type, email and phone are filled in even when unmapped, GST fields when your ERPNext has them, and the customer's addresses become linked Address documents.",
    fields: [
      { medusa_path: "email", erpnext_field: "email_id", direction: "both", transform: "lowercase", label: "Email", on: true },
      { medusa_path: "phone", erpnext_field: "mobile_no", direction: "both", transform: "phone", label: "Phone", on: true },
      { medusa_path: "{first_name} {last_name}", erpnext_field: "customer_name", direction: "push", label: "Name", on: true },
      {
        medusa_path: "",
        erpnext_field: "customer_type",
        direction: "push",
        label: "Customer type",
        on: true,
        constant: "",
        constantHint: "Mandatory on ERPNext, and a store has no equivalent."
      }
    ]
  },
  {
    key: "products",
    emoji: "📦",
    title: "Products",
    blurb: "Mirror your catalogue as ERPNext Items.",
    doctype: "Item",
    medusa_entity: "product",
    events: ["product.created", "product.updated", "product.deleted"],
    key_medusa_field: "handle",
    key_erpnext_field: "item_code",
    defaultDirection: "both",
    directions: ["both", "push", "pull"],
    note: "Item Group and Stock UOM are mandatory on an ERPNext Item and have no counterpart in a store, so they are sent as fixed values. The choices are read from your ERPNext.",
    fields: [
      { medusa_path: "handle", erpnext_field: "item_code", direction: "both", transform: "lowercase", label: "Code (URL handle)", on: true },
      { medusa_path: "title", erpnext_field: "item_name", direction: "both", label: "Name", on: true },
      { medusa_path: "description", erpnext_field: "description", direction: "push", label: "Description", on: true },
      {
        medusa_path: "",
        erpnext_field: "item_group",
        direction: "push",
        label: "Item group",
        on: true,
        constant: "",
        constantHint: "Mandatory on an ERPNext Item, and a store has no equivalent."
      },
      {
        medusa_path: "",
        erpnext_field: "stock_uom",
        direction: "push",
        label: "Stock UOM",
        on: true,
        constant: "",
        constantHint: "Mandatory on an ERPNext Item, and a store has no equivalent."
      }
    ]
  },
  {
    key: "orders",
    emoji: "🧾",
    title: "Orders",
    blurb: "Send each placed order to ERPNext as a Sales Order.",
    doctype: "Sales Order",
    medusa_entity: "order",
    events: ["order.placed", "order.payment_captured", "order.canceled"],
    key_medusa_field: "display_id",
    key_erpnext_field: "po_no",
    defaultDirection: "push",
    directions: ["push"],
    note: "Line items, the customer, the addresses and the amounts are attached automatically; the order number lands in the Sales Order's PO number. Once the order is paid a Sales Invoice is raised too, per Settings → Pushing to ERPNext. Orders always flow Medusa → ERPNext.",
    fields: [
      { medusa_path: "email", erpnext_field: "contact_email", direction: "push", label: "Customer email", on: true }
    ]
  }
];
const DIRECTION_CHOICE = {
  push: { label: "Medusa → ERPNext", help: "Changes in your store are written to ERPNext." },
  pull: { label: "ERPNext → Medusa", help: "Changes in ERPNext are pulled into your store." },
  both: { label: "Both ways", help: "Keep both sides in step. Per-field rules decide who wins each field." }
};
const ENTITY_DOCTYPE_SUGGESTIONS = {
  customer: ["Customer"],
  customer_group: ["Customer Group"],
  product: ["Item"],
  product_category: ["Item Group"],
  order: ["Sales Order"],
  currency: ["Currency"],
  user: ["User"],
  stock_location: ["Warehouse"],
  fulfillment: ["Delivery Note"],
  payment_collection: ["Payment Entry"],
  promotion: ["Pricing Rule"],
  region: ["Territory"]
};
function friendlyErpError(raw) {
  const s = String(raw ?? "");
  if (/econnrefused|refused|failed to fetch|networkerror|enotfound|etimedout|timeout|502|503|504|econnreset|socket hang up/i.test(
    s
  )) {
    return "ERPNext isn't reachable — is it running? Check the ERPNext server and the URL in the Settings tab.";
  }
  return s || "Something went wrong talking to ERPNext.";
}
const AddSyncWizard = ({ onDone, onAdvanced }) => {
  const [step, setStep] = useState(1);
  const [presetKey, setPresetKey] = useState(null);
  const [fields, setFields] = useState([]);
  const [direction, setDirection] = useState("both");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(null);
  const [stage, setStage] = useState(null);
  const [savedOff, setSavedOff] = useState(null);
  const [foldedInto, setFoldedInto] = useState(null);
  const preset = SYNC_PRESETS.find((p) => p.key === presetKey) || null;
  const choose = (p) => {
    setPresetKey(p.key);
    setFields(p.fields.map((f) => ({ ...f })));
    setDirection(p.defaultDirection);
    setName(`${p.title} ↔ ERPNext`);
    setError(null);
    setStep(2);
  };
  const blankConstants = fields.filter(
    (f) => f.on && f.constant !== void 0 && !constantHasValue(f.constant)
  );
  const { options: constantOptions, request: requestConstantOptions } = useConstantOptions(preset?.doctype);
  useEffect(() => {
    for (const f of preset?.fields ?? []) {
      if (f.constant !== void 0) requestConstantOptions(f.erpnext_field);
    }
  }, [preset?.key, requestConstantOptions]);
  const save = async () => {
    if (!preset) return;
    setBusy(true);
    setError(null);
    try {
      const field_mappings = fields.filter((f) => f.on).filter((f) => f.constant === void 0 || constantHasValue(f.constant)).map((f) => ({
        medusa_path: f.medusa_path,
        erpnext_field: f.erpnext_field,
        direction: f.direction,
        ...f.transform ? { transform: f.transform } : {},
        ...f.constant !== void 0 ? { constant: f.constant.trim() } : {}
      }));
      const draft = {
        name: name.trim() || `${preset.title} ↔ ERPNext`,
        medusa_entity: preset.medusa_entity,
        doctype: preset.doctype,
        direction,
        events: preset.events,
        trigger_preset: "always",
        trigger_condition: "",
        skip_unchanged: false,
        allow_create: true,
        allow_update: true,
        pull_filter: null,
        pull_page_size: 200,
        key_medusa_field: preset.key_medusa_field,
        key_erpnext_field: preset.key_erpnext_field,
        field_mappings
      };
      const res = await fetch("/admin/erpnext/mappings", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...draft, enabled: false, merge_into_pair: true })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || "Could not save");
      const id = body?.mapping?.id ?? body?.id ?? "";
      if (!id) throw new Error("Saved, but no mapping id came back");
      setFoldedInto(body?.mapping?.merged_into ? String(body.mapping.name ?? "") : null);
      setStage("rehearsing");
      const dryRes = await fetch(`/admin/erpnext/mappings/${id}/dry-run`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({})
      });
      const dry = await dryRes.json();
      if (!dry?.ok) {
        setSavedOff({ id, why: dry?.message ?? "the rehearsal did not pass" });
        return;
      }
      setStage("enabling");
      const onRes = await fetch("/admin/erpnext/mappings", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...draft, id, enabled: true })
      });
      const onBody = await onRes.json();
      if (!onRes.ok) {
        setSavedOff({ id, why: onBody?.message ?? "it could not be switched on" });
        return;
      }
      setDone({ id });
    } catch (e) {
      setError(e?.message ?? "Could not save");
    } finally {
      setBusy(false);
      setStage(null);
    }
  };
  const Dots = () => /* @__PURE__ */ jsx("div", { className: "mb-5 flex items-center gap-2 text-xs text-ui-fg-subtle", children: ["Choose", "Set up", "Review"].map((s, i) => /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsx(
      "span",
      {
        className: "flex h-5 w-5 items-center justify-center rounded-full text-[11px] " + (step >= i + 1 ? "bg-ui-bg-interactive text-ui-fg-on-color" : "bg-ui-bg-base-hover"),
        children: i + 1
      }
    ),
    /* @__PURE__ */ jsx("span", { className: step === i + 1 ? "text-ui-fg-base" : "", children: s }),
    i < 2 && /* @__PURE__ */ jsx("span", { className: "mx-1", children: "→" })
  ] }, s)) });
  if (done) {
    return /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-6 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-2 text-2xl", children: "✅" }),
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-1", children: "You're all set" }),
      /* @__PURE__ */ jsxs(Text, { className: "mb-4 text-ui-fg-subtle", children: [
        foldedInto ? `Added to “${foldedInto}”, which already kept these two in step — one sync per pair, so nothing was created beside it.` : `“${name}” is now syncing.`,
        " ",
        "You can fine-tune every detail any time from the mappings list."
      ] }),
      /* @__PURE__ */ jsx(Button, { variant: "primary", onClick: onDone, children: "Back to syncs" })
    ] });
  }
  if (savedOff) {
    return /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-6 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-2 text-2xl", children: "⚠️" }),
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-1", children: "Saved, but left switched off" }),
      /* @__PURE__ */ jsxs(Text, { className: "mb-4 text-ui-fg-subtle", children: [
        foldedInto ? `The fields were added to “${foldedInto}”` : `“${name}” was created`,
        " and nothing was sent anywhere. The rehearsal did not pass, so it has not been switched on: ",
        savedOff.why
      ] }),
      /* @__PURE__ */ jsx(Text, { className: "mb-4 text-ui-fg-subtle", children: "Open it in the advanced editor to see what the dry run reported, fix it, then use Test to switch it on." }),
      /* @__PURE__ */ jsx(Button, { variant: "primary", onClick: onDone, children: "Back to syncs" })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: onDone, children: "← Cancel" }),
      /* @__PURE__ */ jsx(Button, { variant: "transparent", size: "small", onClick: onAdvanced, children: "Advanced editor instead" })
    ] }),
    /* @__PURE__ */ jsx(Dots, {}),
    error && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error", children: error }),
    step === 1 && /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-1", children: "What do you want to keep in sync?" }),
      /* @__PURE__ */ jsx(Text, { className: "mb-4 text-ui-fg-subtle", children: "Pick one to start. You can add more later." }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-3", children: SYNC_PRESETS.map((p) => /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => choose(p),
          className: "rounded-lg border p-4 text-left transition hover:border-ui-border-interactive hover:bg-ui-bg-base-hover",
          children: [
            /* @__PURE__ */ jsx("div", { className: "mb-1 text-2xl", children: p.emoji }),
            /* @__PURE__ */ jsx("div", { className: "mb-1 font-medium", children: p.title }),
            /* @__PURE__ */ jsx(Text, { className: "text-xs text-ui-fg-subtle", children: p.blurb })
          ]
        },
        p.key
      )) })
    ] }),
    step === 2 && preset && /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(Heading, { level: "h2", className: "mb-1", children: [
          preset.emoji,
          " ",
          preset.title,
          " — which way should it sync?"
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3", children: preset.directions.map((d) => /* @__PURE__ */ jsxs(
          "button",
          {
            onClick: () => setDirection(d),
            className: "rounded-lg border p-3 text-left transition " + (direction === d ? "border-ui-border-interactive bg-ui-bg-base-hover" : "hover:bg-ui-bg-base-hover"),
            children: [
              /* @__PURE__ */ jsx("div", { className: "text-sm font-medium", children: DIRECTION_CHOICE[d].label }),
              /* @__PURE__ */ jsx(Text, { className: "text-xs text-ui-fg-subtle", children: DIRECTION_CHOICE[d].help })
            ]
          },
          d
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-1", children: "Which details should we keep in step?" }),
        /* @__PURE__ */ jsx(Text, { className: "mb-3 text-ui-fg-subtle", children: "These are matched up for you. Turn any off if you don't want it synced." }),
        /* @__PURE__ */ jsx("div", { className: "rounded-lg border divide-y", children: fields.filter((f) => !f.advanced).map((f, i) => {
          const realIdx = fields.indexOf(f);
          const isConstant = f.constant !== void 0;
          return /* @__PURE__ */ jsxs("div", { className: "p-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-sm", children: [
                /* @__PURE__ */ jsx("span", { className: "font-medium", children: f.label }),
                /* @__PURE__ */ jsx("span", { className: "text-ui-fg-subtle", children: isConstant ? /* @__PURE__ */ jsxs(Fragment, { children: [
                  "a fixed value → ERPNext ",
                  /* @__PURE__ */ jsx("code", { className: "text-xs", children: f.erpnext_field })
                ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                  "Medusa ",
                  /* @__PURE__ */ jsx("code", { className: "text-xs", children: f.medusa_path }),
                  " ↔ ERPNext ",
                  /* @__PURE__ */ jsx("code", { className: "text-xs", children: f.erpnext_field })
                ] }) })
              ] }),
              /* @__PURE__ */ jsx(
                Switch,
                {
                  checked: f.on,
                  onCheckedChange: (v) => setFields((arr) => arr.map((x, j) => j === realIdx ? { ...x, on: !!v } : x))
                }
              )
            ] }),
            isConstant && f.on && (() => {
              const meta = constantOptions[f.erpnext_field];
              const setConstant = (v) => setFields(
                (arr) => arr.map((x, j) => j === realIdx ? { ...x, constant: v } : x)
              );
              return /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
                ConstantValueControl,
                {
                  value: f.constant ?? "",
                  meta,
                  hint: f.constantHint,
                  placeholder: "Value to send every time",
                  onChange: setConstant
                }
              ) });
            })()
          ] }, i);
        }) }),
        fields.some((f) => f.advanced) && /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
          /* @__PURE__ */ jsxs(Button, { variant: "transparent", size: "small", onClick: () => setShowAdvanced((s) => !s), children: [
            showAdvanced ? "Hide" : "Show",
            " technical fields"
          ] }),
          showAdvanced && /* @__PURE__ */ jsx("div", { className: "mt-2 rounded-lg border divide-y", children: fields.filter((f) => f.advanced).map((f) => {
            const realIdx = fields.indexOf(f);
            return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-sm", children: [
                /* @__PURE__ */ jsx("span", { className: "font-medium", children: f.label }),
                /* @__PURE__ */ jsx("span", { className: "text-ui-fg-subtle", children: "keeps the two records linked — recommended" })
              ] }),
              /* @__PURE__ */ jsx(
                Switch,
                {
                  checked: f.on,
                  onCheckedChange: (v) => setFields((arr) => arr.map((x, j) => j === realIdx ? { ...x, on: !!v } : x))
                }
              )
            ] }, f.erpnext_field);
          }) })
        ] })
      ] }),
      preset.note && /* @__PURE__ */ jsx("div", { className: "rounded-lg border border-ui-border-base bg-ui-bg-subtle p-3", children: /* @__PURE__ */ jsxs(Text, { className: "text-xs text-ui-fg-subtle", children: [
        "ℹ️ ",
        preset.note
      ] }) }),
      blankConstants.length > 0 && /* @__PURE__ */ jsx("div", { className: "rounded-lg border border-ui-border-base bg-ui-bg-subtle p-3", children: /* @__PURE__ */ jsxs(Text, { className: "text-xs text-ui-fg-subtle", children: [
        "Still needs a value: ",
        blankConstants.map((f) => f.label).join(", "),
        ". ERPNext requires these and the store has nothing to fill them from, so the sync cannot run until you say what to send. Turn one off if you would rather leave it to ERPNext's own default."
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: () => setStep(1), children: "← Back" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            variant: "primary",
            onClick: () => setStep(3),
            disabled: blankConstants.length > 0,
            children: "Review →"
          }
        )
      ] })
    ] }),
    step === 3 && preset && /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Review & turn it on" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Name this sync" }),
        /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-4 text-sm", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsx("span", { className: "text-ui-fg-subtle", children: "Syncing " }),
          /* @__PURE__ */ jsx("strong", { children: preset.title }),
          /* @__PURE__ */ jsx("span", { className: "text-ui-fg-subtle", children: " as ERPNext " }),
          /* @__PURE__ */ jsx("strong", { children: preset.doctype })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsx("span", { className: "text-ui-fg-subtle", children: "Direction: " }),
          /* @__PURE__ */ jsx("strong", { children: DIRECTION_CHOICE[direction].label })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-ui-fg-subtle", children: [
          "Keeping in step:",
          " ",
          fields.filter((f) => f.on && f.constant === void 0).map((f) => f.label).join(", ") || "nothing selected"
        ] }),
        fields.some((f) => f.on && f.constant) && /* @__PURE__ */ jsxs("div", { className: "mt-2 text-ui-fg-subtle", children: [
          "Always sending:",
          " ",
          fields.filter((f) => f.on && f.constant).map((f) => `${f.erpnext_field} = ${f.constant}`).join(", ")
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: () => setStep(2), children: "← Back" }),
        /* @__PURE__ */ jsx(Button, { variant: "primary", onClick: save, disabled: busy, children: stage === "rehearsing" ? "Rehearsing…" : stage === "enabling" ? "Turning on…" : busy ? "Saving…" : "Rehearse & turn on" })
      ] })
    ] })
  ] });
};
const MappingsTab = ({
  onJumpToTab
}) => {
  const [view, setView] = useState("list");
  const [editingId, setEditingId] = useState(null);
  const openNew = () => {
    setEditingId(null);
    setView("edit");
  };
  const openWizard = () => {
    setEditingId(null);
    setView("wizard");
  };
  const openEdit = (id) => {
    setEditingId(id);
    setView("edit");
  };
  const back = () => {
    setEditingId(null);
    setView("list");
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs(Text, { className: "mb-4 text-ui-fg-subtle", children: [
      "Choose what to keep in step between your store and ERPNext. Use",
      " ",
      /* @__PURE__ */ jsx("strong", { children: "Add a sync" }),
      " for the guided setup, or the advanced editor for full control over fields, filters and triggers."
    ] }),
    view === "list" && /* @__PURE__ */ jsx(MappingList, { onOpen: openEdit, onNew: openNew, onWizard: openWizard }),
    view === "wizard" && /* @__PURE__ */ jsx(AddSyncWizard, { onDone: back, onAdvanced: openNew }),
    view === "edit" && /* @__PURE__ */ jsx(MappingEditor, { id: editingId, onBack: back, onJumpToTab })
  ] });
};
const MappingList = ({ onOpen, onNew, onWizard }) => {
  const [items, setItems] = useState(null);
  const [error, setError] = useState(null);
  const refresh = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch("/admin/erpnext/mappings", {
        credentials: "include"
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || "list_failed");
      setItems(body.items ?? []);
    } catch (e) {
      setError(e?.message ?? "failed");
    }
  }, []);
  useEffect(() => {
    refresh();
  }, [refresh]);
  const toggleEnabled = async (m) => {
    await fetch(`/admin/erpnext/mappings/${m.id}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...m, enabled: !m.enabled })
    });
    refresh();
  };
  const remove = async (m) => {
    if (!confirm(`Delete mapping "${m.name}"?`)) return;
    await fetch(`/admin/erpnext/mappings/${m.id}`, {
      method: "DELETE",
      credentials: "include"
    });
    refresh();
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs(Text, { weight: "plus", children: [
        items?.length ?? 0,
        " active ",
        (items?.length ?? 0) === 1 ? "sync" : "syncs"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxs(Button, { size: "small", variant: "primary", onClick: onWizard, children: [
          /* @__PURE__ */ jsx(Plus, {}),
          " Add a sync"
        ] }),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", onClick: onNew, children: "Advanced editor" })
      ] })
    ] }),
    error && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error mb-3", children: error }),
    !items && /* @__PURE__ */ jsx(Text, { children: "Loading…" }),
    items && items.length === 0 && /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-8 text-center", children: [
      /* @__PURE__ */ jsx("div", { className: "mb-2 text-3xl", children: "🔗" }),
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-1", children: "Nothing is syncing yet" }),
      /* @__PURE__ */ jsx(Text, { className: "mb-4 text-ui-fg-subtle", children: "Set up your first sync in a few clicks — pick Customers, Products or Orders and we'll do the rest." }),
      /* @__PURE__ */ jsxs(Button, { variant: "primary", onClick: onWizard, children: [
        /* @__PURE__ */ jsx(Plus, {}),
        " Add your first sync"
      ] })
    ] }),
    items && items.length > 0 && /* @__PURE__ */ jsx("div", { className: "rounded border", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsx("thead", { className: "bg-ui-bg-base-hover", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Name" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Medusa (store)" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "ERPNext DocType" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Direction" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Pairs" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Last run" }),
        /* @__PURE__ */ jsx("th", { className: "p-2 text-left", children: "Enabled" }),
        /* @__PURE__ */ jsx("th", { className: "p-2" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: items.map((m) => /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
        /* @__PURE__ */ jsxs("td", { className: "p-2", children: [
          /* @__PURE__ */ jsx(
            "a",
            {
              onClick: () => onOpen(m.id),
              className: "cursor-pointer font-medium text-ui-fg-interactive hover:underline",
              children: m.name
            }
          ),
          m.description && /* @__PURE__ */ jsx("div", { className: "text-xs text-ui-fg-subtle", children: m.description })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-2", children: m.medusa_entity }),
        /* @__PURE__ */ jsxs("td", { className: "p-2", children: [
          m.doctype,
          Array.isArray(m.secondary_doctypes) && m.secondary_doctypes.length ? ` + ${m.secondary_doctypes.map((s) => s.doctype).filter(Boolean).join(", ")}` : ""
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-2", children: m.direction }),
        /* @__PURE__ */ jsx("td", { className: "p-2", children: m.field_mappings?.length ?? 0 }),
        /* @__PURE__ */ jsxs("td", { className: "p-2 text-xs text-ui-fg-subtle", children: [
          m.last_push_run_at && /* @__PURE__ */ jsxs("div", { children: [
            "push: ",
            formatDate(m.last_push_run_at)
          ] }),
          m.last_pull_run_at && /* @__PURE__ */ jsxs("div", { children: [
            "pull: ",
            formatDate(m.last_pull_run_at)
          ] }),
          m.last_push_error && /* @__PURE__ */ jsx("div", { className: "text-ui-fg-error", children: m.last_push_error }),
          m.last_pull_error && /* @__PURE__ */ jsx("div", { className: "text-ui-fg-error", children: m.last_pull_error })
        ] }),
        /* @__PURE__ */ jsx("td", { className: "p-2", children: /* @__PURE__ */ jsx(
          Switch,
          {
            checked: m.enabled,
            onCheckedChange: () => toggleEnabled(m)
          }
        ) }),
        /* @__PURE__ */ jsx("td", { className: "p-2 text-right", children: /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "transparent",
            onClick: () => remove(m),
            children: /* @__PURE__ */ jsx(Trash, {})
          }
        ) })
      ] }, m.id)) })
    ] }) })
  ] });
};
const PULL_ACTION_COLOR = {
  created: "green",
  updated: "blue",
  skipped: "grey",
  failed: "red"
};
const PullStatus = ({ report, doctype, entity, onDismiss }) => {
  const noun = doctype || "record";
  if (report.running) {
    return /* @__PURE__ */ jsx("div", { className: "rounded border border-ui-border-base p-3", children: /* @__PURE__ */ jsx(Text, { size: "small", children: report.full ? `Reading every selected ${noun} from ERPNext…` : `Pulling changed ${noun} records from ERPNext…` }) });
  }
  const r = report.result ?? {};
  const counts = {
    pulled: r.pulled ?? 0,
    created: r.created ?? 0,
    updated: r.updated ?? 0,
    skipped: r.skipped ?? 0,
    errors: r.errors ?? 0
  };
  const failedOutright = r.ok === false && typeof r.message === "string" && r.message.length > 0;
  const tone = failedOutright || counts.errors ? "red" : counts.pulled === 0 ? "orange" : "green";
  const records = r.records ?? [];
  const everything = report.full || !r.since;
  const scope = everything ? `Every ${noun} selected for sync was read.` : `Only ${noun} records changed in ERPNext since ${new Date(r.since).toLocaleString()} were read.`;
  const emptyHint = !failedOutright && counts.pulled === 0 ? everything ? `No ${noun} has Sync to Medusa set to "ERPNext → Medusa" or "Both".` : `Nothing changed since then. Use Pull all to read every selected ${noun} again.` : null;
  return /* @__PURE__ */ jsxs("div", { className: "rounded border border-ui-border-base p-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(StatusBadge, { color: tone, children: failedOutright ? "Pull failed" : counts.errors ? "Finished with errors" : "Pull finished" }),
        report.at && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: report.at.toLocaleTimeString() })
      ] }),
      /* @__PURE__ */ jsx(Button, { variant: "transparent", size: "small", onClick: onDismiss, children: "Dismiss" })
    ] }),
    failedOutright ? /* @__PURE__ */ jsx(Text, { size: "small", className: "mt-2 text-ui-fg-error", children: r.message }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", className: "mt-2", children: [
        "Fetched ",
        /* @__PURE__ */ jsx("strong", { children: counts.pulled }),
        " ",
        noun,
        counts.pulled === 1 ? "" : "s",
        " from ERPNext: ",
        counts.created,
        " created, ",
        counts.updated,
        " updated,",
        " ",
        counts.skipped,
        " skipped, ",
        counts.errors,
        " failed."
      ] }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: scope }),
      emptyHint && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: emptyHint }),
      records.length > 0 && /* @__PURE__ */ jsxs("table", { className: "mt-2 w-full text-xs", children: [
        /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "text-left text-ui-fg-subtle", children: [
          /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: doctype || "Record" }),
          /* @__PURE__ */ jsx("th", { className: "py-1 pr-2", children: "Result" }),
          /* @__PURE__ */ jsx("th", { className: "py-1", children: "Detail" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: records.map((rec, i) => /* @__PURE__ */ jsxs("tr", { className: "border-t border-ui-border-base", children: [
          /* @__PURE__ */ jsx("td", { className: "py-1 pr-2 font-mono", children: rec.name }),
          /* @__PURE__ */ jsx("td", { className: "py-1 pr-2", children: /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: PULL_ACTION_COLOR[rec.action], children: rec.action }) }),
          /* @__PURE__ */ jsx("td", { className: "py-1", children: rec.reason ?? (rec.medusa_id && entity === "product" ? /* @__PURE__ */ jsx("a", { className: "text-ui-fg-interactive", href: `/app/products/${rec.medusa_id}`, children: rec.medusa_id }) : rec.medusa_id ?? "") })
        ] }, `${rec.name}-${i}`)) })
      ] }),
      records.length > 0 && counts.pulled > records.length && /* @__PURE__ */ jsxs(Text, { size: "small", className: "mt-1 text-ui-fg-subtle", children: [
        "Showing the first ",
        records.length,
        " of ",
        counts.pulled,
        "."
      ] })
    ] })
  ] });
};
const MappingEditor = ({ id, onBack, onJumpToTab }) => {
  const [entities, setEntities] = useState([]);
  const [doctypes, setDoctypes] = useState([]);
  const [doctypeSearch, setDoctypeSearch] = useState("");
  const [doctypeFields, setDoctypeFields] = useState([]);
  const [filledByPush, setFilledByPush] = useState([]);
  const [draft, setDraft] = useState({
    name: "",
    description: "",
    enabled: true,
    direction: "both",
    trigger_preset: "always",
    trigger_condition: "",
    skip_unchanged: false,
    allow_create: true,
    allow_update: true,
    events: [],
    pull_filter: null,
    pull_page_size: 200,
    key_medusa_field: "",
    key_erpnext_field: "name",
    field_mappings: []
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [testRecordId, setTestRecordId] = useState("");
  const [testResult, setTestResult] = useState(null);
  const [pullReport, setPullReport] = useState(null);
  useEffect(() => {
    fetch("/admin/erpnext/medusa-entities", { credentials: "include" }).then((r) => r.json()).then((b) => setEntities(b.items ?? []));
  }, []);
  useEffect(() => {
    if (!id) return;
    fetch(`/admin/erpnext/mappings/${id}`, { credentials: "include" }).then((r) => r.json()).then((b) => {
      if (b?.mapping) {
        setDraft(b.mapping);
        if (b.mapping.doctype) loadDoctypeFields(b.mapping.doctype);
      }
    });
  }, [id]);
  const [doctypesError, setDoctypesError] = useState(null);
  const [doctypesLoading, setDoctypesLoading] = useState(false);
  useEffect(() => {
    refreshDoctypes("");
  }, []);
  const refreshDoctypes = async (search) => {
    setDoctypesLoading(true);
    setDoctypesError(null);
    try {
      const url = search ? `/admin/erpnext/doctypes?search=${encodeURIComponent(search)}&limit=200` : `/admin/erpnext/doctypes?limit=5000`;
      const res = await fetch(url, { credentials: "include" });
      const body = await res.json();
      if (!res.ok || body?.ok === false) {
        setDoctypes([]);
        setDoctypesError(
          friendlyErpError(
            body?.message || `Frappe responded HTTP ${res.status}`
          )
        );
        return;
      }
      const items = body.items ?? [];
      setDoctypes(items.map((i) => i.name));
      if (items.length === 0) {
        setDoctypesError(
          "Frappe returned zero doctypes — the api_key user may lack DocType read permission"
        );
      }
    } catch (e) {
      setDoctypes([]);
      setDoctypesError(friendlyErpError(e?.message));
    } finally {
      setDoctypesLoading(false);
    }
  };
  const loadDoctypeFields = async (name) => {
    if (!name) {
      setDoctypeFields([]);
      return;
    }
    try {
      const res = await fetch(
        `/admin/erpnext/doctypes/${encodeURIComponent(name)}`,
        { credentials: "include" }
      );
      const body = await res.json();
      setDoctypeFields(body.fields ?? []);
      setFilledByPush(Array.isArray(body.filled_by_push) ? body.filled_by_push : []);
    } catch (e) {
      setDoctypeFields([]);
      setError(`could not load fields for ${name}: ${e?.message}`);
    }
  };
  const activeEntity = useMemo(
    () => entities.find((e) => e.key === draft.medusa_entity) ?? null,
    [entities, draft.medusa_entity]
  );
  const [fieldsByDoctype, setFieldsByDoctype] = useState({});
  const ensureFieldsFor = async (name) => {
    if (!name || fieldsByDoctype[name]) return;
    try {
      const res = await fetch(`/admin/erpnext/doctypes/${encodeURIComponent(name)}`, { credentials: "include" });
      const body = await res.json();
      setFieldsByDoctype((m) => ({ ...m, [name]: body.fields ?? [] }));
    } catch {
      setFieldsByDoctype((m) => ({ ...m, [name]: [] }));
    }
  };
  const secondaryDoctypes = Array.isArray(draft.secondary_doctypes) ? draft.secondary_doctypes : [];
  useEffect(() => {
    for (const s of secondaryDoctypes) if (s.doctype) void ensureFieldsFor(s.doctype);
  }, [secondaryDoctypes.map((s) => s.doctype).join("|")]);
  const setSecondaries = (next) => setDraft((d) => ({ ...d, secondary_doctypes: next }));
  const doctypeChoices = [draft.doctype ?? "", ...secondaryDoctypes.map((s) => s.doctype)].filter(Boolean);
  const fieldsFor = (dt) => !dt || dt === (draft.doctype ?? "") ? doctypeFields : fieldsByDoctype[dt] ?? [];
  const [medusaFields, setMedusaFields] = useState([]);
  useEffect(() => {
    const key = draft.medusa_entity;
    if (!key) {
      setMedusaFields([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `/admin/erpnext/medusa-entities/${encodeURIComponent(key)}/fields`,
          { credentials: "include" }
        );
        const body = await res.json();
        if (cancelled) return;
        setMedusaFields(res.ok ? body.fields ?? [] : []);
      } catch {
        if (!cancelled) setMedusaFields([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [draft.medusa_entity]);
  const recommendedDoctypes = useMemo(() => {
    const wanted = ENTITY_DOCTYPE_SUGGESTIONS[draft.medusa_entity ?? ""] ?? [];
    if (!wanted.length || !doctypes.length) return [];
    const have = new Set(doctypes);
    return wanted.filter((d) => have.has(d));
  }, [draft.medusa_entity, doctypes]);
  const pickEntity = (key) => {
    const e = entities.find((x) => x.key === key);
    setDraft((d) => ({
      ...d,
      medusa_entity: key,
      events: e ? e.events : [],
      key_medusa_field: e ? e.default_key_path : ""
    }));
    const wanted = ENTITY_DOCTYPE_SUGGESTIONS[key] ?? [];
    const liveWanted = doctypes.length ? wanted.filter((d) => doctypes.includes(d)) : wanted;
    if (!draft.doctype && liveWanted.length === 1) {
      pickDoctype(liveWanted[0]);
    }
  };
  const pickDoctype = (name) => {
    setDraft((d) => ({ ...d, doctype: name }));
    loadDoctypeFields(name);
  };
  const [annotations, setAnnotations] = useState({});
  const [autofilling, setAutofilling] = useState(false);
  const [autofillMode, setAutofillMode] = useState("smart");
  const runAutofill = async (entity, doctype, opts = {}) => {
    if (!entity || !doctype) return;
    if (!opts.force && (draft.field_mappings?.length ?? 0) > 0) return;
    setAutofilling(true);
    setSuggestStatus(null);
    try {
      const params = new URLSearchParams({
        entity,
        doctype,
        mode: opts.mode ?? autofillMode
      });
      if (draft.direction) params.set("direction", draft.direction);
      const r = await fetch(
        `/admin/erpnext/mappings/autofill?${params.toString()}`,
        { credentials: "include" }
      );
      const b = await r.json();
      if (!b?.ok) {
        setSuggestStatus(
          `Could not read "${doctype}" from Frappe: ${b?.message ?? "unknown error"}`
        );
        return;
      }
      const byField = {};
      for (const a of b.annotations ?? []) {
        byField[a.erpnext_field] = a;
      }
      setAnnotations(byField);
      setDraft((d) => ({
        ...d,
        key_medusa_field: b.key_medusa_field || d.key_medusa_field,
        key_erpnext_field: b.key_erpnext_field || d.key_erpnext_field,
        events: b.events?.length ? b.events : d.events,
        pull_filter: b.pull_filter ?? d.pull_filter,
        field_mappings: b.field_mappings ?? []
      }));
      const s = b.summary ?? {};
      const confident = (s.canonical ?? 0) + (s.composite ?? 0) + (s.exact ?? 0) + (s.synonym ?? 0);
      const needsReview = (s.weak ?? 0) + (s.none ?? 0);
      setSuggestStatus(
        `Read ${b.total_doctype_fields} fields from "${doctype}". Mapped ${b.field_mappings?.length ?? 0} — ${confident} confident, ${s.strong ?? 0} likely${needsReview ? `, ${needsReview} needing your eyes` : ""}.` + (b.canonical ? " Canonical pairs for this combination were applied first." : "")
      );
    } catch (e) {
      setSuggestStatus(`Autofill failed: ${e?.message ?? "network error"}`);
    } finally {
      setAutofilling(false);
    }
  };
  const [suggestStatus, setSuggestStatus] = useState(null);
  const setPair = (idx, patch) => {
    setDraft((d) => {
      const fm = [...d.field_mappings ?? []];
      const next = { ...fm[idx], ...patch };
      for (const [k, v] of Object.entries(patch)) {
        if (v === void 0) delete next[k];
      }
      fm[idx] = next;
      return { ...d, field_mappings: fm };
    });
  };
  const addPair = () => {
    setDraft((d) => ({
      ...d,
      field_mappings: [
        ...d.field_mappings ?? [],
        { medusa_path: "", erpnext_field: "" }
      ]
    }));
  };
  const { options: constantOptions, request: requestConstantOptions } = useConstantOptions(draft.doctype);
  const removePair = (idx) => {
    setDraft((d) => {
      const fm = [...d.field_mappings ?? []];
      fm.splice(idx, 1);
      return { ...d, field_mappings: fm };
    });
  };
  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const url = id ? `/admin/erpnext/mappings/${id}` : "/admin/erpnext/mappings";
      const res = await fetch(url, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        // A row switched to "fixed value" and left blank is not a pair
        // yet: it has no source, and keeping it would count as filling
        // the Frappe field it names — silencing the mandatory-field
        // warnings and passing the rehearsal that gates switching the
        // mapping on. The banner above the list says so before we get
        // here; this is what makes it true. Same rule as the wizard.
        body: JSON.stringify({
          ...draft,
          field_mappings: cleanPairs(draft.field_mappings ?? [])
        })
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || "save_failed");
      onBack();
    } catch (e) {
      setError(e?.message ?? "save_failed");
    } finally {
      setBusy(false);
    }
  };
  const test = async () => {
    if (!id) {
      setError("save first, then test");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(
        // Route folder is `dry-run` (NOT `test`) — Medusa's compiler
        // hardcodes `test` as an ignored directory name and silently
        // drops any file under it, leaving the endpoint to return 404
        // for every push. See dry-run/route.ts.
        `/admin/erpnext/mappings/${id}/dry-run`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(
            testRecordId.trim() ? { record_id: testRecordId.trim() } : {}
          )
        }
      );
      const body = await res.json();
      setTestResult(body);
    } catch (e) {
      setError(e?.message ?? "test_failed");
    } finally {
      setBusy(false);
    }
  };
  const showSample = async () => {
    if (!draft.medusa_entity) {
      setError("pick a Medusa entity first");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const query = new URLSearchParams({ entity: String(draft.medusa_entity) });
      if (testRecordId.trim()) query.set("id", testRecordId.trim());
      const res = await fetch(`/admin/erpnext/studio/sample?${query.toString()}`, {
        credentials: "include"
      });
      setTestResult(await res.json());
    } catch (e) {
      setError(e?.message ?? "sample_failed");
    } finally {
      setBusy(false);
    }
  };
  const planInbound = async () => {
    setBusy(true);
    setError(null);
    try {
      const sample = { doctype: draft.doctype, name: "sample", medusa_sync: "Both" };
      for (const pair of draft.field_mappings ?? []) {
        if (!pair.erpnext_field) continue;
        sample[pair.erpnext_field] = `sample ${pair.erpnext_field}`;
      }
      const res = await fetch("/admin/erpnext/studio/plan-inbound", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          event: "on_update",
          doctype: draft.doctype,
          name: sample.name,
          doc: sample
        })
      });
      setTestResult(await res.json());
    } catch (e) {
      setError(e?.message ?? "plan_failed");
    } finally {
      setBusy(false);
    }
  };
  const pullNow = async (full = false) => {
    if (!id) {
      setError("save first, then pull");
      return;
    }
    setBusy(true);
    setError(null);
    setPullReport({ running: true, full });
    try {
      const res = await fetch(
        `/admin/erpnext/mappings/${id}/pull-now`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(full ? { full: true } : {})
        }
      );
      const body = await res.json().catch(() => ({ ok: false, message: `HTTP ${res.status}` }));
      setPullReport({ running: false, full, at: /* @__PURE__ */ new Date(), result: body });
    } catch (e) {
      setPullReport({ running: false, full, at: /* @__PURE__ */ new Date(), result: { ok: false, message: e?.message ?? "pull_failed" } });
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: onBack, children: "← Back to list" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: showSample, disabled: busy, children: "Sample" }),
        /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: test, disabled: busy || !id, children: "Test push" }),
        /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: planInbound, disabled: busy || !id, children: "Test pull" }),
        /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: () => pullNow(false), disabled: busy || !id, children: pullReport?.running && !pullReport.full ? "Pulling…" : "Pull now" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            variant: "secondary",
            size: "small",
            onClick: () => pullNow(true),
            disabled: busy || !id,
            title: "Read every selected record again, not only those changed since the last pull",
            children: pullReport?.running && pullReport.full ? "Pulling…" : "Pull all"
          }
        ),
        /* @__PURE__ */ jsx(Button, { variant: "primary", size: "small", onClick: save, disabled: busy, children: id ? "Save" : "Create" })
      ] })
    ] }),
    error && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error", children: error }),
    pullReport && /* @__PURE__ */ jsx(
      PullStatus,
      {
        report: pullReport,
        doctype: draft.doctype,
        entity: draft.medusa_entity,
        onDismiss: () => setPullReport(null)
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Name" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: draft.name ?? "",
            onChange: (e) => setDraft((d) => ({ ...d, name: e.target.value }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Sync direction" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
            value: draft.direction ?? "both",
            onChange: (e) => {
              const direction = e.target.value;
              setDraft((d) => ({
                ...d,
                direction,
                // A pair's own direction only narrows a two-way sync; on a
                // one-way sync it could only disagree, so it is dropped.
                field_mappings: direction === "both" ? d.field_mappings : (d.field_mappings ?? []).map((p) => {
                  const { direction: _pd, ...rest } = p;
                  return rest;
                })
              }));
            },
            children: [
              /* @__PURE__ */ jsx("option", { value: "push", children: "One-way — Medusa → ERPNext" }),
              /* @__PURE__ */ jsx("option", { value: "pull", children: "One-way — ERPNext → Medusa" }),
              /* @__PURE__ */ jsx("option", { value: "both", children: "Two-way — both directions" })
            ]
          }
        ),
        /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: DIRECTION_HELP[draft.direction ?? "both"] }),
        (draft.direction ?? "both") !== "push" && /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "New ERPNext documents" }),
          /* @__PURE__ */ jsxs(
            "select",
            {
              className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
              value: draft.selection_mode === "deny" ? "deny" : "allow",
              onChange: (e) => setDraft((d) => ({ ...d, selection_mode: e.target.value })),
              children: [
                /* @__PURE__ */ jsx("option", { value: "allow", children: "Start on None — somebody picks the few to sync (allow list)" }),
                /* @__PURE__ */ jsx("option", { value: "deny", children: "Start on Both — somebody sets the exemptions to None (deny list)" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
            "Set up ERPNext puts a ",
            /* @__PURE__ */ jsx("strong", { children: "Sync to Medusa" }),
            " field and two webhooks on",
            " ",
            draft.doctype || "this DocType",
            "; this is what a new document starts with. Deny also puts every existing document on Both at the first setup. Run Set up ERPNext (Settings) after saving."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Description" }),
        /* @__PURE__ */ jsx(
          Textarea,
          {
            rows: 2,
            value: draft.description ?? "",
            onChange: (e) => setDraft((d) => ({ ...d, description: e.target.value }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Medusa entity" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
            value: draft.medusa_entity ?? "",
            onChange: (e) => pickEntity(e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "— pick an entity —" }),
              entities.map((e) => /* @__PURE__ */ jsxs("option", { value: e.key, children: [
                e.label,
                e.is_custom_module ? `  (${e.module_name})` : ""
              ] }, e.key))
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Frappe doctype" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-2", children: /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: doctypesLoading ? "loading…" : doctypes.length ? "search Frappe doctypes…" : "—",
            value: doctypeSearch,
            disabled: !doctypes.length && !doctypesLoading,
            onChange: (e) => {
              setDoctypeSearch(e.target.value);
              refreshDoctypes(e.target.value);
            }
          }
        ) }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "mt-1 w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm disabled:opacity-50",
            value: draft.doctype ?? "",
            disabled: !doctypes.length,
            onChange: (e) => pickDoctype(e.target.value),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: doctypesLoading ? "loading…" : doctypes.length ? "— pick a doctype —" : "— Frappe not connected —" }),
              recommendedDoctypes.length > 0 && /* @__PURE__ */ jsx("optgroup", { label: `Recommended for ${activeEntity?.label ?? "this entity"}`, children: recommendedDoctypes.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, `rec-${d}`)) }),
              /* @__PURE__ */ jsx(
                "optgroup",
                {
                  label: recommendedDoctypes.length > 0 ? "All doctypes" : void 0,
                  children: doctypes.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, d))
                }
              )
            ]
          }
        ),
        recommendedDoctypes.length > 0 && /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
          "Suggested for ",
          activeEntity?.label,
          ":",
          " ",
          /* @__PURE__ */ jsx("strong", { children: recommendedDoctypes.join(", ") }),
          ". Pick another below if yours is different."
        ] }),
        !doctypesLoading && doctypes.length === 0 && /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-error", children: [
          doctypesError || "No doctypes available.",
          " ",
          /* @__PURE__ */ jsx(
            "a",
            {
              href: "#",
              onClick: (e) => {
                e.preventDefault();
                onJumpToTab?.("settings");
              },
              className: "underline",
              children: "Open Settings tab →"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Key field (Medusa path)" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: draft.key_medusa_field ?? "",
            placeholder: activeEntity?.default_key_path ?? "email",
            onChange: (e) => setDraft((d) => ({ ...d, key_medusa_field: e.target.value }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Key field (Frappe doctype)" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: draft.key_erpnext_field ?? "name",
            onChange: (e) => setDraft((d) => ({ ...d, key_erpnext_field: e.target.value }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2 rounded border border-ui-border-base p-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(Label, { children: "More DocTypes in this sync" }),
          /* @__PURE__ */ jsxs(
            Button,
            {
              size: "small",
              variant: "secondary",
              disabled: !draft.doctype,
              onClick: () => setSecondaries([...secondaryDoctypes, { doctype: "", link_kind: "field", link_field: "" }]),
              children: [
                /* @__PURE__ */ jsx(Plus, {}),
                " Add a DocType"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs(Text, { className: "mb-2 text-xs text-ui-fg-subtle", children: [
          "A ",
          draft.doctype || "main",
          " document can carry documents of other DocTypes with it: a Contact or Address tied through its ",
          /* @__PURE__ */ jsx("em", { children: "Links" }),
          " table, or a document that names the",
          " ",
          draft.doctype || "main",
          " in a Link field. Each field pair below then picks which DocType it targets. The main document is written first; each linked one is found through the link, or created with it set. A change to a linked document in ERPNext comes back as a change to the main one."
        ] }),
        secondaryDoctypes.length === 0 && /* @__PURE__ */ jsxs(Text, { className: "text-xs text-ui-fg-subtle", children: [
          "Just ",
          draft.doctype || "the main DocType",
          "."
        ] }),
        /* @__PURE__ */ jsx("div", { className: "space-y-2", children: secondaryDoctypes.map((sec, i) => {
          const linkFields = (fieldsByDoctype[sec.doctype] ?? []).filter((f) => f.fieldtype === "Link");
          const toMain = linkFields.filter((f) => (f.options ?? "") === (draft.doctype ?? ""));
          const hasLinksTable = (fieldsByDoctype[sec.doctype] ?? []).some((f) => f.fieldname === "links" && f.fieldtype === "Table");
          return /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 items-end gap-2 md:grid-cols-[1fr_220px_1fr_auto]", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(Label, { children: "DocType" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  list: "erpnext-secondary-doctypes",
                  value: sec.doctype,
                  placeholder: "Contact",
                  onChange: (e) => {
                    const v = e.target.value;
                    setSecondaries(secondaryDoctypes.map((s, j) => j === i ? { ...s, doctype: v } : s));
                    if (doctypes.includes(v)) void ensureFieldsFor(v);
                  }
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs(Label, { children: [
                "Tied to ",
                draft.doctype || "the main one",
                " by"
              ] }),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
                  value: sec.link_kind,
                  onChange: (e) => setSecondaries(secondaryDoctypes.map((s, j) => j === i ? { ...s, link_kind: e.target.value } : s)),
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "field", children: "a Link field on it" }),
                    /* @__PURE__ */ jsxs("option", { value: "dynamic_links", children: [
                      "its Links table",
                      hasLinksTable ? "" : " (none seen)"
                    ] })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(Label, { children: "Link field" }),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm disabled:opacity-50",
                  disabled: sec.link_kind !== "field",
                  value: sec.link_field ?? "",
                  onChange: (e) => setSecondaries(secondaryDoctypes.map((s, j) => j === i ? { ...s, link_field: e.target.value } : s)),
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", children: sec.link_kind === "field" ? "Pick the Link field…" : "— Links table —" }),
                    (toMain.length ? toMain : linkFields).map((f) => /* @__PURE__ */ jsxs("option", { value: f.fieldname, children: [
                      f.label,
                      " · ",
                      f.fieldname,
                      f.options ? ` → ${f.options}` : ""
                    ] }, f.fieldname))
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                size: "small",
                variant: "transparent",
                onClick: () => {
                  const gone = sec.doctype;
                  setSecondaries(secondaryDoctypes.filter((_, j) => j !== i));
                  setDraft((d) => ({
                    ...d,
                    field_mappings: (d.field_mappings ?? []).map(
                      (p) => p.erpnext_doctype === gone ? { ...p, erpnext_doctype: void 0, erpnext_field: "" } : p
                    )
                  }));
                },
                children: /* @__PURE__ */ jsx(Trash, {})
              }
            )
          ] }, i);
        }) }),
        /* @__PURE__ */ jsx("datalist", { id: "erpnext-secondary-doctypes", children: doctypes.map((d) => /* @__PURE__ */ jsx("option", { value: d }, d)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Push events (comma separated)" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: (draft.events ?? []).join(", "),
            placeholder: activeEntity ? activeEntity.events.join(", ") : "e.g. customer.created, customer.updated",
            onChange: (e) => setDraft((d) => ({
              ...d,
              events: e.target.value.split(",").map((s) => s.trim()).filter(Boolean)
            }))
          }
        ),
        /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: "Subscriber fires this mapping whenever any listed event lands. Leave empty to disable the push side entirely." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Which ERPNext records should the pull bring back?" }),
        /* @__PURE__ */ jsx(Text, { className: "mb-2 text-xs text-ui-fg-subtle", children: "Every condition has to hold. Leave it empty to take everything. Only records changed since the last pull are fetched either way." }),
        /* @__PURE__ */ jsx(
          PullFilterBuilder,
          {
            value: draft.pull_filter,
            fields: doctypeFields,
            onChange: (next) => setDraft((d) => ({ ...d, pull_filter: next }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2 rounded border border-ui-border-base p-3", children: [
        /* @__PURE__ */ jsx(Label, { children: "When should this sync?" }),
        /* @__PURE__ */ jsxs(Text, { className: "mb-2 text-xs text-ui-fg-subtle", children: [
          "The events above decide which changes are candidates. This decides which ",
          /* @__PURE__ */ jsx("em", { children: "records" }),
          " qualify — e.g. only once KYC clears, or only once they have actually bought something."
        ] }),
        /* @__PURE__ */ jsx(
          "select",
          {
            className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
            value: draft.trigger_preset ?? "always",
            onChange: (e) => {
              const preset = TRIGGER_PRESETS.find((p) => p.value === e.target.value);
              setDraft((d) => ({
                ...d,
                trigger_preset: e.target.value,
                // Keep whatever the operator typed when they switch to
                // custom; otherwise adopt the preset's own condition.
                trigger_condition: e.target.value === "custom" ? d.trigger_condition ?? "" : preset?.condition ?? ""
              }));
            },
            children: TRIGGER_PRESETS.map((p) => /* @__PURE__ */ jsx("option", { value: p.value, children: p.label }, p.value))
          }
        ),
        /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: TRIGGER_PRESETS.find((p) => p.value === (draft.trigger_preset ?? "always"))?.help }),
        (draft.trigger_preset ?? "always") === "custom" && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              className: "mt-2 font-mono text-xs",
              placeholder: "always — no condition",
              value: draft.trigger_condition ?? "",
              onChange: (e) => setDraft((d) => ({
                ...d,
                trigger_condition: e.target.value,
                trigger_preset: "custom"
              }))
            }
          ),
          /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
            "Supported: ",
            /* @__PURE__ */ jsx("code", { children: "is set" }),
            ", ",
            /* @__PURE__ */ jsx("code", { children: "is not set" }),
            ",",
            " ",
            /* @__PURE__ */ jsx("code", { children: "is empty" }),
            ", ",
            /* @__PURE__ */ jsx("code", { children: "== != > >= < <=" }),
            ",",
            " ",
            /* @__PURE__ */ jsx("code", { children: "contains" }),
            ", ",
            /* @__PURE__ */ jsx("code", { children: "starts with" }),
            ",",
            " ",
            /* @__PURE__ */ jsx("code", { children: "and" }),
            " / ",
            /* @__PURE__ */ jsx("code", { children: "or" }),
            " / ",
            /* @__PURE__ */ jsx("code", { children: "not" }),
            " and brackets. Not JavaScript — it can only read fields off the record. An invalid condition is rejected on save, and would sync nothing rather than everything."
          ] })
        ] }),
        (draft.trigger_preset ?? "always") !== "custom" && draft.trigger_condition ? /* @__PURE__ */ jsxs(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: [
          "Runs when ",
          /* @__PURE__ */ jsx("code", { children: draft.trigger_condition }),
          "."
        ] }) : null,
        /* @__PURE__ */ jsxs("div", { className: "mt-3 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(
            Switch,
            {
              checked: Boolean(draft.skip_unchanged),
              onCheckedChange: (v) => setDraft((d) => ({ ...d, skip_unchanged: v }))
            }
          ),
          /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-subtle", children: "Skip when nothing changed" })
        ] }),
        /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: "Compares against the last payload that synced successfully for this record. Only the fields mapped below count — an unrelated change elsewhere on the record will not re-push." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "col-span-2 rounded border border-ui-border-base p-3", children: [
        /* @__PURE__ */ jsx(Label, { children: "What may this sync do to the other side?" }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 flex gap-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(
              Switch,
              {
                checked: draft.allow_create !== false,
                onCheckedChange: (v) => setDraft((d) => ({ ...d, allow_create: v }))
              }
            ),
            /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-subtle", children: "Create missing records" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(
              Switch,
              {
                checked: draft.allow_update !== false,
                onCheckedChange: (v) => setDraft((d) => ({ ...d, allow_update: v }))
              }
            ),
            /* @__PURE__ */ jsx(Label, { className: "text-ui-fg-subtle", children: "Update existing records" })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Text, { className: "mt-1 text-xs text-ui-fg-subtle", children: "Both on = full upsert, which is the usual setting. Create-only never overwrites a record someone edited on the other side; update-only enriches records that system already owns." })
      ] })
    ] }),
    /* @__PURE__ */ jsx(
      RequiredBoxes,
      {
        direction: draft.direction ?? "both",
        pairs: draft.field_mappings ?? [],
        doctype: draft.doctype ?? "",
        erpRequired: doctypeFields.filter((f) => f.reqd && !f.fetch_from && !f.default).filter(
          (f) => !filledByPush.includes(f.fieldname) && !(f.fieldname === "terms" && (draft.field_mappings ?? []).some((p) => p?.erpnext_field === "tc_name"))
        ).map((f) => ({ name: f.fieldname, label: f.label || f.fieldname })),
        medusaRequired: medusaFields.filter((f) => f.required).map((f) => ({ name: f.path, label: f.label || f.path })),
        storeKnown: medusaFields.length > 0,
        onAddErp: (names) => setDraft((d) => ({
          ...d,
          field_mappings: [
            ...d.field_mappings ?? [],
            ...names.map((n) => ({ medusa_path: "", erpnext_field: n }))
          ]
        })),
        onAddMedusa: (paths) => setDraft((d) => ({
          ...d,
          field_mappings: [
            ...d.field_mappings ?? [],
            ...paths.map((p) => ({ medusa_path: p, erpnext_field: "" }))
          ]
        }))
      }
    ),
    secondaryDoctypes.filter((sec) => sec.doctype).map((sec) => {
      const linkField = sec.link_kind === "dynamic_links" ? "links" : sec.link_field ?? "";
      return /* @__PURE__ */ jsx(
        RequiredBoxes,
        {
          direction: "push",
          pairs: (draft.field_mappings ?? []).filter((p) => p.erpnext_doctype === sec.doctype),
          doctype: sec.doctype,
          erpRequired: (fieldsByDoctype[sec.doctype] ?? []).filter((f) => f.reqd && !f.fetch_from && !f.default && f.fieldname !== linkField).map((f) => ({ name: f.fieldname, label: f.label || f.fieldname })),
          medusaRequired: [],
          storeKnown: false,
          onAddErp: (names) => setDraft((d) => ({
            ...d,
            field_mappings: [
              ...d.field_mappings ?? [],
              ...names.map((n) => ({ medusa_path: "", erpnext_field: n, erpnext_doctype: sec.doctype }))
            ]
          })),
          onAddMedusa: () => {
          }
        },
        `req-${sec.doctype}`
      );
    }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Field mappings" }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxs(
            "select",
            {
              className: "rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
              value: autofillMode,
              onChange: (e) => {
                const mode = e.target.value;
                setAutofillMode(mode);
                if (draft.medusa_entity && draft.doctype) {
                  runAutofill(draft.medusa_entity, draft.doctype, {
                    force: true,
                    mode
                  });
                }
              },
              title: "Which doctype fields to put in the grid",
              children: [
                /* @__PURE__ */ jsx("option", { value: "smart", children: "mandatory + matched" }),
                /* @__PURE__ */ jsx("option", { value: "all", children: "every field" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: "secondary",
              isLoading: autofilling,
              onClick: () => runAutofill(draft.medusa_entity, draft.doctype, {
                force: true
              }),
              disabled: !draft.medusa_entity || !draft.doctype || autofilling,
              title: !draft.medusa_entity || !draft.doctype ? "Pick a Medusa entity and Frappe doctype first" : "Read the doctype's fields and guess a Medusa source for each. Replaces the current pairs.",
              children: "Auto-map fields"
            }
          ),
          /* @__PURE__ */ jsxs(Button, { size: "small", variant: "secondary", onClick: addPair, children: [
            /* @__PURE__ */ jsx(Plus, {}),
            " Add pair"
          ] })
        ] })
      ] }),
      suggestStatus && /* @__PURE__ */ jsx("div", { className: "mb-3 rounded border border-ui-border-interactive bg-ui-bg-subtle p-3 text-xs text-ui-fg-subtle", children: suggestStatus }),
      /* @__PURE__ */ jsxs(Text, { className: "mb-4 text-xs text-ui-fg-subtle", children: [
        "Each row pairs one Medusa source with one Frappe fieldname. Picking a doctype reads its fields live and guesses a source for each — the badge on every row says how confident that guess is, so ",
        /* @__PURE__ */ jsx("em", { children: "check this" }),
        " and ",
        /* @__PURE__ */ jsx("em", { children: "no match" }),
        " are the only ones you have to look at. A source can also combine several Medusa fields: ",
        /* @__PURE__ */ jsx("code", { children: "{first_name} {last_name}" }),
        " writes both into ERPNext's single name column. Combined sources are push-only (there's no way to split a joined value back apart)."
      ] }),
      (draft.field_mappings ?? []).length === 0 && /* @__PURE__ */ jsxs("div", { className: "rounded border p-4 text-center text-ui-fg-subtle", children: [
        "No field pairs yet — click ",
        /* @__PURE__ */ jsx("em", { children: "Auto-map fields" }),
        " to read the doctype and fill this in, or ",
        /* @__PURE__ */ jsx("em", { children: "Add pair" }),
        " to build manually."
      ] }),
      (() => {
        const blanks = (draft.field_mappings ?? []).filter(
          (p) => p.constant !== void 0 && !constantHasValue(p.constant)
        );
        if (!blanks.length) return null;
        return /* @__PURE__ */ jsxs("div", { className: "mb-3 rounded border border-ui-tag-orange-border bg-ui-tag-orange-bg p-3 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-1 font-medium", children: [
            blanks.length,
            " fixed value",
            blanks.length === 1 ? "" : "s",
            " with nothing to send"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-ui-fg-subtle", children: [
            "These rows will not be saved until you say what to send:",
            " ",
            blanks.map((p) => p.erpnext_field || "(no field picked)").join(", "),
            ". Pick a value, or use ↩ to read a store field instead."
          ] })
        ] });
      })(),
      (() => {
        const mapped = new Set(
          (draft.field_mappings ?? []).filter(
            (p) => p.constant === void 0 || constantHasValue(p.constant)
          ).map((p) => p.erpnext_field)
        );
        const gaps = Object.values(annotations).filter(
          (a) => a.reqd && !a.medusa_path && !mapped.has(a.erpnext_field)
        );
        if (!gaps.length) return null;
        return /* @__PURE__ */ jsxs("div", { className: "mb-3 rounded border border-ui-tag-orange-border bg-ui-tag-orange-bg p-3 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-1 font-medium", children: [
            gaps.length,
            " mandatory ERPNext field",
            gaps.length === 1 ? "" : "s",
            " with no Medusa source"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-ui-fg-subtle", children: [
            "ERPNext will reject the write unless these have a value. Add a pair with a default, or let Frappe's own default apply:",
            " ",
            gaps.map(
              (g) => `${g.erpnext_label} (${g.erpnext_field})` + (g.default ? ` → defaults to "${g.default}"` : "")
            ).join("; ")
          ] })
        ] });
      })(),
      (() => {
        const seen = /* @__PURE__ */ new Map();
        for (const p of draft.field_mappings ?? []) {
          if (!p.erpnext_field || !p.medusa_path) continue;
          const dirs = (p.direction ?? draft.direction ?? "both") === "both" ? ["push", "pull"] : [p.direction ?? draft.direction ?? "both"];
          for (const d of dirs) {
            const k = `${p.erpnext_field}::${d}`;
            seen.set(k, [...seen.get(k) ?? [], p.medusa_path]);
          }
        }
        const clashes = [...seen.entries()].filter(([, v]) => v.length > 1);
        if (!clashes.length) return null;
        return /* @__PURE__ */ jsxs("div", { className: "mb-3 rounded border border-ui-tag-red-border bg-ui-tag-red-bg p-3 text-xs", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-1 font-medium", children: [
            clashes.length,
            " field",
            clashes.length === 1 ? "" : "s",
            " written twice in the same direction"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "text-ui-fg-subtle", children: [
            "Whichever row runs last wins, so the result depends on row order rather than on anything you chose. If you meant “use the first one that has a value”, delete one row and write the other as",
            " ",
            /* @__PURE__ */ jsx("code", { children: "{path.a || path.b}" }),
            ".",
            /* @__PURE__ */ jsx("ul", { className: "mt-1 list-disc pl-4", children: clashes.map(([k, v]) => /* @__PURE__ */ jsxs("li", { children: [
              /* @__PURE__ */ jsx("code", { children: k.split("::")[0] }),
              " on ",
              k.split("::")[1],
              " ←",
              " ",
              v.join("  ·  ")
            ] }, k)) })
          ] })
        ] });
      })(),
      (draft.field_mappings ?? []).length > 0 && /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center gap-2 rounded bg-ui-bg-subtle px-2 py-1 text-xs font-medium", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
          "Medusa · ",
          activeEntity?.label ?? draft.medusa_entity ?? "store",
          /* @__PURE__ */ jsx("span", { className: "ml-1 font-normal text-ui-fg-subtle", children: "(this store)" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-[104px] shrink-0 text-center font-normal text-ui-fg-subtle", title: "→ out to ERPNext · ↔ both ways · ← in from ERPNext", children: (draft.direction ?? "both") === "both" ? "direction" : "direction (set above)" }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
          "ERPNext · ",
          draft.doctype || "DocType",
          secondaryDoctypes.filter((s) => s.doctype).length ? ` + ${secondaryDoctypes.filter((s) => s.doctype).map((s) => s.doctype).join(", ")}` : "",
          /* @__PURE__ */ jsx("span", { className: "ml-1 font-normal text-ui-fg-subtle", children: "(the ERP)" })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-[52px] shrink-0" })
      ] }),
      (draft.field_mappings ?? []).map((pair, idx) => /* @__PURE__ */ jsx(
        FieldPairRow,
        {
          pair,
          entity: activeEntity,
          medusaFields,
          fields: fieldsFor(pair.erpnext_doctype),
          doctypeChoices,
          mainDoctype: draft.doctype ?? "",
          annotation: annotations[pair.erpnext_field],
          mappingDirection: draft.direction ?? "both",
          takenErpnextFields: (draft.field_mappings ?? []).filter((p) => (p.erpnext_doctype || draft.doctype || "") === (pair.erpnext_doctype || draft.doctype || "")).map((p) => p.erpnext_field).filter(Boolean),
          constantOptions,
          onRequestConstantOptions: requestConstantOptions,
          onChange: (patch) => setPair(idx, patch),
          onRemove: () => removePair(idx)
        },
        idx
      ))
    ] }),
    id && /* @__PURE__ */ jsxs("div", { className: "mt-6 rounded border p-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", className: "mb-2", children: "Test" }),
      /* @__PURE__ */ jsxs("div", { className: "mb-2 flex gap-2", children: [
        /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: "Medusa record id (cus_…, prod_…, etc.)",
            value: testRecordId,
            onChange: (e) => setTestRecordId(e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(Button, { variant: "secondary", size: "small", onClick: test, disabled: busy, children: "Dry-run push" })
      ] }),
      testResult && /* @__PURE__ */ jsx("pre", { className: "mt-2 max-h-96 overflow-auto rounded bg-ui-bg-subtle p-2 text-xs", children: JSON.stringify(testResult, null, 2) })
    ] })
  ] });
};
const FieldPairRow = ({
  pair,
  entity,
  medusaFields,
  fields,
  doctypeChoices = [],
  mainDoctype = "",
  annotation,
  mappingDirection,
  takenErpnextFields,
  constantOptions,
  onRequestConstantOptions,
  onChange,
  onRemove
}) => {
  const isTemplate = /\{[^{}]+\}/.test(pair.medusa_path ?? "");
  const isConstant = pair.constant !== void 0;
  useEffect(() => {
    if (isConstant && pair.erpnext_field) {
      onRequestConstantOptions(pair.erpnext_field);
    }
  }, [isConstant, pair.erpnext_field, onRequestConstantOptions]);
  const toggleConstant = () => onChange(
    isConstant ? { constant: void 0 } : { constant: "", medusa_path: "", transform: void 0 }
  );
  const effectiveDirection = pair.direction ?? mappingDirection;
  const conf = annotation ? CONFIDENCE_META[annotation.confidence] : null;
  const [open, setOpen] = useState(
    Boolean(
      isTemplate || pair.transform || pair.transform_push || pair.transform_pull || pair.constant !== void 0 || pair.constant_pull !== void 0 || pair.default !== void 0 || pair.default_push !== void 0 || pair.default_pull !== void 0
    )
  );
  const flowsPush = effectiveDirection === "push" || effectiveDirection === "both";
  const flowsPull = effectiveDirection === "pull" || effectiveDirection === "both";
  const medusaType = (medusaFields.length ? medusaFields : entity?.paths ?? []).find(
    (p) => p.path === pair.medusa_path
  )?.type;
  const frappeType = fields.find((f) => f.fieldname === pair.erpnext_field)?.fieldtype;
  const verdictFor = (dir) => {
    if (!medusaType || !frappeType || isTemplate) return null;
    if (dir === "push" ? pair.constant !== void 0 : pair.constant_pull !== void 0) return null;
    if (dir === "push" ? pair.transform_push || pair.transform : pair.transform_pull || pair.transform) return null;
    const v = suggestConversion({ direction: dir, medusaType, frappeType });
    return v.kind === "none" ? null : v;
  };
  const warnings = [
    ...flowsPush ? [["push", verdictFor("push")]] : [],
    ...flowsPull ? [["pull", verdictFor("pull")]] : []
  ].filter((x) => x[1] !== null);
  const paths = medusaFields.length ? medusaFields : (entity?.paths ?? []).map((p) => ({
    path: p.path,
    label: p.label,
    type: p.type
  }));
  const [showAll, setShowAll] = useState(false);
  const hiddenPaths = paths.filter((p) => p.advanced && p.path !== pair.medusa_path).length;
  const pickerGroups = groupForPicker(paths, {
    showAll,
    keep: pair.medusa_path,
    ownLabel: entity?.label ?? "This record"
  });
  const requiredDocFields = fields.filter((f) => f.reqd);
  const otherDocFields = fields.filter((f) => !f.reqd);
  const arrow = (value, glyph, title) => /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      title,
      disabled: isTemplate && value !== "push",
      onClick: () => onChange({ direction: value }),
      className: "h-7 w-8 rounded border text-sm disabled:opacity-40 " + (effectiveDirection === value ? "border-ui-border-interactive bg-ui-bg-base-pressed font-semibold" : "border-ui-border-base bg-ui-bg-base text-ui-fg-subtle"),
      children: glyph
    },
    value
  );
  return /* @__PURE__ */ jsxs("div", { className: "mb-2 rounded border border-ui-border-base p-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx("div", { className: "flex-1", children: isTemplate ? /* @__PURE__ */ jsxs("div", { className: "rounded border border-ui-tag-blue-border bg-ui-tag-blue-bg px-2 py-1.5 text-xs", children: [
        "combines",
        " ",
        (pair.medusa_path.match(/\{([^{}]+)\}/g) ?? []).map((x) => x.slice(1, -1)).join(" + ")
      ] }) : isConstant ? /* @__PURE__ */ jsx(
        ConstantValueControl,
        {
          value: String(pair.constant ?? ""),
          meta: constantOptions[pair.erpnext_field],
          hasField: Boolean(pair.erpnext_field),
          onChange: (v) => onChange({ constant: v })
        }
      ) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
            value: pair.medusa_path,
            onChange: (e) => onChange({ medusa_path: e.target.value }),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Pick a store field…" }),
              pickerGroups.map((g) => /* @__PURE__ */ jsx("optgroup", { label: g.label, children: g.fields.map((p) => /* @__PURE__ */ jsxs("option", { value: p.path, title: p.description ?? p.path, children: [
                p.label,
                " · ",
                p.path
              ] }, p.path)) }, g.label))
            ]
          }
        ),
        (hiddenPaths > 0 || showAll) && /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            className: "mt-0.5 text-xs text-ui-fg-subtle underline",
            onClick: () => setShowAll((v) => !v),
            children: showAll ? "Hide internal fields" : `Show ${hiddenPaths} internal fields`
          }
        )
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "flex w-[104px] shrink-0 justify-center gap-1", children: mappingDirection === "both" ? /* @__PURE__ */ jsxs(Fragment, { children: [
        arrow("push", "→", "Only out to ERPNext"),
        arrow("both", "↔", "Both ways"),
        arrow("pull", "←", "Only in from ERPNext")
      ] }) : (
        // A one-way sync moves every pair its one way; there is nothing
        // to choose here, so the arrow just says which way.
        /* @__PURE__ */ jsx(
          "span",
          {
            className: "inline-flex h-7 w-8 items-center justify-center rounded border border-ui-border-base bg-ui-bg-subtle text-sm text-ui-fg-subtle",
            title: mappingDirection === "push" ? "Out to ERPNext — set by the sync direction" : "In from ERPNext — set by the sync direction",
            children: mappingDirection === "push" ? "→" : "←"
          }
        )
      ) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-1 rounded border-l-2 border-ui-border-strong bg-ui-bg-subtle p-1", title: "ERPNext side", children: [
        doctypeChoices.length > 1 && /* @__PURE__ */ jsx(
          "select",
          {
            className: "mb-1 w-full rounded border bg-ui-bg-base px-2 py-1 text-xs",
            value: pair.erpnext_doctype || mainDoctype,
            onChange: (e) => {
              const dt = e.target.value;
              onChange({ erpnext_doctype: dt === mainDoctype ? void 0 : dt, erpnext_field: "" });
            },
            children: doctypeChoices.map((dt) => /* @__PURE__ */ jsx("option", { value: dt, children: dt === mainDoctype ? `${dt} (main)` : dt }, dt))
          }
        ),
        /* @__PURE__ */ jsxs(
          "select",
          {
            className: "w-full rounded border bg-ui-bg-base px-2 py-1.5 text-sm",
            value: pair.erpnext_field,
            onChange: (e) => onChange({ erpnext_field: e.target.value }),
            children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Pick a Frappe field…" }),
              requiredDocFields.length > 0 && /* @__PURE__ */ jsx("optgroup", { label: "Required", children: requiredDocFields.map((f) => /* @__PURE__ */ jsxs(
                "option",
                {
                  value: f.fieldname,
                  disabled: takenErpnextFields.includes(f.fieldname) && f.fieldname !== pair.erpnext_field,
                  children: [
                    f.label,
                    " · ",
                    f.fieldname
                  ]
                },
                f.fieldname
              )) }),
              /* @__PURE__ */ jsx("optgroup", { label: "──────────", children: otherDocFields.map((f) => /* @__PURE__ */ jsxs(
                "option",
                {
                  value: f.fieldname,
                  disabled: takenErpnextFields.includes(f.fieldname) && f.fieldname !== pair.erpnext_field,
                  children: [
                    f.label,
                    " · ",
                    f.fieldname
                  ]
                },
                f.fieldname
              )) })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx(
        Button,
        {
          variant: "transparent",
          size: "small",
          onClick: toggleConstant,
          disabled: isTemplate,
          title: isTemplate ? "A combined source cannot also be a fixed value" : isConstant ? "Read a store field instead" : "Send a fixed value instead — for a field ERPNext requires and the store has no equivalent for",
          children: isConstant ? "↩" : "="
        }
      ),
      /* @__PURE__ */ jsx(
        Button,
        {
          variant: "transparent",
          size: "small",
          onClick: () => setOpen((v) => !v),
          title: "Transform, a combined source, or a field the picker does not list",
          children: "⋯"
        }
      ),
      /* @__PURE__ */ jsx(Button, { variant: "transparent", size: "small", onClick: onRemove, children: /* @__PURE__ */ jsx(Trash, {}) })
    ] }),
    (conf || annotation?.reqd) && /* @__PURE__ */ jsxs("div", { className: "mt-1 flex items-center gap-1", children: [
      annotation?.reqd && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: "red", children: "required" }),
      conf && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: conf.color, title: annotation?.why, children: conf.label })
    ] }),
    warnings.length > 0 && /* @__PURE__ */ jsx("div", { className: "mt-1 space-y-0.5", children: warnings.map(([dir, v]) => /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-1 text-xs", children: [
      /* @__PURE__ */ jsxs(Badge, { size: "2xsmall", color: v.kind === "safe" ? "blue" : v.kind === "review" ? "orange" : "red", children: [
        dir === "push" ? "→ ERPNext" : "← ERPNext",
        " ",
        v.kind === "safe" ? "convert" : v.kind === "review" ? "check type" : "type"
      ] }),
      /* @__PURE__ */ jsxs("span", { className: "text-ui-fg-subtle", children: [
        medusaType,
        " ↔ ",
        frappeType,
        ": ",
        v.kind === "none" ? "" : v.why
      ] }),
      "transform" in v && v.transform && /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          className: "underline",
          onClick: () => onChange(
            dir === "push" ? { transform_push: v.transform } : { transform_pull: v.transform }
          ),
          children: [
            "use ",
            v.transform
          ]
        }
      )
    ] }, dir)) }),
    open && /* @__PURE__ */ jsxs("div", { className: "mt-2 space-y-2 border-t border-ui-border-base pt-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-2 md:grid-cols-2", children: [
        flowsPush && /* @__PURE__ */ jsx(
          DirectionPanel,
          {
            title: "Out to ERPNext",
            direction: "push",
            pair,
            onChange,
            valueControl: (value, set, placeholder) => /* @__PURE__ */ jsx(
              ConstantValueControl,
              {
                value,
                meta: constantOptions[pair.erpnext_field],
                hasField: Boolean(pair.erpnext_field),
                placeholder,
                onChange: set
              }
            ),
            onNeedOptions: () => pair.erpnext_field && onRequestConstantOptions(pair.erpnext_field)
          }
        ),
        flowsPull && /* @__PURE__ */ jsx(
          DirectionPanel,
          {
            title: "In from ERPNext",
            direction: "pull",
            pair,
            onChange,
            valueControl: (value, set, placeholder) => /* @__PURE__ */ jsx(
              MedusaValueControl,
              {
                entity: entity?.key ?? null,
                path: pair.medusa_path,
                value,
                placeholder,
                onChange: set
              }
            )
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Store path" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              className: "font-mono text-xs",
              placeholder: "dot-path, or {a} {b} to combine",
              value: pair.medusa_path,
              onChange: (e) => onChange({ medusa_path: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Frappe fieldname" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              className: "font-mono text-xs",
              placeholder: "a fieldname the picker does not list",
              value: pair.erpnext_field,
              onChange: (e) => onChange({ erpnext_field: e.target.value })
            }
          )
        ] })
      ] })
    ] })
  ] });
};
const DirectionPanel = ({ title, direction, pair, onChange, valueControl, onNeedOptions }) => {
  const fixedKey = direction === "push" ? "constant" : "constant_pull";
  const defaultKey = direction === "push" ? "default_push" : "default_pull";
  const transformKey = direction === "push" ? "transform_push" : "transform_pull";
  const fixed = pair[fixedKey];
  const ownDefault = pair[defaultKey];
  const mode = fixed !== void 0 ? "fixed" : ownDefault !== void 0 ? "default" : "source";
  const ownTransform = pair[transformKey] ?? "";
  const sharedTransform = pair.transform ?? "";
  useEffect(() => {
    if (mode !== "source") onNeedOptions?.();
  }, [mode, onNeedOptions]);
  const setMode = (next) => {
    const patch = {};
    if (next !== "fixed") patch[fixedKey] = void 0;
    if (next !== "default") patch[defaultKey] = void 0;
    if (next === "fixed") {
      patch[fixedKey] = "";
      if (direction === "push") patch.medusa_path = pair.medusa_path;
    }
    if (next === "default") patch[defaultKey] = "";
    onChange(patch);
  };
  return /* @__PURE__ */ jsxs("div", { className: "rounded border border-ui-border-base p-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Text, { size: "xsmall", weight: "plus", children: title }),
      /* @__PURE__ */ jsxs(
        "select",
        {
          className: "rounded border bg-ui-bg-base px-1 py-0.5 text-xs",
          value: mode,
          onChange: (e) => setMode(e.target.value),
          children: [
            /* @__PURE__ */ jsx("option", { value: "source", children: "value from the source field" }),
            /* @__PURE__ */ jsx("option", { value: "fixed", children: "a fixed value, always" }),
            /* @__PURE__ */ jsx("option", { value: "default", children: "a default when the source is empty" })
          ]
        }
      )
    ] }),
    mode === "fixed" && valueControl(String(fixed ?? ""), (v) => onChange({ [fixedKey]: v }), "Fixed value, written every time"),
    mode === "default" && valueControl(String(ownDefault ?? ""), (v) => onChange({ [defaultKey]: v }), "Used only when the source is empty"),
    mode === "source" && pair.default !== void 0 && /* @__PURE__ */ jsxs(Text, { size: "xsmall", className: "text-ui-fg-subtle", children: [
      "Shared default: ",
      String(pair.default)
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-1", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Transform" }),
      /* @__PURE__ */ jsx(
        Input,
        {
          className: "font-mono text-xs",
          list: "erpnext-transforms",
          placeholder: sharedTransform ? `inherits ${sharedTransform}` : "none",
          value: ownTransform,
          onChange: (e) => onChange({ [transformKey]: e.target.value || void 0 })
        }
      ),
      /* @__PURE__ */ jsx("datalist", { id: "erpnext-transforms", children: TRANSFORM_OPTIONS.filter((t) => t.value).map((t) => /* @__PURE__ */ jsx("option", { value: t.value, children: t.label }, t.value)) })
    ] })
  ] });
};
function formatDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString();
  } catch {
    return iso;
  }
}
function frappeDocUrl(base, doctype, name) {
  if (!base) return null;
  const slug = doctype.toLowerCase().replace(/\s+/g, "-");
  return `${base.replace(/\/+$/, "")}/app/${slug}/${encodeURIComponent(name)}`;
}
function medusaRecordUrl(entity, id) {
  const paths = { product: "products", customer: "customers", order: "orders", product_category: "categories", product_collection: "collections" };
  return paths[entity] ? `/app/${paths[entity]}/${id}` : null;
}
const DocumentsTab = ({ erpnextUrl }) => {
  const [items, setItems] = useState([]);
  const [count, setCount] = useState(0);
  const [doctypes, setDoctypes] = useState([]);
  const [entities, setEntities] = useState([]);
  const [doctype, setDoctype] = useState("");
  const [entity, setEntity] = useState("");
  const [state, setState] = useState("");
  const [q, setQ] = useState("");
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);
  const limit = 50;
  const load = async () => {
    setLoading(true);
    setErr(null);
    try {
      const params = new URLSearchParams({ limit: String(limit), offset: String(offset) });
      if (doctype) params.set("doctype", doctype);
      if (entity) params.set("entity", entity);
      if (state) params.set("state", state);
      if (q.trim()) params.set("q", q.trim());
      const res = await fetch(`/admin/erpnext/links?${params.toString()}`, { credentials: "include" });
      const body = await res.json();
      if (!res.ok) throw new Error(body.message || `HTTP ${res.status}`);
      setItems(body.items ?? []);
      setCount(body.count ?? 0);
      setDoctypes(body.doctypes ?? []);
      setEntities(body.entities ?? []);
    } catch (e) {
      setErr(e?.message ?? "load_failed");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, [doctype, entity, state, offset]);
  const directionLabel = (d) => d === null || d === void 0 ? "not shown yet" : d === "" || d === "None" ? "None — not selected" : d;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
      "One row per ERPNext document that is tied to a record in this store. ",
      /* @__PURE__ */ jsx("strong", { children: "Which documents are allowed to sync is decided in ERPNext" }),
      ": on each document, the ",
      /* @__PURE__ */ jsx("em", { children: "Sync to Medusa" }),
      " ",
      "field says ERPNext → Medusa, Medusa → ERPNext, Both, or None (not selected). In ERPNext, filter the DocType's list by that field to see the allowed and the not-allowed ones. This tab is the record of what has synced, with the direction ERPNext last showed for each; a document that was deselected or deleted there shows its store record as ",
      /* @__PURE__ */ jsx("em", { children: "drafted" }),
      "."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-end gap-2", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "ERPNext DocType" }),
        /* @__PURE__ */ jsxs("select", { className: "rounded border bg-ui-bg-base px-2 py-1.5 text-sm", value: doctype, onChange: (e) => {
          setOffset(0);
          setDoctype(e.target.value);
        }, children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "all" }),
          doctypes.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, d))
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Medusa" }),
        /* @__PURE__ */ jsxs("select", { className: "rounded border bg-ui-bg-base px-2 py-1.5 text-sm", value: entity, onChange: (e) => {
          setOffset(0);
          setEntity(e.target.value);
        }, children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "all" }),
          entities.map((d) => /* @__PURE__ */ jsx("option", { value: d, children: d }, d))
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Store record" }),
        /* @__PURE__ */ jsxs("select", { className: "rounded border bg-ui-bg-base px-2 py-1.5 text-sm", value: state, onChange: (e) => {
          setOffset(0);
          setState(e.target.value);
        }, children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "active and drafted" }),
          /* @__PURE__ */ jsx("option", { value: "active", children: "active" }),
          /* @__PURE__ */ jsx("option", { value: "drafted", children: "drafted" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "min-w-[220px] flex-1", children: [
        /* @__PURE__ */ jsx(Label, { children: "Search" }),
        /* @__PURE__ */ jsx(Input, { value: q, placeholder: "ERPNext name or Medusa id", onChange: (e) => setQ(e.target.value), onKeyDown: (e) => {
          if (e.key === "Enter") {
            setOffset(0);
            void load();
          }
        } })
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", isLoading: loading, onClick: () => {
        setOffset(0);
        void load();
      }, children: "Refresh" })
    ] }),
    err && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: err }),
    /* @__PURE__ */ jsx("div", { className: "overflow-x-auto rounded border border-ui-border-base", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b border-ui-border-base text-left text-ui-fg-subtle", children: [
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "ERPNext DocType" }),
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "ERPNext document" }),
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "Sync to Medusa" }),
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "Medusa" }),
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "Store record" }),
        /* @__PURE__ */ jsx("th", { className: "p-2", children: "Last seen" })
      ] }) }),
      /* @__PURE__ */ jsxs("tbody", { children: [
        items.length === 0 && !loading && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsxs("td", { className: "p-3 text-ui-fg-subtle", colSpan: 6, children: [
          "Nothing has synced yet. Set ",
          /* @__PURE__ */ jsx("em", { children: "Sync to Medusa" }),
          " on a document in ERPNext, or push a record from the store."
        ] }) }),
        items.map((l) => {
          const erp = frappeDocUrl(erpnextUrl, l.doctype, l.erpnext_name);
          const med = medusaRecordUrl(l.medusa_entity, l.medusa_id);
          return /* @__PURE__ */ jsxs("tr", { className: "border-b border-ui-border-base last:border-0", children: [
            /* @__PURE__ */ jsx("td", { className: "p-2", children: l.doctype }),
            /* @__PURE__ */ jsx("td", { className: "p-2 font-mono", children: erp ? /* @__PURE__ */ jsx("a", { className: "underline", href: erp, target: "_blank", rel: "noreferrer", children: l.erpnext_name }) : l.erpnext_name }),
            /* @__PURE__ */ jsx("td", { className: "p-2", children: directionLabel(l.remote_direction) }),
            /* @__PURE__ */ jsxs("td", { className: "p-2", children: [
              l.medusa_entity,
              " ",
              /* @__PURE__ */ jsx("span", { className: "font-mono text-xs text-ui-fg-subtle", children: med ? /* @__PURE__ */ jsx("a", { className: "underline", href: med, children: l.medusa_id }) : l.medusa_id })
            ] }),
            /* @__PURE__ */ jsx("td", { className: "p-2", children: /* @__PURE__ */ jsx(StatusBadge, { color: l.state === "drafted" ? "orange" : "green", children: l.state }) }),
            /* @__PURE__ */ jsx("td", { className: "p-2 text-xs text-ui-fg-subtle", children: l.last_seen_at ? new Date(l.last_seen_at).toLocaleString() : "—" })
          ] }, l.id);
        })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-ui-fg-subtle", children: [
      /* @__PURE__ */ jsxs("span", { children: [
        count,
        " document",
        count === 1 ? "" : "s"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: offset === 0, onClick: () => setOffset(Math.max(0, offset - limit)), children: "Previous" }),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: offset + limit >= count, onClick: () => setOffset(offset + limit), children: "Next" })
      ] })
    ] })
  ] });
};
const ReconcileTab = () => {
  const [running, setRunning] = useState(false);
  const [reports, setReports] = useState(null);
  const [generatedAt, setGeneratedAt] = useState(null);
  const [err, setErr] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const run = async () => {
    setRunning(true);
    setErr(null);
    try {
      const res = await fetch("/admin/erpnext/reconcile", { credentials: "include" });
      const body = await res.json();
      if (!res.ok || body?.ok === false) {
        setErr(friendlyErpError(body?.error || `HTTP ${res.status}`));
        return;
      }
      setReports(body.reports ?? []);
      setGeneratedAt(body.generated_at ?? null);
    } catch (e) {
      setErr(friendlyErpError(e?.message));
    } finally {
      setRunning(false);
    }
  };
  return /* @__PURE__ */ jsxs("section", { className: "rounded border border-ui-border-base p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Reconcile" }),
        /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-subtle", size: "small", children: "Compare what Medusa has against ERPNext, per entity. Read-only — nothing is changed." })
      ] }),
      /* @__PURE__ */ jsx(Button, { onClick: run, disabled: running, variant: "primary", children: running ? "Checking…" : "Reconcile now" })
    ] }),
    err && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error", size: "small", children: err }),
    generatedAt && /* @__PURE__ */ jsxs(Text, { className: "text-ui-fg-muted mb-2", size: "xsmall", children: [
      "Last run: ",
      new Date(generatedAt).toLocaleString()
    ] }),
    reports && reports.length > 0 && /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-left text-sm", children: [
      /* @__PURE__ */ jsx("thead", { className: "text-ui-fg-subtle border-b border-ui-border-base", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Entity" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Medusa" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "ERPNext" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Matched" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Missing in ERPNext" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "ERPNext orphans" }),
        /* @__PURE__ */ jsx("th", { className: "py-2 pr-4", children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: reports.map((r) => {
        const key = `${r.entity}:${r.doctype}`;
        const clean = !r.skipped && !r.error && (r.missing_on_frappe_count ?? 0) === 0 && (r.frappe_orphans_count ?? 0) === 0;
        return /* @__PURE__ */ jsxs(React.Fragment, { children: [
          /* @__PURE__ */ jsxs("tr", { className: "border-b border-ui-border-base", children: [
            /* @__PURE__ */ jsxs("td", { className: "py-2 pr-4 font-medium", children: [
              r.entity,
              /* @__PURE__ */ jsxs("span", { className: "text-ui-fg-muted", children: [
                " → ",
                r.doctype
              ] })
            ] }),
            r.skipped || r.error ? /* @__PURE__ */ jsx("td", { className: "text-ui-fg-muted py-2", colSpan: 6, children: r.skipped ? `skipped: ${r.skipped}` : `error: ${r.error}` }) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: r.medusa_count }),
              /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: r.frappe_count }),
              /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: r.matched }),
              /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: (r.missing_on_frappe_count ?? 0) > 0 ? /* @__PURE__ */ jsx(
                "button",
                {
                  className: "text-ui-fg-interactive underline",
                  onClick: () => setExpanded(expanded === key ? null : key),
                  children: r.missing_on_frappe_count
                }
              ) : 0 }),
              /* @__PURE__ */ jsx("td", { className: "py-2 pr-4", children: (r.frappe_orphans_count ?? 0) > 0 ? /* @__PURE__ */ jsx(
                "button",
                {
                  className: "text-ui-fg-interactive underline",
                  onClick: () => setExpanded(expanded === key ? null : key),
                  children: r.frappe_orphans_count
                }
              ) : 0 }),
              /* @__PURE__ */ jsxs("td", { className: "py-2 pr-4", children: [
                clean ? /* @__PURE__ */ jsx(StatusBadge, { color: "green", children: "In sync" }) : /* @__PURE__ */ jsx(StatusBadge, { color: "orange", children: "Drift" }),
                r.truncated && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", className: "ml-1", children: "truncated" })
              ] })
            ] })
          ] }),
          expanded === key && !r.skipped && !r.error && /* @__PURE__ */ jsx("tr", { className: "bg-ui-bg-subtle", children: /* @__PURE__ */ jsxs("td", { colSpan: 7, className: "p-3", children: [
            (r.missing_on_frappe ?? []).length > 0 && /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle mb-1", children: "Missing in ERPNext (in Medusa, not pushed):" }),
              /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "break-all font-mono", children: (r.missing_on_frappe ?? []).join(", ") })
            ] }),
            (r.frappe_orphans ?? []).length > 0 && /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle mb-1", children: "ERPNext orphans (stamped with a Medusa id Medusa no longer has):" }),
              /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "break-all font-mono", children: (r.frappe_orphans ?? []).join(", ") })
            ] })
          ] }) })
        ] }, key);
      }) })
    ] }) }),
    reports && reports.length === 0 && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-muted", size: "small", children: "No reconcilable mappings enabled (customer / product / order)." })
  ] });
};
const config = defineRouteConfig({
  label: "ERPNext",
  icon: ArrowsPointingOut
});
const widgetModule = { widgets: [] };
const routeModule = {
  routes: [
    {
      Component: ErpnextPage,
      path: "/erpnext",
      handle: { label: config.label, translationNs: config.translationNs }
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config.label,
      icon: config.icon,
      path: "/erpnext",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: {} };
const cellRendererModule = {};
const layoutModule = { layouts: [] };
const searchEntityModule = {};
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule,
  cellRendererModule,
  layoutModule,
  searchEntityModule
};
export {
  plugin as default
};
