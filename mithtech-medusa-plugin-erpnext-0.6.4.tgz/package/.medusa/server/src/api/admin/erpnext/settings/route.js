"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = exports.GET = void 0;
const zod_1 = require("zod");
const erpnext_1 = require("../../../../modules/erpnext");
/**
 * GET  /admin/erpnext/settings
 * POST /admin/erpnext/settings
 *
 * Backs the admin "ERPNext Sync" settings page.
 *
 * GET response shape (selected fields, see service for full):
 *   - exists                            — whether a DB row exists yet
 *   - enable_sync                       — kill switch
 *   - erpnext_url                       — base URL (or null)
 *   - frappe_webhook_secret_masked      — "abc…xyz" preview, never raw
 *   - sync_doctypes / erpnext_setup_*   — the selection DocTypes and the
 *                                         last "Set up ERPNext" report
 *   - request_timeout_ms / retry knobs
 *   - env_fallback                      — what env vars currently
 *                                         provide (so the admin UI can
 *                                         show "using env" vs "using
 *                                         saved value")
 *
 * POST contract for secret-typed fields:
 *   - field absent / empty string → leave as-is
 *   - null                        → clear
 *   - other                       → update
 */
const GET = async (req, res) => {
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const view = await erpnext.getSettingsView();
        res.json(view);
    }
    catch (err) {
        res.status(500).json({
            message: err?.message ?? "settings_load_failed",
        });
    }
};
exports.GET = GET;
const SaveSchema = zod_1.z.object({
    enable_sync: zod_1.z.boolean().optional(),
    /** What may happen when a product is created in Medusa. */
    medusa_product_policy: zod_1.z.enum(["off", "link", "create"]).nullable().optional(),
    erpnext_url: zod_1.z.string().nullable().optional(),
    /** Where ERPNext POSTs webhooks; absolute http(s). */
    medusa_public_url: zod_1.z.string().nullable().optional(),
    /** The DocTypes under `medusa_sync` selection, with their modes. */
    sync_doctypes: zod_1.z
        .array(zod_1.z.object({ doctype: zod_1.z.string().min(1), mode: zod_1.z.enum(["allow", "deny"]).optional() }))
        .nullable()
        .optional(),
    /** The secret every Frappe Webhook signs with; secret semantics. */
    frappe_webhook_secret: zod_1.z.string().nullable().optional(),
    /** ISO 3166 region for phone numbers without a country code. */
    phone_region: zod_1.z.string().max(2).nullable().optional(),
    /** Where a pushed document lands; empty falls back to ERPNext's defaults. */
    erpnext_company: zod_1.z.string().nullable().optional(),
    erpnext_price_list: zod_1.z.string().nullable().optional(),
    erpnext_customer_group: zod_1.z.string().nullable().optional(),
    erpnext_territory: zod_1.z.string().nullable().optional(),
    erpnext_shipping_account: zod_1.z.string().nullable().optional(),
    erpnext_taxes_template: zod_1.z.string().nullable().optional(),
    /** Stock and prices, ERPNext → Medusa. */
    sync_stock: zod_1.z.boolean().optional(),
    sync_prices: zod_1.z.boolean().optional(),
    erpnext_warehouse: zod_1.z.string().nullable().optional(),
    medusa_stock_location_id: zod_1.z.string().nullable().optional(),
    erpnext_safety_stock: zod_1.z.number().int().min(0).nullable().optional(),
    erpnext_api_key: zod_1.z.string().nullable().optional(),
    erpnext_api_secret: zod_1.z.string().nullable().optional(),
    request_timeout_ms: zod_1.z.number().int().optional(),
    auto_retry_failed: zod_1.z.boolean().optional(),
    auto_retry_max_attempts: zod_1.z.number().int().optional(),
    auto_retry_min_interval_minutes: zod_1.z.number().int().optional(),
    last_full_resync_at: zod_1.z.string().nullable().optional(),
    /** Outbound safety valve — newline/comma separated record ids,
     *  emails or handles. Empty = no restriction. */
    push_allowlist: zod_1.z.string().nullable().optional(),
    /** Days to keep erpnext_sync_event rows. 0 = keep forever. */
    log_retention_days: zod_1.z.number().int().min(0).max(1825).optional(),
    /** Orders and invoices — this store's choice, honoured by the push. */
    order_document: zod_1.z.string().nullable().optional(),
    invoice_numbering: zod_1.z.enum(["erpnext", "store"]).nullable().optional(),
    store_invoice_prefix: zod_1.z.string().nullable().optional(),
    send_invoice_to_store: zod_1.z.boolean().optional(),
    record_payments: zod_1.z.boolean().optional(),
    /** Medusa payment provider id → ERPNext Mode of Payment; null = the default. */
    payment_modes: zod_1.z.record(zod_1.z.string().min(1), zod_1.z.string()).nullable().optional(),
    invoice_storage: zod_1.z.enum(["local", "s3"]).nullable().optional(),
    invoice_local_dir: zod_1.z.string().nullable().optional(),
    s3_bucket: zod_1.z.string().nullable().optional(),
    s3_region: zod_1.z.string().nullable().optional(),
    s3_endpoint: zod_1.z.string().nullable().optional(),
    s3_prefix: zod_1.z.string().nullable().optional(),
    s3_force_path_style: zod_1.z.boolean().optional(),
    s3_access_key_id: zod_1.z.string().nullable().optional(),
    s3_secret_access_key: zod_1.z.string().nullable().optional(),
    notes: zod_1.z.string().nullable().optional(),
});
const POST = async (req, res) => {
    const parsed = SaveSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            message: "Invalid input",
            errors: parsed.error.flatten(),
        });
        return;
    }
    const adminUserId = req.auth_context?.actor_id ??
        req.auth_context?.app_metadata?.user_id ??
        null;
    const erpnext = req.scope.resolve(erpnext_1.ERPNEXT_MODULE);
    try {
        const view = await erpnext.saveSettings({
            ...parsed.data,
            updated_by_user_id: adminUserId,
        });
        res.json(view);
    }
    catch (err) {
        const message = err?.message ?? "settings_save_failed";
        res.status(/must be an absolute/.test(message) ? 400 : 500).json({ message });
    }
};
exports.POST = POST;
//# sourceMappingURL=route.js.map