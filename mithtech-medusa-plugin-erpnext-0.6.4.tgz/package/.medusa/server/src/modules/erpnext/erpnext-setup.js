"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WEBHOOK_SET_ONCE = exports.CUSTOM_FIELD_MUTABLE = exports.SELECT_OPTIONS = exports.ON_TRASH_CONDITION = exports.ON_UPDATE_CONDITION = exports.CUSTOM_FIELD_LABEL = exports.WEBHOOK_EVENTS = exports.INBOUND_PATH = void 0;
exports.webhookJsonTemplate = webhookJsonTemplate;
exports.customFieldName = customFieldName;
exports.webhookName = webhookName;
exports.inboundUrl = inboundUrl;
exports.buildCustomField = buildCustomField;
exports.buildWebhook = buildWebhook;
exports.webhookUpdatePayload = webhookUpdatePayload;
exports.fingerprintOf = fingerprintOf;
exports.describeSetupFailure = describeSetupFailure;
exports.customFieldMatches = customFieldMatches;
exports.webhookMatches = webhookMatches;
exports.ensureCustomField = ensureCustomField;
exports.ensureWebhook = ensureWebhook;
exports.buildStockWebhooks = buildStockWebhooks;
exports.buildPriceWebhooks = buildPriceWebhooks;
exports.buildInvoiceWebhooks = buildInvoiceWebhooks;
exports.runErpnextSetup = runErpnextSetup;
const crypto_1 = __importDefault(require("crypto"));
const selection_1 = require("./selection");
const invoice_events_1 = require("./invoice-events");
const stock_prices_1 = require("./stock-prices");
/**
 * "Set up ERPNext": everything this plugin needs on the ERPNext side,
 * created over REST so nobody clicks through Desk.
 *
 * Per selection DocType, in this order:
 *   1. Custom Field `<DocType>-medusa_sync` (Select, "Sync to Medusa":
 *      blank / ERPNext → Medusa / Medusa → ERPNext / Both). First,
 *      because a Webhook's condition is validated against a blank
 *      document when the Webhook is saved.
 *   2. Webhook `Medusa Sync: <DocType> on_update` — fires when the
 *      document moves ERPNext → Medusa, or did before this save (so a
 *      deselection arrives once and drafts the product). `on_update` also
 *      runs on insert, so no `after_insert` hook is needed.
 *   3. Webhook `Medusa Sync: <DocType> on_trash` — fires for a document
 *      moving ERPNext → Medusa being deleted.
 *
 * Both Webhooks POST the whole document as JSON, signed with the shared
 * secret, plus the `Content-Type: application/json` header Frappe does not
 * send by itself and Medusa needs in order to keep the raw body.
 *
 * Re-running is safe: a row that already says the right thing is left
 * alone, one that drifted is updated, and the set-once fields
 * (`webhook_doctype`, `webhook_docevent`) are never sent to an existing
 * row. Frappe masks `webhook_secret` on read, so whether the secret is
 * current is decided by a fingerprint kept in the last report.
 *
 * Every builder here is pure; the `ensure*` functions take a client.
 */
exports.INBOUND_PATH = "/webhooks/erpnext-inbound";
/** The two a selection DocType gets. */
exports.WEBHOOK_EVENTS = ["on_update", "on_trash"];
exports.CUSTOM_FIELD_LABEL = "Sync to Medusa";
/** The Python tuple of values under which ERPNext → Medusa applies. */
const PULL_TUPLE = `("${selection_1.DIRECTION_ERPNEXT_TO_MEDUSA}", "${selection_1.DIRECTION_BOTH}")`;
/** Fires for a document that moves ERPNext → Medusa now or did before
 *  this save, and for any change of the field (so a document that stops
 *  being Medusa-owned is noticed). `get_doc_before_save()` is None on
 *  insert and on the blank document Frappe validates the condition
 *  against; `and` short-circuits. */
exports.ON_UPDATE_CONDITION = `doc.get("medusa_sync") in ${PULL_TUPLE} or (doc.get_doc_before_save() and (doc.get_doc_before_save().get("medusa_sync") in ${PULL_TUPLE} or doc.get("medusa_sync") != doc.get_doc_before_save().get("medusa_sync")))`;
exports.ON_TRASH_CONDITION = `doc.get("medusa_sync") in ${PULL_TUPLE}`;
/** Frappe's Select options, one per line. No blank line: "not set" is the
 *  explicit None, and Frappe skips validating an empty value, so documents
 *  left blank before None existed still save. */
exports.SELECT_OPTIONS = selection_1.SELECTION_OPTIONS.join("\n");
/** Frappe renders this with Jinja, `doc` being `as_dict()` and `json`
 *  being `frappe.as_json`, then `json.loads` the result. */
function webhookJsonTemplate(event) {
    return `{"event":${JSON.stringify(event)},"doctype":{{ doc.doctype | json }},"name":{{ doc.name | json }},"doc":{{ doc | json }}}`;
}
function customFieldName(doctype) {
    return `${doctype}-${selection_1.SELECTION_FIELD}`;
}
function webhookName(doctype, event) {
    return `Medusa Sync: ${doctype} ${event}`;
}
function inboundUrl(publicUrl) {
    return `${String(publicUrl ?? "").trim().replace(/\/+$/, "")}${exports.INBOUND_PATH}`;
}
function buildCustomField(doctype, mode) {
    return {
        doctype: "Custom Field",
        dt: doctype,
        fieldname: selection_1.SELECTION_FIELD,
        label: exports.CUSTOM_FIELD_LABEL,
        fieldtype: "Select",
        options: exports.SELECT_OPTIONS,
        default: (0, selection_1.selectionDefault)(mode),
        // Item keeps it next to "Disabled" where a person looks for such
        // switches; any other DocType gets it at the end.
        insert_after: doctype === "Item" ? "disabled" : "append",
        in_standard_filter: 1,
        description: mode === "deny"
            ? "Which way this document syncs with the Medusa store. None keeps it out."
            : "Which way this document syncs with the Medusa store. Leave it on None to keep it out.",
    };
}
/** The fields an update may carry. `insert_after` is deliberately absent:
 *  Frappe rewrites "append" to a real fieldname, so it never compares equal. */
exports.CUSTOM_FIELD_MUTABLE = ["label", "options", "default", "in_standard_filter", "description"];
function buildWebhook(args) {
    return {
        doctype: "Webhook",
        name: webhookName(args.doctype, args.event),
        webhook_doctype: args.doctype,
        webhook_docevent: args.event,
        enabled: 1,
        request_url: inboundUrl(args.publicUrl),
        is_dynamic_url: 0,
        request_method: "POST",
        request_structure: "JSON",
        webhook_json: webhookJsonTemplate(args.event),
        condition: args.condition !== undefined
            ? args.condition
            : args.event === "on_trash"
                ? exports.ON_TRASH_CONDITION
                : exports.ON_UPDATE_CONDITION,
        enable_security: 1,
        webhook_secret: args.secret,
        timeout: 15,
        webhook_headers: [
            { doctype: "Webhook Header", key: "Content-Type", value: "application/json" },
        ],
    };
}
/** Never sent to an existing Webhook: Frappe refuses to change them. */
exports.WEBHOOK_SET_ONCE = ["doctype", "name", "webhook_doctype", "webhook_docevent"];
function webhookUpdatePayload(desired) {
    const out = {};
    for (const [k, v] of Object.entries(desired)) {
        if (!exports.WEBHOOK_SET_ONCE.includes(k))
            out[k] = v;
    }
    return out;
}
function stable(value) {
    if (Array.isArray(value))
        return value.map(stable);
    if (value && typeof value === "object") {
        return Object.keys(value)
            .sort()
            .reduce((acc, k) => {
            acc[k] = stable(value[k]);
            return acc;
        }, {});
    }
    return value;
}
/** Of everything we would send, secret included. */
function fingerprintOf(payload) {
    return crypto_1.default.createHash("sha256").update(JSON.stringify(stable(payload))).digest("hex");
}
function describeSetupFailure(res) {
    if (res.status === 403)
        return "API user needs the System Manager role (ERPNext answered 403)";
    if (res.status === 401)
        return "ERPNext rejected the API key (401)";
    if (res.status === 0)
        return `ERPNext unreachable: ${res.error}`;
    return res.error;
}
function sameText(a, b) {
    return String(a ?? "").trim() === String(b ?? "").trim();
}
function sameFlag(a, b) {
    return Number(a ?? 0) === Number(b ?? 0);
}
function customFieldMatches(existing, desired) {
    return (sameText(existing.label, desired.label) &&
        sameText(existing.fieldtype, desired.fieldtype) &&
        sameText(existing.options, desired.options) &&
        sameText(existing.default, desired.default) &&
        sameFlag(existing.in_standard_filter, desired.in_standard_filter) &&
        sameText(existing.description, desired.description));
}
function webhookMatches(existing, desired) {
    const headersOf = (rows) => (Array.isArray(rows) ? rows : [])
        .map((r) => `${String(r?.key ?? "").trim()}=${String(r?.value ?? "").trim()}`)
        .sort()
        .join("\n");
    return (sameFlag(existing.enabled, desired.enabled) &&
        sameText(existing.request_url, desired.request_url) &&
        sameFlag(existing.is_dynamic_url, desired.is_dynamic_url) &&
        sameText(existing.request_method, desired.request_method) &&
        sameText(existing.request_structure, desired.request_structure) &&
        sameText(existing.webhook_json, desired.webhook_json) &&
        sameText(existing.condition, desired.condition) &&
        sameFlag(existing.enable_security, desired.enable_security) &&
        Number(existing.timeout ?? 0) === Number(desired.timeout ?? 0) &&
        headersOf(existing.webhook_headers) === headersOf(desired.webhook_headers));
}
const CUSTOM_FIELD_PATH = "/api/resource/Custom%20Field";
const WEBHOOK_PATH = "/api/resource/Webhook";
async function ensureCustomField(client, doctype, mode) {
    const name = customFieldName(doctype);
    const desired = buildCustomField(doctype, mode);
    const item = (action, extra = {}) => ({
        kind: "custom_field",
        doctype,
        name,
        action,
        ...extra,
    });
    const got = await client.get(`${CUSTOM_FIELD_PATH}/${encodeURIComponent(name)}`);
    if (got.ok === false && got.status === 404) {
        const created = await client.post(CUSTOM_FIELD_PATH, desired);
        if (created.ok === false)
            return item("error", { error: describeSetupFailure(created) });
        return item("created", {
            detail: mode === "deny"
                ? `default "${selection_1.DIRECTION_BOTH}": every existing document now syncs both ways`
                : `default "${selection_1.DIRECTION_NONE}": choose a direction on the documents to sync`,
        });
    }
    if (got.ok === false)
        return item("error", { error: describeSetupFailure(got) });
    const existing = got.data ?? {};
    if (!sameText(existing.fieldtype, "Select")) {
        return item("error", {
            error: `${name} exists with fieldtype ${existing.fieldtype}; expected Select — delete it in ERPNext and run again`,
        });
    }
    if (customFieldMatches(existing, desired))
        return item("unchanged");
    const patch = {};
    for (const k of exports.CUSTOM_FIELD_MUTABLE)
        patch[k] = desired[k];
    const put = await client.put(`${CUSTOM_FIELD_PATH}/${encodeURIComponent(name)}`, patch);
    if (put.ok === false)
        return item("error", { error: describeSetupFailure(put) });
    return item("updated", { detail: `existing documents keep their current value; a blank one counts as ${selection_1.DIRECTION_NONE}` });
}
async function ensureWebhook(client, desired, previous) {
    const name = String(desired.name);
    const doctype = String(desired.webhook_doctype);
    const fingerprint = fingerprintOf(desired);
    const item = (action, extra = {}) => ({
        kind: "webhook",
        doctype,
        name,
        action,
        fingerprint,
        ...extra,
    });
    const got = await client.get(`${WEBHOOK_PATH}/${encodeURIComponent(name)}`);
    if (got.ok === false && got.status === 404) {
        const created = await client.post(WEBHOOK_PATH, desired);
        if (created.ok === false)
            return item("error", { error: describeSetupFailure(created) });
        return item("created");
    }
    if (got.ok === false)
        return item("error", { error: describeSetupFailure(got) });
    const existing = got.data ?? {};
    if (!sameText(existing.webhook_doctype, desired.webhook_doctype) ||
        !sameText(existing.webhook_docevent, desired.webhook_docevent)) {
        return item("error", {
            error: `${name} exists for ${existing.webhook_doctype} ${existing.webhook_docevent}; rename or delete it in ERPNext`,
        });
    }
    if (webhookMatches(existing, desired) && previous?.fingerprint === fingerprint) {
        return item("unchanged");
    }
    const put = await client.put(`${WEBHOOK_PATH}/${encodeURIComponent(name)}`, webhookUpdatePayload(desired));
    if (put.ok === false)
        return item("error", { error: describeSetupFailure(put) });
    return item("updated");
}
function previousItem(report, kind, name) {
    return (report?.items ?? []).find((i) => i.kind === kind && i.name === name) ?? null;
}
/**
 * The whole sequence for every selection DocType. Item-level failures
 * land in the report rather than throwing, so one DocType's trouble does
 * not hide what happened to the others.
 */
/**
 * Stock, ERPNext → Medusa: a ledger entry at the store's warehouse, and a
 * Sales Order submit or cancel (reserved quantity moves with no ledger
 * entry; the lines are filtered on arrival, since a condition cannot walk
 * a child table without builtins).
 */
function buildStockWebhooks(args) {
    const base = { publicUrl: args.publicUrl, secret: args.secret };
    return [
        buildWebhook({ ...base, doctype: stock_prices_1.STOCK_LEDGER_DOCTYPE, event: "after_insert", condition: (0, stock_prices_1.stockLedgerCondition)(args.warehouse) }),
        buildWebhook({ ...base, doctype: stock_prices_1.SALES_ORDER_DOCTYPE, event: "on_submit", condition: "" }),
        buildWebhook({ ...base, doctype: stock_prices_1.SALES_ORDER_DOCTYPE, event: "on_cancel", condition: "" }),
    ];
}
/** Prices, ERPNext → Medusa: a selling price on the store's list. */
function buildPriceWebhooks(args) {
    const base = { publicUrl: args.publicUrl, secret: args.secret };
    return [
        buildWebhook({ ...base, doctype: stock_prices_1.ITEM_PRICE_DOCTYPE, event: "on_update", condition: (0, stock_prices_1.itemPriceCondition)(args.priceList) }),
        buildWebhook({ ...base, doctype: stock_prices_1.ITEM_PRICE_DOCTYPE, event: "on_trash", condition: (0, stock_prices_1.itemPriceCondition)(args.priceList) }),
    ];
}
/**
 * Invoices, ERPNext → Medusa: a Sales Invoice submitted or cancelled.
 * Unconditioned; whether it bills a store order is decided on arrival.
 */
function buildInvoiceWebhooks(args) {
    const base = { publicUrl: args.publicUrl, secret: args.secret };
    return [
        buildWebhook({ ...base, doctype: invoice_events_1.SALES_INVOICE_DOCTYPE, event: "on_submit", condition: "" }),
        buildWebhook({ ...base, doctype: invoice_events_1.SALES_INVOICE_DOCTYPE, event: "on_cancel", condition: "" }),
    ];
}
async function runErpnextSetup(args) {
    const items = [];
    for (const { doctype, mode } of args.doctypes) {
        const field = await ensureCustomField(args.client, doctype, mode);
        items.push(field);
        for (const event of exports.WEBHOOK_EVENTS) {
            const desired = buildWebhook({ doctype, event, publicUrl: args.publicUrl, secret: args.secret });
            if (field.action === "error") {
                items.push({
                    kind: "webhook",
                    doctype,
                    name: String(desired.name),
                    action: "error",
                    error: "not attempted: the custom field could not be created",
                });
                continue;
            }
            items.push(await ensureWebhook(args.client, desired, previousItem(args.previous, "webhook", String(desired.name))));
        }
    }
    const underSelection = new Set(args.doctypes.map((d) => d.doctype));
    const extra = [
        ...(args.stock ? buildStockWebhooks({ warehouse: args.stock.warehouse, publicUrl: args.publicUrl, secret: args.secret }) : []),
        ...(args.prices ? buildPriceWebhooks({ priceList: args.prices.priceList, publicUrl: args.publicUrl, secret: args.secret }) : []),
        ...(args.invoices ? buildInvoiceWebhooks({ publicUrl: args.publicUrl, secret: args.secret }) : []),
        ...(args.secondaries ?? [])
            .filter((dt, i, all) => dt && !underSelection.has(dt) && all.indexOf(dt) === i)
            .map((dt) => buildWebhook({ doctype: dt, event: "on_update", publicUrl: args.publicUrl, secret: args.secret, condition: "" })),
    ];
    for (const desired of extra) {
        items.push(await ensureWebhook(args.client, desired, previousItem(args.previous, "webhook", String(desired.name))));
    }
    return {
        at: new Date().toISOString(),
        ok: items.every((i) => i.action !== "error"),
        public_url: args.publicUrl,
        inbound_url: inboundUrl(args.publicUrl),
        items,
    };
}
//# sourceMappingURL=erpnext-setup.js.map