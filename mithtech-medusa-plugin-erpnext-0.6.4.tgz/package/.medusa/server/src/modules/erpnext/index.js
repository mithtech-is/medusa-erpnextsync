"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = exports.ERPNEXT_MODULE = void 0;
const utils_1 = require("@medusajs/framework/utils");
const crypto_1 = __importDefault(require("crypto"));
const sync_event_1 = require("./models/sync-event");
const setting_1 = require("./models/setting");
const mapping_1 = require("./models/mapping");
const link_1 = require("./models/link");
const mapping_engine_1 = require("./mapping-engine");
const registry_1 = require("./registry");
const discovery_runtime_1 = require("./discovery-runtime");
const invoice_1 = require("./models/invoice");
const invoice_number_1 = require("./invoice-number");
const mapping_engine_2 = require("./mapping-engine");
const invoice_storage_1 = require("./invoice-storage");
const breakerRules = __importStar(require("./breaker"));
const signature_1 = require("./signature");
const autofill_1 = require("./autofill");
const push_guard_1 = require("./push-guard");
const trigger_1 = require("./trigger");
const pair_identity_1 = require("./pair-identity");
const echo_1 = require("./echo");
const outbound_1 = require("./outbound");
const selection_1 = require("./selection");
const frappe_webhook_1 = require("./frappe-webhook");
const frappe_client_1 = require("./frappe-client");
const push_rest_1 = require("./push-rest");
const erpnext_setup_1 = require("./erpnext-setup");
const doctype_meta_1 = require("./doctype-meta");
const retry_policy_1 = require("./retry-policy");
const secondary_doctypes_1 = require("./secondary-doctypes");
const stock_prices_1 = require("./stock-prices");
const product_policy_1 = require("./product-policy");
const item_gst_1 = require("./item-gst");
const delivery_1 = require("./delivery");
const invoice_events_1 = require("./invoice-events");
const rounding_1 = require("./rounding");
const pull_watermark_1 = require("./pull-watermark");
const order_accounting_1 = require("./order-accounting");
const core_flows_1 = require("@medusajs/medusa/core-flows");
/** Write a dotted path into a plain object, creating what it passes through. */
function setByPath(target, dotted, value) {
    const parts = String(dotted || "").split(".").filter(Boolean);
    if (!parts.length)
        return;
    let cursor = target;
    for (const key of parts.slice(0, -1)) {
        if (typeof cursor[key] !== "object" || cursor[key] === null)
            cursor[key] = {};
        cursor = cursor[key];
    }
    cursor[parts[parts.length - 1]] = value;
}
/**
 * A plausible value for one declared path.
 *
 * Plausible matters more than pretty: a mapping that parses a date or
 * multiplies a number should meet a date and a number here, not the
 * string "sample", or the rehearsal passes and the real push does not.
 */
function placeholderFor(p) {
    switch (p.type) {
        case "number":
            return 1;
        case "boolean":
            return false;
        case "datetime":
            return new Date().toISOString();
        case "array":
            return [];
        case "id":
            return `sample_${String(p.path).replace(/[^a-z0-9]+/gi, "_")}`;
        default:
            return `Sample ${p.label ?? p.path}`;
    }
}
exports.ERPNEXT_MODULE = "erpnext";
// Doctypes whose ERPNext record is a header + a child line-items table.
// A flat field mapping can populate the header, but not the child rows,
// so pushes for these get the extra `medusa_items` / customer fields
// attached from the enriched Medusa order record. See augmentSalesDocPayload.
const SALES_DOCTYPES = new Set(["Sales Order", "Sales Invoice"]);
const DEFAULT_TIMEOUT_MS = 15_000;
const ERROR_TRUNCATE = 1000;
const SINGLETON_KEY = "default";
/** A pull reports this many records by name; the counts cover all of them. */
const PULL_RECORDS_SHOWN = 50;
/**
 * ErpnextModuleService — owns:
 *   1. The `erpnext_sync_event` log table (every sync attempt, both ways).
 *   2. The `erpnext_setting` singleton (URL / secrets / toggles).
 *   3. The `erpnext_mapping` rules and the `erpnext_link` map.
 *
 * ERPNext → Medusa arrives through Frappe core Webhooks
 * (api/webhooks/erpnext-inbound) and the pull job; both go through the
 * mapping engine and the entity registry. Medusa → ERPNext is paused
 * (./outbound.ts) until Phase 2 writes over REST.
 *
 * Failure handling: HTTP failures are caught and logged on the row;
 * the caller never sees a thrown error, so order placement on the
 * storefront is never blocked by an ERPNext outage.
 */
class ErpnextModuleService extends (0, utils_1.MedusaService)({
    ErpnextSyncEvent: sync_event_1.ErpnextSyncEvent,
    ErpnextSetting: setting_1.ErpnextSetting,
    ErpnextMapping: mapping_1.ErpnextMapping,
    ErpnextLink: link_1.ErpnextLink,
    ErpnextInvoice: invoice_1.ErpnextInvoice,
}) {
    /**
     * The legacy full-payload push, which no longer has a transport: the
     * connector is mapping-driven, so an event with no push mapping is
     * logged and skipped. Kept because the bulk-push routes and the retry
     * job still reach it for rows from before the mapping era.
     */
    async forwardEvent(args) {
        const cfg = await this.getActiveConfig();
        if (!cfg.enable_sync) {
            return { ok: true, status: "skipped", reason: "sync-disabled" };
        }
        if (outbound_1.OUTBOUND_PAUSED) {
            await this.upsertEventRow(args, {
                status: "skipped",
                last_error: outbound_1.OUTBOUND_PAUSED_MESSAGE,
                target_url: null,
                action: "paused",
            });
            return (0, outbound_1.pausedResult)();
        }
        const reason = `no push mapping handles ${args.event}; add one under Mappings`;
        await this.upsertEventRow(args, { status: "skipped", last_error: reason, target_url: null, action: "skipped" });
        return { ok: true, status: "skipped", reason: "no-mapping" };
    }
    /** Where the connection stands, for the admin and for the retry job. */
    async breakerState() {
        const row = await this.findSettingsRow();
        return breakerRules.stateOf(row);
    }
    /** Forget the failures and start trying again. What the button does. */
    async closeBreaker() {
        const row = await this.findSettingsRow();
        if (row?.id) {
            await this.updateErpnextSettings({
                id: row.id,
                consecutive_failures: 0,
                tripped_at: null,
            });
        }
        return this.breakerState();
    }
    /**
     * Which enabled mappings name an ERPNext field that no longer exists?
     *
     * ERPNext moves. A customisation is removed, an app is uninstalled, a
     * field is renamed, and a mapping that worked for a year starts
     * referring to nothing. It fails silently — the payload simply stops
     * carrying that field — and somebody notices a month later from the
     * wrong end.
     *
     * The one it finds is switched off, because it cannot do what it says.
     * Only that one: a check that stopped every mapping because one went
     * stale would be worse than the drift.
     *
     * Never throws. It runs from a scheduled job, and a job that dies on
     * one bad mapping stops checking the rest.
     */
    async checkMappingDrift() {
        const report = { checked: 0, flagged: [], cleared: [], errors: [] };
        let mappings = [];
        try {
            mappings = await this.listErpnextMappings({ enabled: true }, { take: 500 });
        }
        catch (err) {
            report.errors.push(describeError(err));
            return report;
        }
        // One fetch per doctype, not per mapping: the meta call crosses the
        // network and several mappings usually share a doctype.
        const fieldsByDoctype = new Map();
        const alwaysValid = new Set([
            "name",
            "owner",
            "creation",
            "modified",
            "docstatus",
            "idx",
            // Link keys. The shipped push presets still name these
            // (`id → medusa_customer_id` and so on) and they are not columns
            // on a vanilla ERPNext; the push is paused, and the Phase 2
            // transport decides what becomes of them. Without this every
            // preset mapping would be switched off the first time this
            // check runs, for fields nobody removed by mistake.
            "medusa_customer_id",
            "medusa_product_id",
            "medusa_variant_id",
            "medusa_order_id",
            "medusa_address_id",
            "medusa_payment_id",
            "medusa_invoice_id",
            "medusa_display_id",
            "medusa_order_source",
            "medusa_payment_method",
            "medusa_payment_reference",
            "medusa_customer_tier",
        ]);
        for (const mapping of mappings) {
            report.checked += 1;
            try {
                const doctype = String(mapping.doctype ?? "").trim();
                const pairs = Array.isArray(mapping.field_mappings) ? mapping.field_mappings : [];
                if (!doctype || !pairs.length)
                    continue;
                if (!fieldsByDoctype.has(doctype)) {
                    let known = null;
                    try {
                        const meta = await this.getDoctypeMeta(doctype);
                        if (meta?.ok && Array.isArray(meta.fields)) {
                            known = new Set(meta.fields
                                .map((f) => String(f?.fieldname ?? ""))
                                .filter(Boolean));
                        }
                    }
                    catch {
                        // ERPNext unreachable. Not knowing is not the same
                        // as knowing it is gone, so say nothing this run.
                        known = null;
                    }
                    fieldsByDoctype.set(doctype, known);
                }
                const known = fieldsByDoctype.get(doctype);
                if (!known)
                    continue;
                const missing = pairs
                    .map((p) => String(p?.erpnext_field ?? p?.frappe_field ?? ""))
                    .filter((f) => f && !known.has(f) && !alwaysValid.has(f));
                if (!missing.length) {
                    if (mapping.attention === "Field Missing") {
                        await this.updateErpnextMappings({
                            id: mapping.id,
                            attention: null,
                            attention_detail: null,
                        });
                        report.cleared.push(mapping.name ?? mapping.id);
                    }
                    continue;
                }
                const detail = `${doctype} no longer has: ${missing.join(", ")}. This mapping is switched ` +
                    `off until it does, or until the field map stops asking for it.`;
                await this.updateErpnextMappings({
                    id: mapping.id,
                    enabled: false,
                    attention: "Field Missing",
                    attention_detail: detail,
                    version: Number(mapping.version ?? 1) + 1,
                });
                report.flagged.push({ name: mapping.name ?? mapping.id, missing });
            }
            catch (err) {
                report.errors.push({ mapping: mapping?.name ?? mapping?.id, error: describeError(err) });
            }
        }
        return report;
    }
    /** Every mapping waiting on somebody. What a dashboard would show. */
    async mappingsNeedingAttention() {
        try {
            const rows = await this.listErpnextMappings({ attention: { $ne: null } }, { take: 200 });
            return rows;
        }
        catch {
            return [];
        }
    }
    // ─────────────────────────────────────────────────────────────────
    // Invoices customers can download
    // ─────────────────────────────────────────────────────────────────
    /**
     * The store's own number for an order's invoice, when this store
     * numbers invoices itself. Idempotent per order: a retried push must
     * carry the number the first attempt took, not burn another.
     *
     * The running number is taken in one UPDATE … RETURNING, so two
     * orders placed in the same instant can never share a number.
     *
     * The read below cannot settle it alone: a subscriber and the retry
     * job can both find no row and both go on to allocate, and since each
     * takes a distinct number the unique index on `number` would not
     * notice. UQ_erpnext_invoice_store_order — one store invoice per
     * order — is what actually decides the winner, and the loser adopts
     * the number that won rather than issuing a second invoice. That
     * leaves the loser's number unused, a gap in the series being the
     * cheaper fault of the two.
     */
    async allocateStoreInvoiceNumber(scope, orderId, customerId) {
        const row = await this.findSettingsRow();
        if (!(0, invoice_number_1.storeNumbers)(row))
            return null;
        const [existing] = await this.listErpnextInvoices({ order_id: orderId, source: "store" }, { take: 1 });
        if (existing)
            return existing.number;
        if (!row?.store_invoice_prefix) {
            throw new Error("this store numbers its invoices but has no invoice prefix; set one under Orders and invoices");
        }
        const pg = scope.resolve("__pg_connection__");
        const result = await pg.raw(`UPDATE "erpnext_setting" SET store_invoice_next = store_invoice_next + 1
              WHERE singleton_key = ? RETURNING store_invoice_next - 1 AS n`, [SINGLETON_KEY]);
        const n = Number(result?.rows?.[0]?.n);
        const number = (0, invoice_number_1.formatInvoiceNumber)(row.store_invoice_prefix, n);
        try {
            await this.createErpnextInvoices([
                { order_id: orderId, customer_id: customerId ?? null, number, source: "store", status: "issued" },
            ]);
        }
        catch (e) {
            if (!isUniqueViolation(e))
                throw e;
            const [won] = await this.listErpnextInvoices({ order_id: orderId, source: "store" }, { take: 1 });
            if (!won)
                throw e;
            return won.number;
        }
        return number;
    }
    /**
     * ERPNext issued an invoice for an order. Record it, and when this
     * store takes ERPNext's invoices, fetch the PDF into private storage.
     * A failed fetch is recorded on the row rather than failing the event:
     * the invoice facts are already correct, and the PDF can be fetched
     * again from the admin.
     */
    async receiveErpInvoice(scope, data) {
        const orderId = String(data?.medusa_order_id ?? "").trim();
        const number = String(data?.invoice_number ?? "").trim();
        if (!orderId || !number)
            return { skipped: "missing order or invoice number" };
        const settings = await this.findSettingsRow();
        const orderSvc = scope.resolve("order");
        const [order] = await orderSvc.listOrders({ id: orderId }, { take: 1, select: ["id", "customer_id"] });
        const facts = {
            order_id: orderId,
            customer_id: order?.customer_id ?? null,
            number,
            source: "erpnext",
            invoice_date: data?.invoice_date ?? null,
            total: data?.grand_total != null ? Number(data.grand_total) : null,
            currency: data?.currency ?? null,
            status: data?.status ?? null,
        };
        const [existing] = await this.listErpnextInvoices({ number }, { take: 1 });
        const invoice = existing
            ? (await this.updateErpnextInvoices([{ id: existing.id, ...facts }]))[0]
            : (await this.createErpnextInvoices([facts]))[0];
        if (!data?.pdf || !(0, invoice_number_1.receivesErpInvoices)(settings))
            return { id: invoice.id, pdf: "not requested" };
        return { id: invoice.id, pdf: await this.fetchInvoicePdf(invoice.id, data.pdf) };
    }
    /** Pull one invoice PDF from ERPNext and keep it privately. */
    async fetchInvoicePdf(invoiceId, pdf) {
        const [invoice] = await this.listErpnextInvoices({ id: invoiceId }, { take: 1 });
        if (!invoice)
            return { ok: false, error: "no such invoice" };
        const cfg = await this.getActiveConfig();
        const creds = await this.getApiCredentials();
        const settings = await this.findSettingsRow();
        try {
            if (!cfg.erpnext_url || !creds.api_key || !creds.api_secret) {
                throw new Error("ERPNext URL or API credentials are not configured");
            }
            const params = new URLSearchParams({
                doctype: pdf?.doctype || "Sales Invoice",
                name: pdf?.name || invoice.number,
            });
            if (pdf?.print_format)
                params.set("format", pdf.print_format);
            const res = await fetch(`${cfg.erpnext_url}/api/method/frappe.utils.print_format.download_pdf?${params}`, {
                headers: { Authorization: `token ${creds.api_key}:${creds.api_secret}` },
                signal: AbortSignal.timeout(Math.max(cfg.request_timeout_ms, 30_000)),
            });
            if (!res.ok)
                throw new Error(`ERPNext answered HTTP ${res.status} for the invoice PDF`);
            const bytes = Buffer.from(await res.arrayBuffer());
            if (bytes.subarray(0, 4).toString() !== "%PDF")
                throw new Error("ERPNext did not return a PDF");
            const storage = (0, invoice_storage_1.storageFor)(settings ?? {});
            const key = (0, invoice_storage_1.invoiceKey)(invoice.order_id, invoice.number);
            await storage.put(key, bytes, "application/pdf");
            await this.updateErpnextInvoices([
                {
                    id: invoice.id,
                    storage: storage.kind,
                    object_key: key,
                    content_type: "application/pdf",
                    size_bytes: bytes.length,
                    fetched_at: new Date(),
                    fetch_error: null,
                },
            ]);
            return { ok: true, size_bytes: bytes.length, storage: storage.kind };
        }
        catch (e) {
            const error = String(e?.message ?? e).slice(0, ERROR_TRUNCATE);
            await this.updateErpnextInvoices([{ id: invoice.id, fetch_error: error }]);
            return { ok: false, error };
        }
    }
    /** Invoices for one order, newest first, without storage internals. */
    /**
     * The GST on an order as ERPNext computed it: the Sales Invoice when
     * one exists, else the Sales Order. Null when ERPNext has neither yet
     * or cannot be read; the storefront then shows Medusa's own lines.
     */
    async gstForOrder(orderId) {
        const rest = await this.restClient(STORE_TIMEOUT_MS);
        if (!rest)
            return null;
        for (const [entity, doctype] of [["invoice", "Sales Invoice"], ["order", "Sales Order"]]) {
            const link = await this.remoteNameFor(entity, orderId, doctype);
            if (!link?.erpnext_name)
                continue;
            const res = await rest.client.get(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(link.erpnext_name)}`);
            if (res.ok !== true || !res.data)
                continue;
            const d = res.data;
            if (Number(d.docstatus) === 2)
                continue;
            const n = (v) => (v === null || v === undefined || v === "" ? null : Number(v));
            return {
                doctype,
                name: String(d.name),
                docstatus: Number(d.docstatus),
                place_of_supply: d.place_of_supply ?? null,
                company_gstin: d.company_gstin ?? null,
                billing_address_gstin: d.billing_address_gstin ?? null,
                items: (Array.isArray(d.items) ? d.items : []).map((it) => ({
                    item_code: it.item_code,
                    item_name: it.item_name,
                    hsn: it.gst_hsn_code ?? null,
                    qty: n(it.qty),
                    rate: n(it.rate),
                    net_amount: n(it.net_amount),
                    taxable_value: n(it.taxable_value),
                    cgst_rate: n(it.cgst_rate),
                    cgst_amount: n(it.cgst_amount),
                    sgst_rate: n(it.sgst_rate),
                    sgst_amount: n(it.sgst_amount),
                    igst_rate: n(it.igst_rate),
                    igst_amount: n(it.igst_amount),
                })),
                taxes: (Array.isArray(d.taxes) ? d.taxes : []).map((t) => ({
                    description: t.description ?? t.account_head,
                    gst_tax_type: t.gst_tax_type ?? null,
                    tax_amount: n(t.tax_amount_after_discount_amount ?? t.tax_amount),
                })),
                net_total: n(d.net_total),
                total_taxes_and_charges: n(d.total_taxes_and_charges),
                grand_total: n(d.grand_total),
                rounding_adjustment: n(d.rounding_adjustment),
                rounded_total: n(d.rounded_total),
            };
        }
        return null;
    }
    async invoicesForOrder(orderId) {
        const rows = await this.listErpnextInvoices({ order_id: orderId }, { order: { created_at: "DESC" } });
        return rows.map((r) => ({
            id: r.id,
            number: r.number,
            source: r.source,
            invoice_date: r.invoice_date,
            total: r.total,
            currency: r.currency,
            status: r.status,
            downloadable: (0, invoice_events_1.isDownloadable)(r),
        }));
    }
    /** The stored PDF for one invoice, or null. Callers check ownership. */
    /**
     * Keep the customers' invoice copies current: an invoice ERPNext has
     * since submitted (or cancelled) gets its status and PDF refreshed;
     * one never fetched is fetched. Runs from the hourly reconcile.
     */
    async refreshInvoicePdfs(limit = 50) {
        const settings = await this.findSettingsRow();
        if (!(0, invoice_number_1.receivesErpInvoices)(settings))
            return { skipped: "off", checked: 0, refreshed: 0, failed: 0 };
        const rest = await this.restClient();
        if (!rest)
            return { skipped: "not-configured", checked: 0, refreshed: 0, failed: 0 };
        const rows = await this.listErpnextInvoices({ source: "erpnext", status: { $ne: "submitted" } }, { take: limit, order: { created_at: "DESC" } });
        let refreshed = 0;
        let failed = 0;
        for (const inv of rows) {
            const doc = await rest.client.get(`/api/resource/Sales%20Invoice/${encodeURIComponent(String(inv.number))}`);
            if (doc.ok === false) {
                if (doc.status === 404)
                    await this.updateErpnextInvoices([{ id: inv.id, status: "deleted" }]);
                else
                    failed += 1;
                continue;
            }
            const docstatus = Number(doc.data?.docstatus ?? 0);
            const status = docstatus === 1 ? "submitted" : docstatus === 2 ? "cancelled" : "draft";
            const changed = status !== inv.status;
            if (changed)
                await this.updateErpnextInvoices([{ id: inv.id, status }]);
            if (status !== "submitted")
                continue;
            if (changed || !inv.fetched_at) {
                const r = await this.fetchInvoicePdf(inv.id);
                if (r.ok)
                    refreshed += 1;
                else
                    failed += 1;
            }
        }
        return { checked: rows.length, refreshed, failed };
    }
    async openInvoice(invoiceId) {
        const [invoice] = await this.listErpnextInvoices({ id: invoiceId }, { take: 1 });
        if (!invoice || !(0, invoice_events_1.isDownloadable)(invoice))
            return null;
        const settings = await this.findSettingsRow();
        const read = (row) => (0, invoice_storage_1.storageFor)({ ...(settings ?? {}), invoice_storage: row.storage }).get(row.object_key);
        let object = await read(invoice);
        // A lost file (storage moved, a volume recreated) is fetched from
        // ERPNext again rather than leaving the customer without an invoice.
        if (!object && (await this.fetchInvoicePdf(invoice.id)).ok) {
            const [again] = await this.listErpnextInvoices({ id: invoiceId }, { take: 1 });
            object = again ? await read(again) : null;
        }
        return object ? { invoice, object } : null;
    }
    /**
     * A Sales Invoice was submitted or cancelled in ERPNext. When it bills
     * a store order, record it against the order and, once submitted, keep
     * ERPNext's PDF of it for the customer. A failed fetch fails the event,
     * so the retry job fetches again.
     */
    async applySalesInvoiceEvent(body, scope) {
        const done = (result) => ({ via: "frappe", event: String(body.event), results: [result] });
        if (!(0, invoice_number_1.receivesErpInvoices)((await this.findSettingsRow()))) {
            return done({ ok: true, action: "skipped", reason: "customers are not sent ERPNext's invoices" });
        }
        const doc = body.doc ?? {};
        const number = String(body.name ?? doc.name ?? "").trim();
        const orderId = number ? await this.orderForSalesInvoice(number, doc) : null;
        if (!orderId)
            return done({ ok: true, action: "skipped", reason: "not a store order's invoice" });
        const status = (0, invoice_events_1.invoiceStatusOf)(String(body.event), doc.docstatus);
        const orderSvc = scope.resolve("order");
        const [order] = await orderSvc.listOrders({ id: orderId }, { take: 1, select: ["id", "customer_id"] });
        const facts = {
            order_id: orderId,
            customer_id: order?.customer_id ?? null,
            number,
            source: "erpnext",
            invoice_date: doc.posting_date ?? null,
            total: (0, invoice_events_1.invoiceTotalOf)(doc),
            currency: doc.currency ? String(doc.currency).toUpperCase() : null,
            status,
        };
        const [known] = await this.listErpnextInvoices({ number }, { take: 1 });
        const saved = known
            ? (await this.updateErpnextInvoices([{ id: known.id, ...facts }]))[0]
            : (await this.createErpnextInvoices([facts]))[0];
        if (status !== "submitted") {
            return done({ ok: true, entity: "order", id: orderId, action: `invoice ${number} ${status}` });
        }
        await this.recordLink({
            doctype: invoice_events_1.SALES_INVOICE_DOCTYPE,
            erpnext_name: number,
            medusa_entity: "invoice",
            medusa_id: orderId,
            state: "active",
        });
        const pdf = await this.fetchInvoicePdf(saved.id);
        return pdf.ok
            ? done({ ok: true, entity: "order", id: orderId, action: `invoice ${number} fetched` })
            : done({ ok: false, entity: "order", id: orderId, error: `invoice ${number}: ${pdf.error}` });
    }
    /** The store order a Sales Invoice bills: one the store raised, else one whose Sales Order it bills. */
    async orderForSalesInvoice(number, doc) {
        const [known] = await this.listErpnextInvoices({ number }, { take: 1 });
        if (known?.order_id)
            return String(known.order_id);
        const [raised] = await this.listErpnextLinks({ doctype: invoice_events_1.SALES_INVOICE_DOCTYPE, erpnext_name: number, medusa_entity: "invoice" }, { take: 1 });
        if (raised?.medusa_id)
            return String(raised.medusa_id);
        for (const so of (0, invoice_events_1.salesOrdersBilled)(doc?.items)) {
            const [link] = await this.listErpnextLinks({ doctype: "Sales Order", erpnext_name: so, medusa_entity: "order" }, { take: 1 });
            if (link?.medusa_id)
                return String(link.medusa_id);
        }
        return null;
    }
    async upsertInboundEventRow(args, patch) {
        const [existing] = await this.listErpnextSyncEvents({ event_id: args.event_id, direction: "inbound" }, { take: 1 });
        const now = new Date();
        if (existing) {
            const [updated] = await this.updateErpnextSyncEvents([
                {
                    id: existing.id,
                    attempts: (existing.attempts ?? 0) + 1,
                    last_attempt_at: now,
                    payload: args.data,
                    event: args.event,
                    ...patch,
                },
            ]);
            return updated;
        }
        const [created] = await this.createErpnextSyncEvents([
            {
                event: args.event,
                event_id: args.event_id,
                payload: args.data,
                attempts: 1,
                last_attempt_at: now,
                target_url: null,
                direction: "inbound",
                ...patch,
            },
        ]);
        return created;
    }
    /**
     * Re-attempt a previously failed (or skipped) event from its stored
     * payload. An inbound row is re-applied through the same executor the
     * webhook route uses; an outbound row waits for Phase 2.
     */
    async retryEvent(eventId, scope, opts) {
        const [row] = await this.listErpnextSyncEvents({ event_id: eventId }, { take: 1 });
        if (!row) {
            return {
                ok: false,
                status: "failed",
                error: `no row for event_id=${eventId}`,
            };
        }
        if (row.direction === "inbound") {
            if (!scope) {
                return {
                    ok: false,
                    status: "failed",
                    error: "inbound event retry needs a request scope",
                };
            }
            const replayed = await this.replayInboundEvent(row, scope);
            return replayed.ok
                ? { ok: true, status: "success" }
                : { ok: false, status: "failed", error: replayed.error ?? "replay failed" };
        }
        if (outbound_1.OUTBOUND_PAUSED)
            return (0, outbound_1.pausedResult)();
        if (row.mapping_id) {
            // A newer push of the same record has its own row; this one
            // holds an older snapshot and is not resent (retry-policy.ts).
            if (!row.entity_ref && row.payload?.id != null) {
                const [m] = await this.listErpnextMappings({ id: row.mapping_id }, { take: 1 });
                if (m?.medusa_entity)
                    row.entity_ref = `${m.medusa_entity}:${String(row.payload.id)}`;
            }
            if (row.entity_ref && row.created_at) {
                const later = await this.listErpnextSyncEvents({ entity_ref: row.entity_ref, mapping_id: row.mapping_id, created_at: { $gt: row.created_at } }, { take: 20 });
                if ((0, retry_policy_1.supersededByLater)(row, later)) {
                    await this.updateErpnextSyncEvents([
                        { id: row.id, status: "skipped", action: "superseded", last_error: retry_policy_1.SUPERSEDED_MESSAGE },
                    ]);
                    return { ok: true, status: "skipped", reason: "superseded" };
                }
            }
            const [mapping] = await this.listErpnextMappings({ id: row.mapping_id }, { take: 1 });
            if (mapping) {
                return this.pushViaMapping({
                    mapping,
                    event: row.event,
                    event_id: row.event_id,
                    record: row.payload,
                    container: scope,
                });
            }
        }
        return this.forwardEvent({
            event: row.event,
            event_id: row.event_id,
            data: row.payload,
            probe: opts?.probe === true,
        });
    }
    /**
     * List the most recent failed/skipped events, oldest-attempt first
     * — the order a retry job would process them in.
     */
    async listFailedForRetry(limit = 50) {
        return this.listErpnextSyncEvents(
        // A rehearsal that failed is information, not a delivery owed
        // to anyone. Retrying one would send a fabricated payload for
        // real, which is the opposite of what a dry run is for. A row
        // still "pending" is one a crash left mid-apply; the job's age
        // check keeps a live one out.
        { status: ["failed", "skipped", "pending"], is_test: false }, { take: limit, order: { last_attempt_at: "ASC" } });
    }
    async upsertEventRow(args, patch) {
        const [existing] = await this.listErpnextSyncEvents({ event_id: args.event_id }, { take: 1 });
        const now = new Date();
        if (existing) {
            const [updated] = await this.updateErpnextSyncEvents([
                {
                    id: existing.id,
                    attempts: (existing.attempts ?? 0) + 1,
                    last_attempt_at: now,
                    payload: args.data,
                    event: args.event,
                    ...patch,
                },
            ]);
            return updated;
        }
        const [created] = await this.createErpnextSyncEvents([
            {
                event: args.event,
                event_id: args.event_id,
                payload: args.data,
                attempts: 1,
                last_attempt_at: now,
                ...patch,
            },
        ]);
        return created;
    }
    /**
     * The row's current values with secrets masked, or defaults when no
     * row exists yet. Never the raw secrets — `getActiveConfig` and
     * `getFrappeWebhookSecret` are for those.
     */
    async getSettingsView() {
        const row = await this.findSettingsRow();
        const envFallback = {
            erpnext_url: process.env.ERPNEXT_URL ?? null,
            frappe_webhook_secret_present: Boolean(process.env.ERPNEXT_FRAPPE_WEBHOOK_SECRET),
            medusa_public_url: process.env.MEDUSA_BACKEND_URL ?? null,
        };
        if (!row) {
            return {
                exists: false,
                enable_sync: true,
                erpnext_url: null,
                medusa_public_url: null,
                frappe_webhook_secret_masked: maskSecret(process.env.ERPNEXT_FRAPPE_WEBHOOK_SECRET),
                erpnext_api_key_masked: null,
                erpnext_api_secret_masked: null,
                sync_doctypes: selection_1.DEFAULT_SYNC_DOCTYPES,
                erpnext_setup_at: null,
                erpnext_setup_report: null,
                phone_region: DEFAULT_PHONE_REGION,
                ...pushSettingsView(null),
                medusa_product_policy: product_policy_1.DEFAULT_PRODUCT_POLICY,
                request_timeout_ms: DEFAULT_TIMEOUT_MS,
                auto_retry_failed: true,
                auto_retry_max_attempts: 5,
                auto_retry_min_interval_minutes: 15,
                last_full_resync_at: null,
                push_allowlist: null,
                log_retention_days: 180,
                ...invoiceSettingsView(null),
                notes: null,
                updated_by_user_id: null,
                outbound_paused: outbound_1.OUTBOUND_PAUSED,
                env_fallback: envFallback,
            };
        }
        // Which syncs put each DocType under selection, so the Settings
        // page can say why a DocType is listed and why another is not.
        const pullMappings = (await this.listErpnextMappings({}, { take: 1000 })).filter((m) => String(m.direction ?? "both").toLowerCase() !== "push");
        const selection_sources = syncDoctypesOf(row).map((d) => ({
            ...d,
            syncs: pullMappings.filter((m) => m.doctype === d.doctype).map((m) => String(m.name)),
        }));
        return {
            exists: true,
            selection_sources,
            enable_sync: row.enable_sync,
            medusa_product_policy: (0, product_policy_1.normalizeProductPolicy)(row.medusa_product_policy),
            erpnext_url: row.erpnext_url,
            medusa_public_url: row.medusa_public_url ?? null,
            frappe_webhook_secret_masked: maskSecret(row.frappe_webhook_secret),
            erpnext_api_key_masked: maskSecret(row.erpnext_api_key),
            erpnext_api_secret_masked: maskSecret(row.erpnext_api_secret),
            sync_doctypes: syncDoctypesOf(row),
            erpnext_setup_at: row.erpnext_setup_at ?? null,
            erpnext_setup_report: row.erpnext_setup_report ?? null,
            phone_region: phoneRegionOf(row),
            ...pushSettingsView(row),
            ...stockSettingsView(row),
            request_timeout_ms: row.request_timeout_ms,
            auto_retry_failed: row.auto_retry_failed,
            auto_retry_max_attempts: row.auto_retry_max_attempts,
            auto_retry_min_interval_minutes: row.auto_retry_min_interval_minutes,
            last_full_resync_at: row.last_full_resync_at,
            // Not a secret — the operator must be able to read and edit
            // the list, so it is returned in full rather than masked.
            push_allowlist: row.push_allowlist ?? null,
            log_retention_days: row.log_retention_days ?? 180,
            ...invoiceSettingsView(row),
            notes: row.notes,
            updated_by_user_id: row.updated_by_user_id,
            outbound_paused: outbound_1.OUTBOUND_PAUSED,
            env_fallback: envFallback,
        };
    }
    /**
     * Persist the settings row.
     *
     * Secret-field semantics:
     *   - `undefined` (key absent)  → leave as-is
     *   - `""` (empty string)       → leave as-is (admin UI sends ""
     *                                  when the user didn't touch the
     *                                  field, since it shows the
     *                                  masked preview as a placeholder)
     *   - `null`                    → clear the field
     *   - any other string          → update
     */
    async saveSettings(input) {
        const existing = await this.findSettingsRow();
        const patch = {};
        if (input.enable_sync !== undefined)
            patch.enable_sync = input.enable_sync;
        if ("medusa_product_policy" in input) {
            patch.medusa_product_policy = (0, product_policy_1.normalizeProductPolicy)(input.medusa_product_policy);
        }
        if ("erpnext_url" in input) {
            patch.erpnext_url = normaliseUrl(input.erpnext_url);
        }
        if ("medusa_public_url" in input) {
            const raw = publicUrlOf(input.medusa_public_url);
            if (input.medusa_public_url && !raw) {
                throw new Error("medusa_public_url must be an absolute http(s) URL");
            }
            patch.medusa_public_url = raw;
        }
        if ("sync_doctypes" in input) {
            patch.sync_doctypes = (0, selection_1.normalizeSyncDoctypes)(input.sync_doctypes);
        }
        applySecret(patch, "frappe_webhook_secret", input.frappe_webhook_secret);
        if ("phone_region" in input) {
            patch.phone_region = phoneRegionOf({ phone_region: input.phone_region });
        }
        for (const key of PUSH_SETTING_KEYS) {
            if (key in input)
                patch[key] = String(input[key] ?? "").trim() || null;
        }
        for (const key of ["erpnext_warehouse", "medusa_stock_location_id"]) {
            if (key in input)
                patch[key] = String(input[key] ?? "").trim() || null;
        }
        if (input.sync_stock !== undefined)
            patch.sync_stock = Boolean(input.sync_stock);
        if (input.sync_prices !== undefined)
            patch.sync_prices = Boolean(input.sync_prices);
        if (input.erpnext_safety_stock !== undefined) {
            patch.erpnext_safety_stock = Math.max(0, Math.floor(Number(input.erpnext_safety_stock) || 0));
        }
        applySecret(patch, "erpnext_api_key", input.erpnext_api_key);
        applySecret(patch, "erpnext_api_secret", input.erpnext_api_secret);
        if (input.request_timeout_ms !== undefined) {
            patch.request_timeout_ms = clampInt(input.request_timeout_ms, 1000, 120_000);
        }
        if (input.auto_retry_failed !== undefined) {
            patch.auto_retry_failed = input.auto_retry_failed;
        }
        if (input.auto_retry_max_attempts !== undefined) {
            patch.auto_retry_max_attempts = clampInt(input.auto_retry_max_attempts, 1, 100);
        }
        if (input.auto_retry_min_interval_minutes !== undefined) {
            patch.auto_retry_min_interval_minutes = clampInt(input.auto_retry_min_interval_minutes, 1, 1440);
        }
        if ("last_full_resync_at" in input) {
            patch.last_full_resync_at = input.last_full_resync_at
                ? new Date(input.last_full_resync_at)
                : null;
        }
        if ("push_allowlist" in input) {
            const raw = (input.push_allowlist ?? "").trim();
            patch.push_allowlist = raw || null;
        }
        if (input.log_retention_days !== undefined) {
            // 0 = keep forever. Cap at ~5 years so a fat-fingered value
            // can't turn the event table into an unbounded PII archive.
            patch.log_retention_days = clampInt(input.log_retention_days, 0, 1825);
        }
        applyInvoiceSettings(patch, input);
        if ("notes" in input)
            patch.notes = input.notes ?? null;
        if ("updated_by_user_id" in input) {
            patch.updated_by_user_id = input.updated_by_user_id ?? null;
        }
        if (existing) {
            await this.updateErpnextSettings([{ id: existing.id, ...patch }]);
        }
        else {
            await this.createErpnextSettings([
                { singleton_key: SINGLETON_KEY, ...patch },
            ]);
        }
        return this.getSettingsView();
    }
    /**
     * The *effective* config: row values, falling back to env per field.
     */
    async getActiveConfig() {
        const row = await this.findSettingsRow();
        const erpnext_url = (row?.erpnext_url || process.env.ERPNEXT_URL || "").replace(/\/$/, "") || null;
        const frappe_webhook_secret = row?.frappe_webhook_secret || process.env.ERPNEXT_FRAPPE_WEBHOOK_SECRET || null;
        const url_source = row?.erpnext_url
            ? "row"
            : process.env.ERPNEXT_URL
                ? "env"
                : "missing";
        const secret_source = row
            ?.frappe_webhook_secret
            ? "row"
            : process.env.ERPNEXT_FRAPPE_WEBHOOK_SECRET
                ? "env"
                : "missing";
        return {
            enable_sync: row?.enable_sync ?? true,
            medusa_product_policy: (0, product_policy_1.normalizeProductPolicy)(row?.medusa_product_policy),
            sync_doctypes: syncDoctypesOf(row),
            erpnext_url,
            frappe_webhook_secret,
            medusa_public_url: publicUrlOf(row?.medusa_public_url ?? process.env.MEDUSA_BACKEND_URL ?? null),
            erpnext_setup_report: row?.erpnext_setup_report ?? null,
            request_timeout_ms: row?.request_timeout_ms ?? DEFAULT_TIMEOUT_MS,
            sync_stock: Boolean(row?.sync_stock),
            sync_prices: Boolean(row?.sync_prices),
            erpnext_warehouse: row?.erpnext_warehouse || null,
            medusa_stock_location_id: row?.medusa_stock_location_id || null,
            erpnext_safety_stock: Number(row?.erpnext_safety_stock) || 0,
            auto_retry_failed: row?.auto_retry_failed ?? true,
            auto_retry_max_attempts: row?.auto_retry_max_attempts ?? 5,
            auto_retry_min_interval_minutes: row?.auto_retry_min_interval_minutes ?? 15,
            source: { url: url_source, secret: secret_source },
        };
    }
    async findSettingsRow() {
        const [row] = await this.listErpnextSettings({ singleton_key: SINGLETON_KEY }, { take: 1 });
        return row;
    }
    /**
     * Public accessor for the Frappe API token-auth credentials
     * (api_key + api_secret). Pulls from the settings row first, falls
     * back to env vars (matching the pattern in pingErpnext / listing
     * helpers). Used by jobs that need to call Frappe's REST API
     * directly outside the webhook-HMAC path — e.g. the reconciliation
     * cron's missing-on-Frappe customer recovery, which needs to list
     * Frappe Customer emails. Returns `null`s when unconfigured so
     * callers can soft-skip instead of throwing.
     */
    async getApiCredentials() {
        const row = await this.findSettingsRow();
        return {
            api_key: row?.erpnext_api_key ?? process.env.ERPNEXT_API_KEY ?? null,
            api_secret: row?.erpnext_api_secret ??
                process.env.ERPNEXT_API_SECRET ??
                null,
        };
    }
    // ─────────────────────────────────────────────────────────────────
    // ERPNext API client surface (pull / ping / setup)
    //
    // Everything this side asks ERPNext uses Frappe's standard token
    // auth (Authorization: token <api_key>:<api_secret>). Inbound
    // webhooks are verified with the separate `frappe_webhook_secret`.
    // ─────────────────────────────────────────────────────────────────
    /**
     * Ping ERPNext using the stored API key/secret. Hits Frappe's
     * built-in `frappe.auth.get_logged_user`, which echoes the user
     * the keys belong to. Useful as a "are credentials valid?" check
     * from the admin UI.
     */
    async pingErpnext() {
        const cfg = await this.getActiveConfig();
        const row = await this.findSettingsRow();
        const apiKey = row?.erpnext_api_key ?? process.env.ERPNEXT_API_KEY ?? null;
        const apiSecret = row?.erpnext_api_secret ?? process.env.ERPNEXT_API_SECRET ?? null;
        if (!cfg.erpnext_url) {
            return { ok: false, url: null, message: "erpnext_url not configured" };
        }
        if (!apiKey || !apiSecret) {
            return {
                ok: false,
                url: cfg.erpnext_url,
                message: "erpnext_api_key / erpnext_api_secret not configured",
            };
        }
        try {
            const res = await fetch(`${cfg.erpnext_url}/api/method/frappe.auth.get_logged_user`, {
                method: "GET",
                headers: {
                    Authorization: `token ${apiKey}:${apiSecret}`,
                },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            const text = await res.text().catch(() => "");
            if (!res.ok) {
                return {
                    ok: false,
                    url: cfg.erpnext_url,
                    httpStatus: res.status,
                    message: text.slice(0, 300) || `HTTP ${res.status}`,
                };
            }
            // Frappe returns { message: "user@example.com" }
            let user;
            try {
                const parsed = JSON.parse(text);
                user = parsed?.message;
            }
            catch {
                /* swallow */
            }
            return { ok: true, url: cfg.erpnext_url, user };
        }
        catch (err) {
            return {
                ok: false,
                url: cfg.erpnext_url,
                message: describeError(err).slice(0, 300),
            };
        }
    }
    /**
     * Generic Frappe REST `GET /api/resource/<doctype>` proxy. Returns
     * the raw body — caller decides how to use it. Caps `limit_page_length`
     * to keep responses manageable from an admin button click.
     */
    async pullDoctype(doctype, params = {}) {
        const cfg = await this.getActiveConfig();
        const row = await this.findSettingsRow();
        const apiKey = row?.erpnext_api_key ?? process.env.ERPNEXT_API_KEY ?? null;
        const apiSecret = row?.erpnext_api_secret ?? process.env.ERPNEXT_API_SECRET ?? null;
        if (!cfg.erpnext_url || !apiKey || !apiSecret) {
            return {
                ok: false,
                message: "erpnext_url / api_key / api_secret not all configured",
            };
        }
        const limit = Math.max(1, Math.min(500, params.limit ?? 50));
        const qs = new URLSearchParams();
        qs.set("limit_page_length", String(limit));
        if (params.fields)
            qs.set("fields", JSON.stringify(params.fields));
        if (params.filters)
            qs.set("filters", JSON.stringify(params.filters));
        try {
            const res = await fetch(`${cfg.erpnext_url}/api/resource/${encodeURIComponent(doctype)}?${qs}`, {
                method: "GET",
                headers: {
                    Authorization: `token ${apiKey}:${apiSecret}`,
                },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            const text = await res.text().catch(() => "");
            if (!res.ok) {
                return {
                    ok: false,
                    message: `HTTP ${res.status}: ${text.slice(0, 300)}`,
                };
            }
            const parsed = JSON.parse(text);
            const data = Array.isArray(parsed?.data) ? parsed.data : [];
            return { ok: true, items: data, count: data.length };
        }
        catch (err) {
            return {
                ok: false,
                message: describeError(err).slice(0, 300),
            };
        }
    }
    /**
     * Catalogue entries in ERPNext that no Medusa product claims yet — what
     * the operator picks from when attaching a product they created here
     * to the one that already exists over there.
     */
    async listUnlinkedCatalogueItems(args = {}) {
        const doctype = await this.productsDoctype();
        const filters = [];
        if (args.search?.trim()) {
            filters.push(["name", "like", `%${args.search.trim()}%`]);
        }
        const limit = Math.min(Math.max(args.limit ?? 20, 1), 200);
        const res = await this.pullDoctype(doctype, {
            filters,
            fields: ["name", "item_name", "disabled"],
            limit: 200,
        });
        if (!res.ok) {
            return { ok: false, doctype, items: [], message: res.message };
        }
        const items = res.items ?? [];
        const names = items.map((i) => String(i.name));
        const linked = names.length
            ? await this.listErpnextLinks({ doctype, medusa_entity: "product", erpnext_name: names }, { take: names.length })
            : [];
        const taken = new Set(linked.map((l) => String(l.erpnext_name)));
        return { ok: true, doctype, items: items.filter((i) => !taken.has(String(i.name))).slice(0, limit) };
    }
    /**
     * Attach a Medusa product to an ERPNext catalogue entry: the product
     * remembers the item code so later pushes are allowed and land on the
     * right record, and the link table remembers the pair.
     */
    async linkProductToItem(args) {
        const doctype = await this.productsDoctype();
        const itemCode = (args.item_code ?? "").trim();
        if (!args.product_id || !itemCode) {
            return { ok: false, message: "product_id and item_code are both required" };
        }
        const cfg = await this.getActiveConfig();
        const underSelection = (0, selection_1.isSyncDoctype)(doctype, cfg.sync_doctypes);
        const lookup = await this.pullDoctype(doctype, {
            filters: [["name", "=", itemCode]],
            fields: underSelection ? ["name", selection_1.SELECTION_FIELD] : ["name"],
            limit: 1,
        });
        if (!lookup.ok) {
            return { ok: false, message: lookup.message ?? "could not reach ERPNext" };
        }
        const item = (lookup.items ?? [])[0];
        if (!item) {
            return { ok: false, message: `${doctype} "${itemCode}" does not exist` };
        }
        // Must not already belong to a different product — silently
        // stealing a link would leave the other product pointing at a
        // record that no longer names it.
        const existing = await this.findLink(doctype, itemCode, "product");
        if (existing && existing.medusa_id !== args.product_id) {
            return { ok: false, message: `${itemCode} is already linked to ${existing.medusa_id}` };
        }
        const productSvc = args.scope?.resolve?.("product");
        if (!productSvc) {
            return { ok: false, message: "product module unavailable in this scope" };
        }
        const product = await productSvc.retrieveProduct(args.product_id);
        await productSvc.updateProducts(args.product_id, {
            metadata: { ...(product.metadata ?? {}), [product_policy_1.LINK_KEY]: itemCode },
        });
        await this.recordLink({
            doctype,
            erpnext_name: itemCode,
            medusa_entity: "product",
            medusa_id: args.product_id,
            state: "active",
            ...(underSelection ? { remote_direction: String(item[selection_1.SELECTION_FIELD] ?? "") } : {}),
        });
        return { ok: true, item_code: itemCode, product_id: args.product_id };
    }
    /** Enabled mappings that push this entity, regardless of which event
     *  fires them. Used by the manual push, which has no event of its own. */
    async listEnabledPushMappingsForEntity(entity) {
        if (!entity)
            return [];
        const rows = await this.listErpnextMappings({ enabled: true, medusa_entity: entity }, { take: 100 });
        return rows.filter((m) => m.direction === "push" || m.direction === "both");
    }
    async bulkPush(args) {
        const results = [];
        let success = 0;
        let failed = 0;
        let skipped = 0;
        // A manual push used to send the raw record to the unmapped
        // endpoint, so "Push customers" and a live customer.created wrote
        // DIFFERENT documents in ERPNext — the button reported green while
        // writing nothing a mapping had shaped. Route both through the
        // mapping engine; fall back to the old path only when the entity
        // has no mapping at all.
        const mappings = args.entity ? await this.listEnabledPushMappingsForEntity(args.entity) : [];
        // The same record the live subscriber pushes: the registry's
        // enriched fetch (payments, totals, product ids), not the bare row
        // the route listed. Falls back to the row when hydration fails.
        const descriptor = args.entity ? (0, registry_1.getMedusaEntity)(args.entity) : null;
        for (const it of args.items) {
            // Synthetic event id: prefix + entity id + timestamp. Lets the
            // far side dedupe but still distinguishes "live event" from
            // "manual replay" runs.
            const eventId = `manual_push:${args.event}:${it.id}:${Date.now()}`;
            let record = it.payload;
            if (descriptor && args.container) {
                try {
                    record = (await descriptor.fetchById(args.container, it.id)) ?? it.payload;
                }
                catch {
                    record = it.payload;
                }
            }
            let r;
            if (mappings.length) {
                const outcomes = [];
                for (const mapping of mappings) {
                    outcomes.push(await this.pushViaMapping({
                        mapping,
                        event: args.event,
                        event_id: `${eventId}:${mapping.id}`,
                        record,
                        container: args.container,
                    }));
                }
                // One failure across several mappings is a failure for the
                // record: the operator needs to see it, not an average.
                r =
                    outcomes.find((o) => !o.ok) ??
                        outcomes.find((o) => o.ok && o.status === "success") ??
                        outcomes[0];
            }
            else {
                r = await this.forwardEvent({
                    event: args.event,
                    event_id: eventId,
                    data: it.payload,
                });
            }
            if (r.ok && r.status === "success") {
                success++;
                results.push({ id: it.id, status: "success" });
            }
            else if (r.ok && r.status === "skipped") {
                skipped++;
                results.push({
                    id: it.id,
                    status: "skipped",
                    error: r.reason,
                });
            }
            else {
                failed++;
                results.push({
                    id: it.id,
                    status: "failed",
                    error: r.error,
                });
            }
        }
        return {
            total: args.items.length,
            success,
            failed,
            skipped,
            results,
        };
    }
    // ─────────────────────────────────────────────────────────────────
    // Doctype + field introspection (Frappe side)
    //
    // Two endpoints feed the admin field-mapper UI:
    //   1. `listFrappeDoctypes` — lists every doctype the operator's
    //      api_key can read; used to populate the right-column doctype
    //      picker.
    //   2. `getDoctypeMeta` — `frappe.client.get_meta` on one doctype;
    //      returns the field list (with label / fieldtype / reqd) so
    //      the right column of the mapper can render the choices.
    // ─────────────────────────────────────────────────────────────────
    /**
     * Enumerate available Frappe doctypes for the mapping picker.
     * Filters out single + child doctypes by default (operators almost
     * always want regular submittable forms). Pass `include_single` to
     * surface Singles like "Medusa Settings".
     */
    async listFrappeDoctypes(options = {}) {
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds) {
            return { ok: false, message: "erpnext_url / api credentials not configured" };
        }
        // A site with several apps carries well over two thousand DocTypes;
        // the pickers ask for all of them and search narrows client-side.
        const limit = Math.max(1, Math.min(5000, options.limit ?? 500));
        const filters = [];
        if (!options.include_single) {
            filters.push(["issingle", "=", 0]);
        }
        if (options.search) {
            filters.push(["name", "like", `%${options.search}%`]);
        }
        const qs = new URLSearchParams();
        qs.set("limit_page_length", String(limit));
        qs.set("fields", JSON.stringify(["name", "module", "istable", "issingle"]));
        if (filters.length)
            qs.set("filters", JSON.stringify(filters));
        qs.set("order_by", "name asc");
        try {
            const res = await fetch(`${cfg.erpnext_url}/api/resource/DocType?${qs}`, {
                method: "GET",
                headers: { Authorization: `token ${apiCreds}` },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            const text = await res.text().catch(() => "");
            if (!res.ok) {
                return {
                    ok: false,
                    message: `HTTP ${res.status}: ${text.slice(0, 300)}`,
                };
            }
            const parsed = JSON.parse(text);
            return {
                ok: true,
                items: Array.isArray(parsed?.data) ? parsed.data : [],
            };
        }
        catch (err) {
            return {
                ok: false,
                message: describeError(err).slice(0, 300),
            };
        }
    }
    /**
     * Fetch the field meta for a single doctype via Frappe's
     * `frappe.client.get_meta` whitelisted method. Returns a flattened
     * list of fields: name, label, fieldtype, reqd, options (for
     * Link/Select), in_list_view, hidden.
     *
     * Cached per-process for 5 minutes — meta rarely changes and the
     * admin field-mapper opens this on every field-picker click.
     */
    async getDoctypeMeta(doctype) {
        if (!doctype || !doctype.trim()) {
            return { ok: false, message: "doctype is required" };
        }
        const cacheKey = doctype.trim();
        const cached = _metaCache.get(cacheKey);
        if (cached && cached.expiresAt > Date.now()) {
            return { ok: true, fields: cached.fields };
        }
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds) {
            return { ok: false, message: "erpnext_url / api credentials not configured" };
        }
        try {
            // Frappe v15+ removed `frappe.client.get_meta`; the REST resource
            // endpoint returns the DocType as shipped under `.data`. A site's
            // customisations live elsewhere: Custom Field rows add columns
            // (a customised Customer carries ~35 of them, the KYC fields
            // included), and Property Setter rows change one property of a
            // standard field — `reqd` above all, which decides whether a
            // push write is accepted. Fan out three reads and merge them
            // with Frappe's own precedence (see doctype-meta.ts).
            const headers = { Authorization: `token ${apiCreds}` };
            const listUrl = (doctype, filters, fields) => `${cfg.erpnext_url}/api/resource/${encodeURIComponent(doctype)}?` +
                new URLSearchParams({
                    filters: JSON.stringify(filters),
                    fields: JSON.stringify(fields),
                    limit_page_length: "500",
                }).toString();
            const [baseRes, customRes, setterRes] = await Promise.all([
                fetch(`${cfg.erpnext_url}/api/resource/DocType/${encodeURIComponent(cacheKey)}`, {
                    method: "GET",
                    headers,
                    signal: AbortSignal.timeout(cfg.request_timeout_ms),
                }),
                fetch(listUrl("Custom Field", [["dt", "=", cacheKey]], [
                    "fieldname",
                    "label",
                    "fieldtype",
                    "reqd",
                    "options",
                    "in_list_view",
                    "hidden",
                    "read_only",
                    "default",
                    "fetch_from",
                ]), { method: "GET", headers, signal: AbortSignal.timeout(cfg.request_timeout_ms) }),
                fetch(listUrl("Property Setter", [
                    ["doc_type", "=", cacheKey],
                    ["doctype_or_field", "=", "DocField"],
                ], ["field_name", "property", "value", "property_type", "doctype_or_field"]), { method: "GET", headers, signal: AbortSignal.timeout(cfg.request_timeout_ms) }),
            ]);
            const baseText = await baseRes.text().catch(() => "");
            if (!baseRes.ok) {
                return {
                    ok: false,
                    message: `HTTP ${baseRes.status}: ${baseText.slice(0, 300)}`,
                };
            }
            const baseParsed = JSON.parse(baseText);
            const baseFields = Array.isArray(baseParsed?.data?.fields)
                ? baseParsed.data.fields
                : Array.isArray(baseParsed?.message?.fields)
                    ? baseParsed.message.fields // legacy shape (v13 / get_meta)
                    : [];
            // The two list reads are best-effort: a doctype with no
            // customisation returns an empty list, and a permission error
            // must not hide the baseline.
            const listRows = async (res) => {
                if (!res.ok)
                    return [];
                try {
                    const parsed = JSON.parse(await res.text().catch(() => ""));
                    return Array.isArray(parsed?.data) ? parsed.data : [];
                }
                catch {
                    return [];
                }
            };
            const trimmed = (0, doctype_meta_1.mergeDoctypeMeta)({
                baseFields,
                customFields: await listRows(customRes),
                propertySetters: await listRows(setterRes),
            });
            _metaCache.set(cacheKey, {
                fields: trimmed,
                expiresAt: Date.now() + _META_CACHE_TTL_MS,
            });
            return { ok: true, fields: trimmed };
        }
        catch (err) {
            return {
                ok: false,
                message: describeError(err).slice(0, 300),
            };
        }
    }
    /**
     * The values one ERPNext field will actually accept.
     *
     * A fixed-value pair usually targets a Select or a Link, and the valid
     * answers are that deployment's own data — its Item Groups, its UOMs,
     * its Customer Types if somebody has edited the list. Shipping a guess
     * ("Products", "Nos") would be one client's setup baked into an
     * application every client installs, and it fails Link validation
     * anywhere it does not hold.
     *
     * Select  → the options on the field itself.
     * Link    → the records that exist in the linked DocType right now.
     * Neither → no options, and the UI asks for free text.
     */
    async fieldOptions(doctype, fieldname) {
        const meta = await this.getDoctypeMeta(doctype);
        if (!meta.ok)
            return { ok: false, message: meta.message };
        const field = (meta.fields ?? []).find((f) => f.fieldname === fieldname);
        if (!field) {
            return { ok: false, message: `'${fieldname}' is not a field on ${doctype}` };
        }
        if (field.fieldtype === "Select") {
            const options = String(field.options ?? "")
                .split("\n")
                .map((o) => o.trim())
                .filter(Boolean);
            return { ok: true, fieldtype: field.fieldtype, options };
        }
        if (field.fieldtype !== "Link" || !field.options) {
            return { ok: true, fieldtype: field.fieldtype, options: [] };
        }
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds) {
            return { ok: false, message: "erpnext_url / api credentials not configured" };
        }
        const LIMIT = 200;
        try {
            const res = await fetch(`${cfg.erpnext_url}/api/resource/${encodeURIComponent(field.options)}?` +
                new URLSearchParams({
                    fields: JSON.stringify(["name"]),
                    limit_page_length: String(LIMIT + 1),
                    order_by: "name asc",
                }).toString(), {
                method: "GET",
                headers: { Authorization: `token ${apiCreds}` },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            const body = await res.json();
            if (!res.ok) {
                return {
                    ok: false,
                    message: body?.message ?? `could not read ${field.options}`,
                };
            }
            const names = (body?.data ?? []).map((r) => String(r.name));
            return {
                ok: true,
                fieldtype: field.fieldtype,
                options: names.slice(0, LIMIT),
                truncated: names.length > LIMIT,
            };
        }
        catch (err) {
            return { ok: false, message: describeError(err).slice(0, 300) };
        }
    }
    /**
     * Outbound gate, shared by every push path.
     *
     * Reads the allowlist fresh from the settings row rather than
     * caching it — an operator widening or clearing the list during a
     * test session should take effect on the next event, not after a
     * restart.
     */
    async checkPushAllowed(record) {
        const row = await this.findSettingsRow?.();
        return (0, push_guard_1.evaluatePush)(record, (0, push_guard_1.parseAllowlist)(row?.push_allowlist));
    }
    async frappeApiCreds() {
        const row = await this.findSettingsRow?.();
        const apiKey = row?.erpnext_api_key ?? process.env.ERPNEXT_API_KEY ?? null;
        const apiSecret = row?.erpnext_api_secret ?? process.env.ERPNEXT_API_SECRET ?? null;
        if (!apiKey || !apiSecret)
            return null;
        return `${apiKey}:${apiSecret}`;
    }
    // ─────────────────────────────────────────────────────────────────
    // Mapping CRUD
    //
    // Thin wrappers over the generated MedusaService accessors that
    // (a) coerce JSON columns into typed shapes and (b) validate the
    // operator-supplied field_mappings array before persisting.
    // ─────────────────────────────────────────────────────────────────
    async listMappings(filter = {}) {
        const where = {};
        if (filter.enabled !== undefined)
            where.enabled = filter.enabled;
        if (filter.medusa_entity)
            where.medusa_entity = filter.medusa_entity;
        if (filter.doctype)
            where.doctype = filter.doctype;
        return this.listErpnextMappings(where, { order: { name: "ASC" } });
    }
    async getMapping(id) {
        const [row] = await this.listErpnextMappings({ id }, { take: 1 });
        return row ?? null;
    }
    /** Look up every enabled mapping for one Medusa entity that
     *  subscribes to `eventName`. Used by the push subscriber. */
    async listEnabledPushMappingsForEvent(medusa_entity, eventName) {
        const rows = await this.listErpnextMappings({ enabled: true, medusa_entity, direction: ["push", "both"] }, { take: 100 });
        return rows.filter((r) => (0, order_accounting_1.mappingHandlesEvent)(r.events, eventName));
    }
    /** Look up every enabled mapping that the pull cron should sweep. */
    async listEnabledPullMappings() {
        return this.listErpnextMappings({ enabled: true, direction: ["pull", "both"] }, { order: { last_pull_run_at: "ASC" }, take: 200 });
    }
    /**
     * Row-count drift report for a mapping — used by the reconciliation
     * cron's drift detector. Returns `{frappe_count, medusa_count}` so
     * the caller can flag mappings whose two sides have diverged.
     *
     * Scoped to the **customer** mapping deliberately. For the other
     * canonical mappings the two populations aren't apples-to-apples
     * (every Medusa Order is a "Platform Purchase", which the Frappe
     * pull_filter explicitly excludes; Medusa wallet transactions
     * include promo + order-driven rows the Frappe deposit/withdrawal
     * docs never see; etc.) so a naive count diff would emit constant
     * false-positive drift. Those return `null` → the cron skips them.
     *
     * Customer IS comparable: Frappe Customers with
     * `custom_is_mithtech_only=0` correspond 1:1 to Medusa customers
     * that have cleared KYC (`metadata.kyc_fully_approved_at`), which is
     * exactly the population the push subscriber forwards. A persistent
     * gap there means the missing-on-Frappe recovery pass (same cron)
     * has something real to heal.
     */
    async countMappingRows(mapping, container) {
        if (mapping?.medusa_entity !== "customer" || !container)
            return null;
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds)
            return null;
        // ── Frappe side: COUNT(*) with the mapping's pull_filter ──
        const filters = Array.isArray(mapping.pull_filter)
            ? mapping.pull_filter
            : [];
        let frappe_count = 0;
        try {
            const url = `${cfg.erpnext_url}/api/method/frappe.client.get_count` +
                `?doctype=${encodeURIComponent(mapping.doctype)}` +
                `&filters=${encodeURIComponent(JSON.stringify(filters))}`;
            const res = await fetch(url, {
                method: "GET",
                headers: { Authorization: `token ${apiCreds}` },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            if (!res.ok)
                return null;
            const body = await res.json().catch(() => ({}));
            frappe_count = Number(body?.message ?? 0);
        }
        catch {
            return null;
        }
        // ── Medusa side: KYC-approved customers (same gate the push
        // subscriber uses). Bounded list + in-JS filter — metadata
        // key-existence isn't a first-class Medusa query filter, and a
        // count for drift only needs to be approximate. Matches the
        // bound used by the recovery pass in jobs/reconciliation.ts.
        let medusa_count = 0;
        try {
            const customerModule = container.resolve("customer");
            const all = await customerModule.listCustomers({}, { take: 1000 });
            medusa_count = all.filter((c) => c?.metadata
                ?.kyc_fully_approved_at).length;
        }
        catch {
            return null;
        }
        return { frappe_count, medusa_count };
    }
    // ─────────────────────────────────────────────────────────────────
    // Detailed reconciliation (breadth): which ids diverge, not just a
    // count delta, for customer / product / order. Compares the stable
    // Medusa id (against the ERPNext `medusa_*_id` the mapping stamps)
    // with a NATURAL-KEY fallback (product handle ↔ item_code, customer
    // email ↔ email_id) — without the fallback, catalog products pulled
    // ERPNext→Medusa (which never stamp their id back onto the Item) all
    // read as "missing_on_frappe". Report-only; bounded + `truncated`.
    // ─────────────────────────────────────────────────────────────────
    static RECONCILABLE = {
        customer: { list: "listCustomers", naturalMedusa: "email", naturalErp: "email_id" },
        product: { list: "listProducts", naturalMedusa: "handle", naturalErp: "item_code" },
        order: { list: "listOrders" }, // id-only: medusa_order_id is the one true key
    };
    async reconcileMapping(mapping, container, opts) {
        const entity = mapping?.medusa_entity;
        const doctype = mapping?.doctype;
        const spec = ErpnextModuleService.RECONCILABLE[entity];
        if (!spec || !container) {
            return { entity, doctype, skipped: "not-reconcilable" };
        }
        const limit = opts?.limit ?? 2000;
        const sampleCap = opts?.sample ?? 100;
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds) {
            return { entity, doctype, skipped: "not-configured" };
        }
        // Which ERPNext field carries the Medusa id (from the id pair).
        const idPair = mapping.field_mappings?.find((p) => p.medusa_path === "id");
        const idField = idPair?.erpnext_field;
        if (!idField)
            return { entity, doctype, skipped: "no-id-pair" };
        // ── Medusa side: {id, natural} bounded ───────────────────────
        const mod = container.resolve(spec.list === "listOrders" ? "order" : entity);
        const rows = (await mod[spec.list]({}, { take: limit })) || [];
        const medusaTruncated = rows.length >= limit;
        const medusaIds = new Set();
        const medusaNatural = new Set();
        const medusaByKey = rows.map((r) => {
            const id = String(r?.id ?? "");
            const nat = spec.naturalMedusa
                ? String((0, mapping_engine_1.getByPath)(r, spec.naturalMedusa) ?? "").toLowerCase()
                : "";
            if (id)
                medusaIds.add(id);
            if (nat)
                medusaNatural.add(nat);
            return { id, nat };
        });
        // ── Frappe side: fetch idField (+ natural field) bounded ─────
        const fields = [idField, "name"];
        if (spec.naturalErp && spec.naturalErp !== idField)
            fields.push(spec.naturalErp);
        const fieldsJson = encodeURIComponent(JSON.stringify(fields));
        const url = `${cfg.erpnext_url}/api/resource/${encodeURIComponent(doctype)}` +
            `?fields=${fieldsJson}&limit_page_length=${limit}`;
        const res = await fetch(url, {
            method: "GET",
            headers: { Authorization: `token ${apiCreds}` },
            signal: AbortSignal.timeout(cfg.request_timeout_ms),
        });
        if (!res.ok) {
            return { entity, doctype, skipped: `frappe-list-${res.status}` };
        }
        const body = await res.json().catch(() => ({}));
        const frappeRows = Array.isArray(body?.data) ? body.data : [];
        const frappeTruncated = frappeRows.length >= limit;
        const frappeIds = new Set();
        const frappeNatural = new Set();
        for (const fr of frappeRows) {
            const fid = String(fr?.[idField] ?? "");
            if (fid)
                frappeIds.add(fid);
            if (spec.naturalErp) {
                const fn = String(fr?.[spec.naturalErp] ?? "").toLowerCase();
                if (fn)
                    frappeNatural.add(fn);
            }
        }
        // ── Diff ─────────────────────────────────────────────────────
        const presentOnFrappe = (m) => (m.id && frappeIds.has(m.id)) || (m.nat && frappeNatural.has(m.nat));
        const missing = medusaByKey.filter((m) => !presentOnFrappe(m));
        const matched = medusaByKey.length - missing.length;
        // Frappe rows whose stamped medusa id is not a live Medusa id AND
        // whose natural key doesn't match either → orphaned / deleted-in-Medusa.
        const orphans = frappeRows.filter((fr) => {
            const fid = String(fr?.[idField] ?? "");
            if (!fid)
                return false; // Frappe-native row (no medusa id) — not an orphan
            if (medusaIds.has(fid))
                return false;
            const fn = spec.naturalErp
                ? String(fr?.[spec.naturalErp] ?? "").toLowerCase()
                : "";
            if (fn && medusaNatural.has(fn))
                return false;
            return true;
        });
        return {
            entity,
            doctype,
            medusa_count: medusaByKey.length,
            frappe_count: frappeRows.length,
            matched,
            missing_on_frappe_count: missing.length,
            missing_on_frappe: missing.slice(0, sampleCap).map((m) => m.nat || m.id),
            frappe_orphans_count: orphans.length,
            frappe_orphans: orphans.slice(0, sampleCap).map((fr) => fr.name),
            truncated: medusaTruncated || frappeTruncated,
        };
    }
    /** Run reconcileMapping across every enabled, reconcilable mapping. */
    async reconcileAll(container, opts) {
        // All ENABLED mappings regardless of direction — the reconcilable
        // entities (customer/product/order) are push mappings, so a
        // pull-only listing would miss them.
        const mappings = await this.listMappings({ enabled: true }).catch(() => []);
        const reports = [];
        const seen = new Set();
        for (const m of mappings) {
            if (!ErpnextModuleService.RECONCILABLE[m.medusa_entity])
                continue;
            if (seen.has(m.medusa_entity))
                continue; // one report per entity
            seen.add(m.medusa_entity);
            try {
                reports.push(await this.reconcileMapping(m, container, opts));
            }
            catch (err) {
                reports.push({ entity: m.medusa_entity, doctype: m.doctype, error: describeError(err) });
            }
        }
        return { ok: true, generated_at: new Date().toISOString(), reports };
    }
    async saveMapping(input) {
        const validated = validateFieldMappings(input.field_mappings ?? []);
        // A mapping goes live only after somebody HERE has tried it. Only
        // the transition is gated: one that is already running keeps
        // running whatever is edited on it, because retro-fitting the rule
        // would stop a working store on the next save of anything.
        const existingRow = input.id
            ? (await this.listErpnextMappings({ id: input.id }, { take: 1 }))[0]
            : null;
        const gateVerdict = (0, signature_1.mayEnable)(existingRow, input);
        if (gateVerdict.ok === false) {
            // Held before the branch: reassigning `input` below resets the
            // narrowing that made `reason` reachable, since the verdict was
            // derived from it.
            const refusal = gateVerdict.reason;
            if (input.from_erpnext) {
                // ERPNext asked for this. Same rule as first contact:
                // nothing runs here until somebody here has looked at it.
                // Keep every other field it sent, leave it switched off,
                // and say why on the mapping rather than in an exception.
                input = {
                    ...input,
                    enabled: false,
                    attention: "Mapping Required",
                    attention_detail: "ERPNext switched this on, and it has not been rehearsed here. " +
                        "Dry-run it and enable it, or leave it off.",
                };
            }
            else {
                throw new Error(refusal);
            }
        }
        // Reject a malformed condition at SAVE time. Conditions fail
        // closed at run time, so a typo here would silently stop the
        // mapping syncing and the operator would find out days later
        // from a missing record rather than from the form.
        const preset = input.trigger_preset ?? "always";
        const condition = input.trigger_condition !== undefined
            ? input.trigger_condition
            : (0, trigger_1.presetCondition)(preset);
        const conditionCheck = (0, trigger_1.validateTrigger)(condition);
        if (!conditionCheck.ok) {
            throw new Error(`trigger_condition is invalid: ${conditionCheck.error}`);
        }
        const patch = {
            name: input.name.trim(),
            description: input.description ?? null,
            enabled: input.enabled ?? true,
            medusa_entity: input.medusa_entity.trim(),
            doctype: input.doctype.trim(),
            direction: input.direction ?? "both",
            events: Array.isArray(input.events) ? input.events.filter(Boolean) : null,
            pull_filter: input.pull_filter ?? null,
            pull_page_size: clampInt(input.pull_page_size ?? 200, 1, 1000),
            key_medusa_field: input.key_medusa_field.trim(),
            key_erpnext_field: (input.key_erpnext_field ?? "name").trim(),
            field_mappings: validated,
            trigger_preset: preset,
            trigger_condition: (condition ?? "").trim() || null,
            skip_unchanged: input.skip_unchanged ?? false,
            allow_create: input.allow_create ?? true,
            allow_update: input.allow_update ?? true,
            selection_mode: input.selection_mode === "deny" ? "deny" : input.selection_mode === "allow" ? "allow" : null,
            secondary_doctypes: (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(input.secondary_doctypes, input.doctype),
            updated_by_user_id: input.updated_by_user_id ?? null,
            // Set by the gate above when ERPNext switched on a mapping this
            // side has not rehearsed. Undefined on an ordinary save, and
            // `?? null` would then clear a flag somebody still has to act
            // on, so it is only written when it is actually present.
            ...(input.attention !== undefined
                ? {
                    attention: input.attention,
                    attention_detail: input.attention_detail ?? null,
                }
                : {}),
        };
        // A sync is its pair: one Medusa entity and one DocType, per store,
        // is one mapping, and its identity is derived from that pair so the
        // ERPNext side arrives at the same one without asking.
        const pair = (0, pair_identity_1.pairUidOf)({
            medusa_entity: patch.medusa_entity,
            doctype: patch.doctype,
        });
        if (input.id) {
            const [current] = await this.listErpnextMappings({ id: input.id }, { take: 1 });
            if (current && (0, pair_identity_1.pairUidOf)(current) !== pair) {
                throw new Error("A sync is identified by what it pairs. To keep a different doctype or " +
                    "entity in step, add a new sync instead of changing this one.");
            }
            // `version` counts saves; the enable gate and the drift check
            // read it to tell an edited mapping from a rehearsed one.
            const [updated] = await this.updateErpnextMappings([
                {
                    id: input.id,
                    ...patch,
                    mapping_uid: pair,
                    version: Number(current?.version ?? 1) + 1,
                    // Switched on here, past the gate: whatever was waiting
                    // on a person is done with. A save that sets attention
                    // itself (the gate's refusal above) wins by spreading last.
                    ...(patch.enabled === true && input.attention === undefined
                        ? { attention: null, attention_detail: null }
                        : {}),
                },
            ]);
            await this.syncSelectionFromMappings();
            return updated;
        }
        const twin = await this.findMappingByPair(patch.medusa_entity, patch.doctype);
        if (twin) {
            if (!input.merge_into_pair) {
                const err = new Error(`"${twin.name}" already keeps ${patch.doctype} in step with ${patch.medusa_entity}. ` +
                    "Edit that sync rather than adding a second one for the same pair.");
                err.code = "pair_exists";
                err.existing_id = twin.id;
                throw err;
            }
            // Fold: the existing pairs win a collision, the new ones are
            // appended, both sides' events fire, and a one-way sync meeting
            // its opposite becomes two-way. Name and switch stay as they are.
            const [folded] = await this.updateErpnextMappings([
                {
                    id: twin.id,
                    ...patch,
                    name: twin.name,
                    enabled: twin.enabled,
                    direction: (0, pair_identity_1.mergeDirection)(twin.direction, patch.direction),
                    field_mappings: (0, pair_identity_1.mergeFieldPairs)(twin.field_mappings ?? [], patch.field_mappings),
                    events: (0, pair_identity_1.mergeEvents)(twin.events, patch.events),
                    mapping_uid: pair,
                    version: Number(twin.version ?? 1) + 1,
                },
            ]);
            await this.syncSelectionFromMappings();
            return { ...folded, merged_into: twin.id };
        }
        const [created] = await this.createErpnextMappings([
            { ...patch, mapping_uid: pair, version: 1 },
        ]);
        await this.syncSelectionFromMappings();
        return created;
    }
    /**
     * The selection list is the syncs' doing: recompute it from every
     * mapping and write it to Settings when it changed, so Set up ERPNext
     * and the pull filter read what the Mappings page shows.
     */
    async syncSelectionFromMappings() {
        const mappings = await this.listErpnextMappings({}, { take: 1000 });
        const derived = (0, selection_1.deriveSyncDoctypes)(mappings);
        const row = await this.findSettingsRow();
        const current = (0, selection_1.normalizeSyncDoctypes)(row?.sync_doctypes);
        const same = current.length === derived.length &&
            current.every((c, i) => c.doctype === derived[i].doctype && c.mode === derived[i].mode);
        if (row && !same)
            await this.updateErpnextSettings([{ id: row.id, sync_doctypes: derived }]);
        return derived;
    }
    /**
     * The mapping that keeps this pair in step, if there is one — by its
     * pair identity first, then by the pair itself for a row that still
     * carries an identity from before the rule.
     */
    async findMappingByPair(medusa_entity, doctype) {
        const pair = (0, pair_identity_1.pairUidOf)({ medusa_entity, doctype });
        const [byUid] = await this.listErpnextMappings({ mapping_uid: pair }, { take: 1 });
        if (byUid)
            return byUid;
        const candidates = await this.listErpnextMappings({ medusa_entity, doctype }, { take: 20 });
        return candidates.find((r) => (0, pair_identity_1.pairUidOf)(r) === pair) ?? null;
    }
    /**
     * Delete sync events past the configured retention window.
     *
     * Deletes in batches so a first run against a long-neglected table
     * doesn't hold one enormous transaction open.
     */
    async pruneSyncEvents() {
        // Rehearsals go first and go regardless of the retention
        // setting. They are not evidence of anything, they are the
        // noisiest rows in the table while somebody is building a
        // mapping, and a site that turned retention off should not
        // accumulate them forever.
        const TEST_EVENT_RETENTION_DAYS = 1;
        const testCutoff = new Date(Date.now() - TEST_EVENT_RETENTION_DAYS * 24 * 60 * 60 * 1000);
        for (let batch = 0; batch < 20; batch += 1) {
            const rehearsals = await this.listErpnextSyncEvents({ is_test: true, created_at: { $lt: testCutoff } }, { take: 500, select: ["id"] });
            if (!rehearsals.length)
                break;
            await this.deleteErpnextSyncEvents(rehearsals.map((r) => r.id));
            if (rehearsals.length < 500)
                break;
        }
        const row = await this.findSettingsRow();
        const retentionDays = Number(row?.log_retention_days ?? 180);
        if (!Number.isFinite(retentionDays) || retentionDays <= 0) {
            return { deleted: 0, retention_days: 0, cutoff: null };
        }
        const cutoff = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
        let deleted = 0;
        for (let batch = 0; batch < 100; batch += 1) {
            const stale = await this.listErpnextSyncEvents({ created_at: { $lt: cutoff } }, { take: 500, select: ["id"] });
            if (!stale.length)
                break;
            await this.deleteErpnextSyncEvents(stale.map((r) => r.id));
            deleted += stale.length;
            if (stale.length < 500)
                break;
        }
        return {
            deleted,
            retention_days: retentionDays,
            cutoff: cutoff.toISOString(),
        };
    }
    /**
     * Per-mapping health for the admin list: how many events succeeded,
     * failed or were skipped recently, so an operator can see at a
     * glance which mapping is unhealthy instead of scrolling the log.
     */
    async mappingHealth(windowDays = 30) {
        const since = new Date(Date.now() - windowDays * 24 * 60 * 60 * 1000);
        const rows = await this.listErpnextSyncEvents({ created_at: { $gte: since } }, { take: 10000, select: ["mapping_id", "status"] });
        const out = {};
        for (const r of rows) {
            const key = r.mapping_id ?? "__unmapped__";
            out[key] ??= { success: 0, failed: 0, skipped: 0, pending: 0 };
            if (r.status in out[key])
                out[key][r.status] += 1;
        }
        return out;
    }
    async deleteMapping(id) {
        // What the mapping correlated stays on the synced records, in the
        // link table and in the event log.
        await this.deleteErpnextMappings([id]);
        await this.syncSelectionFromMappings();
        return { ok: true, id };
    }
    /**
     * Seed the canonical mapping set on plugin install / migrate.
     *
     * Idempotent — looks up each canonical entry by `name` and skips
     * if present. Returns `{seeded, skipped}` counts so the caller
     * can log. Safe to call on every server boot (cheap query).
     *
     * Called by the F0+ migration path and by the admin "Reseed
     * canonical mappings" button (F4).
     */
    async seedCanonicalMappings() {
        const { CANONICAL_MAPPINGS } = await import("./canonical-mappings.js");
        // A sync is its pair, so a shipped default that already exists under
        // any name — including the one ERPNext ships for the same pair — is
        // updated rather than seeded beside it.
        const existing = await this.listErpnextMappings({}, { take: 1000 });
        const existingByPair = new Map(existing.map((r) => [(0, pair_identity_1.pairUidOf)(r), r]));
        const seeded = [];
        const updated = [];
        const errors = [];
        for (const m of CANONICAL_MAPPINGS) {
            try {
                // UPSERT: pass the existing id when present so registry
                // changes (new field pairs, fixed pull_filter, etc.)
                // actually propagate. Previously skipped existing
                // rows — which left manually-empty mappings stuck
                // forever after the first save.
                const existingRow = existingByPair.get((0, pair_identity_1.pairUidOf)({ medusa_entity: m.medusa_entity, doctype: m.doctype }));
                await this.saveMapping({
                    id: existingRow?.id,
                    name: existingRow?.name ?? m.name,
                    description: m.description,
                    enabled: m.enabled,
                    medusa_entity: m.medusa_entity,
                    doctype: m.doctype,
                    direction: m.direction,
                    events: m.events,
                    pull_filter: m.pull_filter,
                    pull_page_size: m.pull_page_size,
                    key_medusa_field: m.key_medusa_field,
                    key_erpnext_field: m.key_erpnext_field,
                    field_mappings: m.field_mappings,
                });
                if (existingRow) {
                    updated.push(m.name);
                }
                else {
                    seeded.push(m.name);
                }
            }
            catch (e) {
                errors.push({ name: m.name, message: String(e?.message || e) });
            }
        }
        return { seeded, updated, errors };
    }
    /**
     * Lookup helper for the admin Mapping editor's "Suggest field
     * pairs" button. Returns the canonical mapping's `field_mappings`
     * + recommended direction/events/pull_filter for one
     * (entity, doctype) pair so the UI can pre-fill without forcing
     * the operator to remember every store-specific field name.
     *
     * Returns null when no canonical entry matches — the UI then
     * falls back to a heuristic (medusa fieldname ≈ frappe fieldname).
     */
    async suggestMappingForPair(entity, doctype) {
        const { findCanonicalMapping } = await import("./canonical-mappings.js");
        const c = findCanonicalMapping(entity, doctype);
        if (!c) {
            return { ok: true, canonical: false, suggestion: null };
        }
        return {
            ok: true,
            canonical: true,
            suggestion: {
                direction: c.direction,
                events: c.events,
                pull_filter: c.pull_filter,
                key_medusa_field: c.key_medusa_field,
                key_erpnext_field: c.key_erpnext_field,
                field_mappings: c.field_mappings,
            },
        };
    }
    /**
     * Build a complete draft field-map for ANY (entity, doctype) pair.
     *
     * `suggestMappingForPair` above only answers for the six canonical
     * combinations shipped in canonical-mappings.ts. This method works
     * for all 993 doctypes on the connected site: it reads the live
     * field meta, reads the entity's curated dot-paths, and runs the
     * matcher in autofill.ts over the cross-product.
     *
     * Canonical entries are still honoured — they're passed into the
     * matcher as pre-decided pairs and win over any heuristic guess, so
     * picking Customer↔Customer keeps giving exactly the hand-tuned
     * result it did before, with the *unmatched* remainder of the
     * doctype now filled in around it.
     *
     * Network cost is one `getDoctypeMeta` (5-minute per-process cache),
     * so the UI can call this on every doctype change.
     */
    async autofillMapping(args) {
        const entityKey = String(args.entity ?? "").trim();
        const doctype = String(args.doctype ?? "").trim();
        if (!entityKey || !doctype) {
            return { ok: false, message: "entity and doctype are required" };
        }
        const descriptor = (0, registry_1.getMedusaEntity)(entityKey);
        if (!descriptor) {
            return { ok: false, message: `unknown Medusa entity '${entityKey}'` };
        }
        const meta = await this.getDoctypeMeta(doctype);
        if (!meta.ok) {
            return {
                ok: false,
                message: meta.message ?? `could not read meta for '${doctype}'`,
            };
        }
        const { findCanonicalMapping } = await import("./canonical-mappings.js");
        const canonicalEntry = findCanonicalMapping(entityKey, doctype);
        // Canonical pairs, keyed by the ERPNext column they write.
        //
        // Two pairs CAN legitimately share a column when they run in
        // opposite directions (Product↔Security maps `handle` on pull
        // and a metadata path on push into the same ERPNext field).
        // Two pairs sharing a column in the SAME direction is a
        // fallback chain written the long way — historically used to
        // survive a metadata rename, relying on empty values being
        // skipped.
        //
        // Keying a plain Map by column silently dropped one of those,
        // and the survivor was whichever came last — which for PAN and
        // Aadhaar was the DEAD renamed key. Auto-mapping Customer would
        // then have replaced a working mapping with one that synced
        // nothing. Merge same-direction collisions into a single
        // `{a || b}` row instead, which is what they always meant.
        const canonicalByField = new Map();
        const collisions = new Map();
        for (const pair of canonicalEntry?.field_mappings ?? []) {
            if (!pair?.erpnext_field)
                continue;
            const key = `${pair.erpnext_field}::${pair.direction ?? "both"}`;
            const existing = canonicalByField.get(key);
            if (existing) {
                const paths = collisions.get(key) ?? [existing.medusa_path];
                paths.push(pair.medusa_path);
                collisions.set(key, paths);
                existing.medusa_path = `{${paths
                    .map((p) => ((0, mapping_engine_1.isTemplatePath)(p) ? p.replace(/^\{|\}$/g, "") : p))
                    .join(" || ")}}`;
                continue;
            }
            canonicalByField.set(key, {
                medusa_path: pair.medusa_path,
                transform: pair.transform ?? null,
                direction: pair.direction,
            });
        }
        const direction = args.direction ?? canonicalEntry?.direction ?? "both";
        // Match against every field the entity really has, not only the
        // curated ones. The curated list covers a fraction of most models
        // — a Frappe column whose counterpart was never listed could not be
        // suggested at all, however obvious the pairing. Falls back to the
        // curated list when there is no container to introspect with.
        const discovered = args.container
            ? await (0, discovery_runtime_1.discoverEntityFields)(args.container, entityKey)
            : null;
        const entityPaths = discovered?.fields ?? descriptor.paths;
        const result = (0, autofill_1.buildAutofill)({
            doctypeFields: (meta.fields ?? []),
            entityPaths,
            direction,
            canonical: canonicalByField,
            mode: args.mode ?? "smart",
        });
        // Emit only rows that actually carry a source. A mandatory-but-
        // unmatched row is surfaced through `annotations` so the UI can
        // show it as a to-do, but persisting a pair with an empty
        // medusa_path would just be dropped by validateFieldMappings.
        const field_mappings = result.rows
            .filter((r) => r.medusa_path)
            .map((r) => {
            const pair = {
                medusa_path: r.medusa_path,
                erpnext_field: r.erpnext_field,
            };
            if (r.transform)
                pair.transform = r.transform;
            if (r.transform_push)
                pair.transform_push = r.transform_push;
            if (r.transform_pull)
                pair.transform_pull = r.transform_pull;
            if (r.direction && r.direction !== direction) {
                pair.direction = r.direction;
            }
            if (r.default !== undefined)
                pair.default = r.default;
            return pair;
        });
        return {
            ok: true,
            doctype,
            entity: entityKey,
            canonical: Boolean(canonicalEntry),
            key_medusa_field: canonicalEntry?.key_medusa_field ?? descriptor.default_key_path,
            key_erpnext_field: canonicalEntry?.key_erpnext_field ?? "name",
            direction,
            events: canonicalEntry?.events ?? descriptor.events,
            pull_filter: canonicalEntry?.pull_filter ?? null,
            field_mappings,
            annotations: result.rows,
            summary: result.summary,
            skipped: result.skipped,
            total_doctype_fields: meta.fields?.length ?? 0,
        };
    }
    /**
     * Dry-run a single mapping against one Medusa record id. Builds
     * the same payload that the push subscriber would send to Frappe,
     * WITHOUT hitting the network. Useful for the admin "Test" button.
     */
    /**
     * A record of this entity to reason about.
     *
     * A real one when the store has any: only a real record shows the
     * shapes an operator will actually meet, empty fields included. One
     * built from the entity's own declared paths otherwise, because a
     * brand-new mapping is exactly when a sample is most useful and
     * exactly when there may be nothing to sample.
     */
    async sampleFor(entityKey, container, recordId) {
        const entity = (0, registry_1.getMedusaEntity)(entityKey);
        if (!entity) {
            throw new Error(`no registry entry for entity '${entityKey}'`);
        }
        const id = recordId ?? null;
        if (id) {
            const record = await entity.fetchById(container, id).catch(() => null);
            if (record) {
                return { entity: entityKey, id, from_record: true, data: record };
            }
        }
        // Built from what the entity says about itself. Typed placeholders
        // rather than empty strings, so a mapping that expects a number
        // gets a number and a transform that parses a date gets a date.
        const data = {};
        for (const p of entity.paths ?? []) {
            setByPath(data, p.path, placeholderFor(p));
        }
        return { entity: entityKey, id: null, from_record: false, data };
    }
    /**
     * Remember that this exact mapping was rehearsed.
     *
     * The gate reads `tested_signature`, so recording a pass is what makes
     * a mapping switchable-on. Written straight to the row: a rehearsal is
     * not an edit, and going through saveMapping would bump the version
     * and re-run the very gate this is satisfying.
     */
    async recordMappingTest(mappingId, passed, report) {
        const [row] = await this.listErpnextMappings({ id: mappingId }, { take: 1 });
        if (!row)
            return { ok: false, reason: "no such mapping" };
        await this.updateErpnextMappings({
            id: mappingId,
            tested_signature: passed ? (0, signature_1.signatureOf)(row) : null,
            last_test_at: new Date(),
            last_test_status: passed ? "passed" : "failed",
            last_test_report: report ?? null,
        });
        return { ok: true, id: mappingId, passed };
    }
    async dryRunPush(args) {
        const mapping = await this.getMapping(args.mapping_id);
        if (!mapping)
            return { ok: false, message: "mapping not found" };
        const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
        if (!entity) {
            return {
                ok: false,
                message: `medusa entity '${mapping.medusa_entity}' has no registry entry`,
            };
        }
        // A brand-new mapping usually has nothing to point at yet, and
        // that is when rehearsing it matters most. Fall back to a sample
        // built from the entity's own declared paths.
        const record = args.record_id
            ? await entity.fetchById(args.container, args.record_id)
            : (await this.sampleFor(mapping.medusa_entity, args.container)).data;
        if (!record) {
            return { ok: false, message: `no ${mapping.medusa_entity} with id ${args.record_id}` };
        }
        const mainDoctype = String(mapping.doctype);
        const allPairs = (mapping.field_mappings ?? []);
        const secs = (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(mapping.secondary_doctypes, mainDoctype);
        const result = (0, mapping_engine_1.applyMapping)({
            direction: "push",
            fields: (0, secondary_doctypes_1.pairsForDoctype)(allPairs, mainDoctype, mainDoctype),
            mappingDirection: mapping.direction,
            source: record,
            options: await this.transformOptions(),
        });
        if (result.ok === false) {
            return {
                ok: false,
                message: `${result.reason} (field=${result.field ?? "?"})`,
            };
        }
        const keyValue = record
            ? String(
            // Walk dot-path on the source to find the key value
            (0, mapping_engine_1.getByPath)(record, mapping.key_medusa_field) ?? "")
            : "";
        // A rehearsal that produced an empty payload, or no key to
        // correlate on, has not shown that the mapping works -- it has
        // shown that it would send nothing. Recording that as a pass would
        // satisfy the enable gate without proving anything, which is worse
        // than having no gate: it looks like a check.
        const fieldCount = Object.keys(result.payload ?? {}).length;
        const warnings = [];
        if (!fieldCount) {
            warnings.push("The mapping carried nothing from this record. Check the Medusa paths against " +
                "the Sample.");
        }
        if (!keyValue) {
            warnings.push(`No value at the key path '${mapping.key_medusa_field}', so ERPNext would have ` +
                "nothing to correlate on.");
        }
        // A mandatory ERPNext field nobody fills does not break here — it
        // breaks on the first real record, with Frappe rejecting the
        // document and the reason buried in a log row. The rehearsal is
        // where that is still cheap to fix, and it is what gates enabling.
        const targetMeta = await this.getDoctypeMeta(mapping.doctype);
        if (targetMeta.ok) {
            // The transport fills some of these itself (a Customer's name
            // and type, a Sales Order's dates and lines); only what is
            // left is the operator's to map.
            const rest = await this.restClient();
            const filled = (0, push_rest_1.transportFilledFields)(mapping.doctype, rest ? await this.pushDefaults(rest.client) : {});
            // The push renders the terms text from a `tc_name` pair, the
            // way ERPNext's form does.
            const namesTerms = mapping.field_mappings.some((p) => p?.erpnext_field === "tc_name");
            if (namesTerms)
                filled.add("terms");
            // Each secondary DocType has its own mandatory fields; the link
            // the plugin sets is not the operator's to map.
            for (const sec of secs) {
                const secMeta = await this.getDoctypeMeta(sec.doctype);
                if (!secMeta.ok)
                    continue;
                const secFilled = (0, push_rest_1.transportFilledFields)(sec.doctype, rest ? await this.pushDefaults(rest.client) : {});
                secFilled.add((0, secondary_doctypes_1.linkFieldFilled)(sec));
                const secUnmet = (0, mapping_engine_1.unmetRequired)({
                    direction: "push",
                    fields: (0, secondary_doctypes_1.pairsForDoctype)(allPairs, mainDoctype, sec.doctype),
                    mappingDirection: mapping.direction,
                    required: (secMeta.fields ?? [])
                        .filter((f) => f.reqd && !f.fetch_from && !f.default && !secFilled.has(f.fieldname))
                        .map((f) => ({ name: f.fieldname, label: f.label })),
                });
                if (secUnmet.length) {
                    warnings.push(`${sec.doctype} (linked to ${mainDoctype}) will not accept a record without ` +
                        secUnmet.map((f) => `'${f.label || f.name}'`).join(", ") +
                        ". Map each one on that DocType, or give it a fixed value.");
                }
            }
            const unmet = (0, mapping_engine_1.unmetRequired)({
                direction: "push",
                fields: (0, secondary_doctypes_1.pairsForDoctype)(allPairs, mainDoctype, mainDoctype),
                mappingDirection: mapping.direction,
                required: (targetMeta.fields ?? [])
                    // A field Frappe derives or defaults is not ours to send.
                    .filter((f) => f.reqd && !f.fetch_from && !f.default && !filled.has(f.fieldname))
                    .map((f) => ({ name: f.fieldname, label: f.label })),
            });
            if (unmet.length) {
                warnings.push(`${mapping.doctype} will not accept a record without ` +
                    unmet.map((f) => `'${f.label || f.name}'`).join(", ") +
                    ". Map each one, or give it a fixed value.");
            }
            // An order that also becomes a Sales Invoice once paid must
            // satisfy the invoice's own mandatory fields with the same
            // pairs; fixed values land on both documents.
            const settingsRow = mapping.doctype === "Sales Order" ? await this.findSettingsRow() : null;
            if (settingsRow && (0, push_rest_1.wantsSalesInvoice)(settingsRow.order_document)) {
                const siMeta = await this.getDoctypeMeta("Sales Invoice");
                const siFilled = (0, push_rest_1.transportFilledFields)("Sales Invoice", rest ? await this.pushDefaults(rest.client) : {});
                if (namesTerms)
                    siFilled.add("terms");
                const siUnmet = siMeta.ok
                    ? (0, mapping_engine_1.unmetRequired)({
                        direction: "push",
                        fields: mapping.field_mappings,
                        mappingDirection: mapping.direction,
                        required: (siMeta.fields ?? [])
                            .filter((f) => f.reqd && !f.fetch_from && !f.default && !siFilled.has(f.fieldname))
                            .map((f) => ({ name: f.fieldname, label: f.label })),
                    })
                    : [];
                if (siUnmet.length) {
                    warnings.push("The Sales Invoice raised once the order is paid will not accept a record without " +
                        siUnmet.map((f) => `'${f.label || f.name}'`).join(", ") +
                        ". Give each one a fixed value on this mapping.");
                }
            }
        }
        await this.recordMappingTest(args.mapping_id, warnings.length === 0, {
            payload: result.payload,
            key_value: keyValue,
            skipped_fields: result.skippedFields,
            warnings,
        });
        return {
            ok: true,
            payload: result.payload,
            key_value: keyValue,
            skipped_fields: result.skippedFields,
            warnings,
            rehearsal_passed: warnings.length === 0,
        };
    }
    /**
     * Rehearse the pull half: a Frappe-shaped sample through the mapping,
     * and whether every field the store cannot create this record without
     * is covered by a pair that flows this way.
     *
     * The push rehearsal has asked ERPNext's question since the gate
     * existed. A mapping that only pulls was being refused for ERPNext
     * fields it never writes, and never asked the store's.
     */
    async dryRunPull(args) {
        const mapping = await this.getMapping(args.mapping_id);
        if (!mapping)
            return { ok: false, message: "mapping not found" };
        const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
        if (!entity) {
            return { ok: false, message: `medusa entity '${mapping.medusa_entity}' has no registry entry` };
        }
        const fields = mapping.field_mappings;
        const mappingDirection = mapping.direction;
        // A Frappe row as the pull cron reads it: every field present, keyed
        // by fieldname. Enough to prove the translation and the coverage.
        const meta = await this.getDoctypeMeta(mapping.doctype);
        const sample = {};
        for (const f of meta.ok ? (meta.fields ?? []) : [])
            sample[f.fieldname] = `sample ${f.fieldname}`;
        for (const p of fields ?? []) {
            if (p.erpnext_field && !(p.erpnext_field in sample))
                sample[p.erpnext_field] = `sample ${p.erpnext_field}`;
        }
        sample.name = sample.name ?? "sample-key";
        if (mapping.key_erpnext_field && sample[mapping.key_erpnext_field] === undefined) {
            sample[mapping.key_erpnext_field] = "sample-key";
        }
        const result = (0, mapping_engine_1.applyMapping)({
            direction: "pull",
            fields,
            mappingDirection,
            source: sample,
            options: await this.transformOptions(),
        });
        if (result.ok === false) {
            return { ok: false, message: `${result.reason} (field=${result.field ?? "?"})` };
        }
        const keyValue = String(result.payload?.[mapping.key_medusa_field] ?? sample[mapping.key_erpnext_field] ?? "");
        const warnings = [];
        if (!Object.keys(result.payload ?? {}).length) {
            warnings.push("The mapping carries nothing into the store. Check the Frappe fieldnames against the doctype.");
        }
        if (!keyValue) {
            warnings.push(`No value for the key '${mapping.key_erpnext_field}', so nothing could be matched in the store.`);
        }
        // What the store will not create this record without. Discovery says
        // which; the curated fallback has no opinion, and that is reported
        // rather than passed in silence.
        const described = await (0, discovery_runtime_1.discoverEntityFields)(args.container, mapping.medusa_entity);
        const required = (described.fields ?? [])
            .filter((f) => f.required)
            .map((f) => ({ name: f.path, label: f.label }));
        if (required.length) {
            const unmet = (0, mapping_engine_1.unmetRequired)({ direction: "pull", fields, mappingDirection, required });
            if (unmet.length) {
                warnings.push(`The store will not create a ${entity.label ?? mapping.medusa_entity} without ` +
                    unmet.map((f) => `'${f.label || f.name}'`).join(", ") +
                    ". Map each one from a Frappe field.");
            }
        }
        await this.recordMappingTest(args.mapping_id, warnings.length === 0, {
            direction: "pull",
            payload: result.payload,
            key_value: keyValue,
            skipped_fields: result.skippedFields,
            warnings,
        });
        return {
            ok: true,
            payload: result.payload,
            key_value: keyValue,
            skipped_fields: result.skippedFields,
            warnings,
            rehearsal_passed: warnings.length === 0,
        };
    }
    /** Rehearse every direction this mapping actually uses. */
    async dryRun(args) {
        const mapping = await this.getMapping(args.mapping_id);
        if (!mapping)
            return { ok: false, message: "mapping not found" };
        if (mapping.direction === "pull")
            return this.dryRunPull(args);
        if (mapping.direction === "push")
            return this.dryRunPush(args);
        const push = await this.dryRunPush(args);
        if (!push.ok)
            return push;
        const pull = await this.dryRunPull(args);
        if (!pull.ok)
            return pull;
        const warnings = [...(push.warnings ?? []), ...(pull.warnings ?? [])];
        await this.recordMappingTest(args.mapping_id, warnings.length === 0, { push, pull, warnings });
        return {
            ok: true,
            payload: push.payload,
            pull_payload: pull.payload,
            key_value: push.key_value,
            skipped_fields: [...(push.skipped_fields ?? []), ...(pull.skipped_fields ?? [])],
            warnings,
            rehearsal_passed: warnings.length === 0,
        };
    }
    // ─────────────────────────────────────────────────────────────────
    // Push via mapping
    //
    // Called by the subscriber. Builds the payload via the engine and
    // logs into erpnext_sync_event tagged with mapping_id.
    // ─────────────────────────────────────────────────────────────────
    /**
     * Push one enriched Medusa record through a specific mapping: policy,
     * trigger, allowlist, transform and the skip-unchanged hash run as
     * before; the transport is paused until Phase 2 (see ./outbound.ts),
     * so the row is recorded as `paused` and nothing leaves.
     */
    async pushViaMapping(args) {
        const cfg = await this.getActiveConfig();
        if (!cfg.enable_sync) {
            return { ok: true, status: "skipped", reason: "sync-disabled" };
        }
        if (!cfg.erpnext_url) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: "ERPNext URL not configured",
                target_url: null,
                mapping_id: args.mapping.id,
            });
            return { ok: true, status: "skipped", reason: "not-configured" };
        }
        // ERPNext owns the catalogue. A product invented in the storefront
        // must not quietly become an Item with no cost, stock or purchase
        // history behind it; the operator says whether it may create one,
        // must be attached to an existing one first, or must not travel.
        if (args.mapping.medusa_entity === "product") {
            // A product is linked when erpnext_link says so, or when it
            // still carries the older metadata key from before the table.
            const linked = (0, product_policy_1.isLinked)(args.record) ||
                (args.record?.id != null && Boolean((await this.remoteNameFor("product", String(args.record.id)))?.erpnext_name));
            const verdict = (0, product_policy_1.decideProductPush)({
                policy: cfg.medusa_product_policy,
                event: args.event,
                linked,
            });
            if (verdict.allow === false) {
                const reason = verdict.reason;
                await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                    status: "skipped",
                    last_error: reason,
                    target_url: null,
                    mapping_id: args.mapping.id,
                });
                return { ok: true, status: "skipped", reason };
            }
        }
        // The document's own say. ERPNext showed us which way it moves the
        // last time we saw it; a record set to ERPNext → Medusa, or not
        // selected at all, never pushes, whatever the mapping allows.
        if (args.record?.id != null) {
            const [link] = await this.listErpnextLinks({ medusa_entity: args.mapping.medusa_entity, medusa_id: String(args.record.id) }, { take: 1 });
            const verdict = (0, selection_1.pushAllowedByRecord)(link ?? null);
            if (verdict.allowed === false) {
                await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                    status: "skipped",
                    last_error: verdict.reason,
                    target_url: null,
                    mapping_id: args.mapping.id,
                    action: "skipped",
                });
                return { ok: true, status: "skipped", reason: verdict.reason };
            }
        }
        // Does this RECORD qualify? `events` decided the event was a
        // candidate; the trigger decides whether this particular record
        // should be in ERPNext at all yet. Used to be a hard-coded KYC
        // check in the forwarder that applied to every customer mapping
        // whether or not the operator wanted it.
        const trigger = (0, trigger_1.evaluateTrigger)(args.mapping.trigger_condition, args.record);
        if (!trigger.ok) {
            // A condition that doesn't parse holds everything back
            // rather than releasing it — see trigger.ts. Log loudly so
            // the reason is visible instead of looking like silence.
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "failed",
                last_error: `trigger_condition is invalid: ${trigger.error}`,
                target_url: null,
                mapping_id: args.mapping.id,
            });
            return { ok: false, status: "failed", error: `invalid trigger_condition: ${trigger.error}` };
        }
        if (!trigger.matched) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: "trigger_condition not met",
                target_url: null,
                mapping_id: args.mapping.id,
                action: "skipped",
            });
            return { ok: true, status: "skipped", reason: "trigger_not_met" };
        }
        // Same gate as forwardEvent — enforced here too so the mapping
        // path, the admin bulk-push routes and any `medusa exec` script
        // all go through it rather than only the event subscriber.
        const gate = await this.checkPushAllowed(args.record);
        if (!gate.allowed) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: gate.reason,
                target_url: null,
                mapping_id: args.mapping.id,
            });
            return { ok: true, status: "skipped", reason: gate.reason };
        }
        const mainDoctype = String(args.mapping.doctype);
        const allPairs = (args.mapping.field_mappings ?? []);
        const transformOptions = await this.transformOptions();
        const transform = (0, mapping_engine_1.applyMapping)({
            direction: "push",
            fields: (0, secondary_doctypes_1.pairsForDoctype)(allPairs, mainDoctype, mainDoctype),
            mappingDirection: args.mapping.direction,
            source: args.record,
            options: transformOptions,
        });
        // One payload per secondary DocType; an empty one sends nothing.
        const secondaries = [];
        for (const sec of (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(args.mapping.secondary_doctypes, mainDoctype)) {
            const t = (0, mapping_engine_1.applyMapping)({
                direction: "push",
                fields: (0, secondary_doctypes_1.pairsForDoctype)(allPairs, mainDoctype, sec.doctype),
                mappingDirection: args.mapping.direction,
                source: args.record,
                options: transformOptions,
            });
            if (t.ok === false) {
                const err = `${sec.doctype}: ${t.reason} (field=${t.field ?? "?"})`;
                await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, { status: "failed", last_error: err, target_url: null, mapping_id: args.mapping.id });
                return { ok: false, status: "failed", error: err };
            }
            if (Object.keys(t.payload ?? {}).length)
                secondaries.push({ sec, payload: t.payload });
        }
        if (transform.ok === false) {
            const err = `${transform.reason} (field=${transform.field ?? "?"})`;
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "failed",
                last_error: err,
                target_url: null,
                mapping_id: args.mapping.id,
            });
            return { ok: false, status: "failed", error: err };
        }
        const keyValue = (0, mapping_engine_1.getByPath)(args.record, args.mapping.key_medusa_field);
        const keyValueStr = keyValue == null || keyValue === ""
            ? null
            : String(keyValue);
        // "Only sync when something actually changed."
        //
        // Medusa events don't carry the previous document, so there is
        // nothing to diff against. What we DO have is the payload we
        // last successfully sent for this record — if the new one
        // hashes the same, nothing a mapped field cares about moved,
        // and the write would be a no-op on the far side.
        //
        // Hashing the payload (not the record) is the point: an
        // unrelated field changing on the customer must not count as a
        // change for a mapping that doesn't sync that field.
        const payloadHash = crypto_1.default
            .createHash("sha256")
            .update(JSON.stringify({
            key: keyValueStr,
            doctype: args.mapping.doctype,
            payload: transform.payload,
            ...(secondaries.length ? { secondaries: secondaries.map((s) => [s.sec.doctype, s.payload]) } : {}),
        }))
            .digest("hex");
        // A store order's documents follow its payments and cancellation,
        // which the mapped payload need not carry, so an unchanged payload
        // is no reason to skip one.
        const salesDocPush = SALES_DOCTYPES.has(args.mapping.doctype) && args.mapping.medusa_entity === "order";
        if (args.mapping.skip_unchanged && keyValueStr && !salesDocPush) {
            const [previous] = await this.listErpnextSyncEvents({
                mapping_id: args.mapping.id,
                payload_hash: payloadHash,
                status: "success",
                // A test run must never be the reason a genuine change
                // is dropped as a duplicate.
                is_test: false,
            }, { take: 1 });
            if (previous) {
                await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                    status: "skipped",
                    last_error: "payload identical to the last successful push",
                    target_url: null,
                    mapping_id: args.mapping.id,
                    action: "skipped",
                    payload_hash: payloadHash,
                });
                return { ok: true, status: "skipped", reason: "unchanged" };
            }
        }
        // Delete/cancel events fire AFTER the row is gone, so the record can't
        // be enriched — the payload is just `{ id }` and the natural key
        // (email/handle) is unavailable. Fall back to keying on the Medusa id
        // against whatever ERPNext field the mapping maps the id to (e.g.
        // `medusa_customer_id`), so the far side can still find the doc to
        // disable/cancel. Non-delete events, and deletes whose natural key IS
        // present, are unaffected.
        let effKeyField = args.mapping.key_erpnext_field;
        let effKeyValue = keyValueStr;
        const isDeleteEvent = /\.(deleted|canceled|cancelled)$/.test(args.event);
        if (isDeleteEvent) {
            // Always key deletes on the stable Medusa id (against the ERPNext
            // `medusa_*_id` field the mapping maps the id to), when available.
            // The natural key (email/handle) requires enriching the record,
            // which is unreliable for a row that's already gone — so a delete
            // must not depend on it.
            const idPair = args.mapping.field_mappings.find((p) => p.medusa_path === "id");
            const rid = args.record?.id;
            if (idPair && rid != null) {
                effKeyField = idPair.erpnext_field;
                effKeyValue = String(rid);
            }
        }
        if (outbound_1.OUTBOUND_PAUSED) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: outbound_1.OUTBOUND_PAUSED_MESSAGE,
                target_url: null,
                mapping_id: args.mapping.id,
                action: "paused",
                payload_hash: payloadHash,
            });
            return (0, outbound_1.pausedResult)();
        }
        const rest = await this.restClient();
        if (!rest) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: "ERPNext URL or API credentials not configured",
                target_url: null,
                mapping_id: args.mapping.id,
            });
            return { ok: true, status: "skipped", reason: "not-configured" };
        }
        // ERPNext's own change coming home: an inbound write touched this
        // record moments ago, and the event it emitted is what brought us
        // here. Pushing it back would only bounce it again. A push that
        // would change the document is a person's edit made inside the
        // window, and travels.
        const entityRef = `${args.mapping.medusa_entity}:${args.record?.id ?? ""}`;
        if (args.record?.id != null &&
            (await this.recentInboundEcho(entityRef)) &&
            !(0, echo_1.pushChangesRemote)(transform.payload, await this.linkedRemoteDoc(rest.client, args.mapping.medusa_entity, String(args.record.id), String(args.mapping.doctype)))) {
            await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
                status: "skipped",
                last_error: "echo of an ERPNext write applied here moments ago",
                target_url: null,
                mapping_id: args.mapping.id,
                action: "skipped",
                payload_hash: payloadHash,
            });
            return { ok: true, status: "skipped", reason: "echo" };
        }
        const targetUrl = `${rest.cfg.erpnext_url}/api/resource/${encodeURIComponent(args.mapping.doctype)}`;
        const row = await this.upsertEventRow({ event: args.event, event_id: args.event_id, data: args.record }, {
            status: "pending",
            last_error: null,
            target_url: targetUrl,
            mapping_id: args.mapping.id,
            payload_hash: payloadHash,
            entity_ref: entityRef,
        });
        try {
            const ctx = {
                client: rest.client,
                cfg: rest.cfg,
                mapping: args.mapping,
                record: args.record,
                event: args.event,
                payload: transform.payload,
                keyField: effKeyField,
                keyValue: effKeyValue,
                container: args.container,
                secondaries,
            };
            const dispatch = async () => {
                if (isDeleteEvent)
                    return this.pushRemoval(ctx);
                if (args.event === order_accounting_1.ORDER_REFUNDED_EVENT) {
                    return salesDocPush
                        ? this.pushOrderRefund(ctx)
                        : { ok: true, status: "skipped", reason: `a refund changes nothing on ${args.mapping.doctype}` };
                }
                if (salesDocPush)
                    return this.pushSalesDocument(ctx);
                if (args.mapping.doctype === "Customer" && args.mapping.medusa_entity === "customer")
                    return this.pushCustomerDoc(ctx);
                return this.pushGenericDoc(ctx);
            };
            // Placement and capture of one order arrive together; two pushes
            // at once would each find no Sales Order and make one.
            let outcome = args.mapping.medusa_entity === "order" && args.record?.id != null
                ? await oneAtATime(_orderLocks, String(args.record.id), dispatch)
                : await dispatch();
            // The documents that hang off the main one, once it has a name.
            if (outcome.ok && outcome.status === "success" && secondaries.length) {
                if (!outcome.name) {
                    outcome = { ...outcome, notes: [...(outcome.notes ?? []), "secondary DocTypes not written: the main document's name is unknown"] };
                }
                else {
                    const sec = await this.pushSecondaryDocs(ctx, outcome.name);
                    outcome = sec.ok === false ? sec : { ...outcome, notes: [...(outcome.notes ?? []), ...sec.notes] };
                }
            }
            if (outcome.ok === false) {
                const errMsg = String(outcome.error).slice(0, ERROR_TRUNCATE);
                await this.updateErpnextSyncEvents({ id: row.id, status: "failed", last_error: errMsg });
                await this.markMappingPushOutcome(args.mapping.id, errMsg);
                return { ok: false, status: "failed", httpStatus: outcome.httpStatus, error: errMsg };
            }
            const notes = outcome.notes?.length ? outcome.notes.join("; ").slice(0, ERROR_TRUNCATE) : null;
            await this.updateErpnextSyncEvents({
                id: row.id,
                status: outcome.status === "skipped" ? "skipped" : "success",
                succeeded_at: outcome.status === "skipped" ? null : new Date(),
                action: String(outcome.status === "skipped" ? "skipped" : outcome.action).slice(0, 40),
                last_error: outcome.status === "skipped" ? (outcome.reason ?? null) : notes,
                payload_hash: payloadHash,
            });
            await this.markMappingPushOutcome(args.mapping.id, null);
            return outcome.status === "skipped"
                ? { ok: true, status: "skipped", reason: outcome.reason }
                : { ok: true, status: "success", action: outcome.action };
        }
        catch (err) {
            const errMsg = describeError(err).slice(0, ERROR_TRUNCATE);
            await this.updateErpnextSyncEvents({ id: row.id, status: "failed", last_error: errMsg });
            await this.markMappingPushOutcome(args.mapping.id, errMsg);
            return { ok: false, status: "failed", error: errMsg };
        }
    }
    // ─────────────────────────────────────────────────────────────────
    // Medusa → ERPNext over plain Frappe REST
    // ─────────────────────────────────────────────────────────────────
    async restClient(timeoutMs) {
        const cfg = await this.getActiveConfig();
        const creds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !creds)
            return null;
        // A write runs ERPNext's validations and naming before it answers;
        // a Customer or a Sales Order takes longer than a read. The push
        // runs on the worker, so waiting costs nothing but the wait. A
        // storefront request passes its own short timeout instead.
        return {
            client: (0, frappe_client_1.makeFrappeClient)({
                baseUrl: cfg.erpnext_url,
                token: creds,
                timeoutMs: timeoutMs ?? Math.max(cfg.request_timeout_ms, PUSH_TIMEOUT_MS),
            }),
            cfg,
        };
    }
    /** The API user's email, so a document it wrote is recognised when it
     *  comes back through a webhook or a pull. Cached per process. */
    async apiUserEmail() {
        const now = Date.now();
        if (_apiUserCache && _apiUserCache.expiresAt > now)
            return _apiUserCache.value;
        let value = null;
        const rest = await this.restClient();
        if (rest) {
            const res = await rest.client.get("/api/method/frappe.auth.get_logged_user");
            if (res.ok && typeof res.data === "string" && res.data.includes("@"))
                value = res.data.toLowerCase();
        }
        _apiUserCache = { value, expiresAt: now + (value ? 60 * 60 * 1000 : 60 * 1000) };
        return value;
    }
    /** Which fields a DocType has, custom fields included. */
    async hasFieldFn(doctype) {
        const meta = await this.getDoctypeMeta(doctype);
        const names = new Set((meta.fields ?? []).map((f) => String(f.fieldname)));
        return (f) => names.has(f);
    }
    /** ERPNext's Country name for an ISO code. Cached per process. */
    async countryNameFor(client, code) {
        const wanted = String(code ?? "").trim().toLowerCase();
        if (!wanted)
            return null;
        const now = Date.now();
        if (!_countryCache || _countryCache.expiresAt < now) {
            const res = await client.get("/api/resource/Country", {
                fields: JSON.stringify(["name", "code"]),
                limit_page_length: "500",
            });
            const map = new Map();
            const countries = res.ok === true && Array.isArray(res.data) ? res.data : [];
            for (const r of countries) {
                if (r?.code && r?.name)
                    map.set(String(r.code).toLowerCase(), String(r.name));
            }
            // A failed or empty read is not an answer; caching it would
            // say "no such country" for a day.
            if (!map.size)
                return null;
            _countryCache = { map, expiresAt: now + 24 * 60 * 60 * 1000 };
        }
        return _countryCache.map.get(wanted) ?? null;
    }
    /** The mandatory fields of a doctype the push fills on its own, so the
     *  editor's "Required in ERPNext" panel agrees with the rehearsal. */
    async transportFilledFor(doctype) {
        const rest = await this.restClient();
        return Array.from((0, push_rest_1.transportFilledFields)(doctype, rest ? await this.pushDefaults(rest.client) : {}));
    }
    /** The company's own address, its GST state and its country, cached for an hour. */
    async companySite(client, company) {
        const key = company ?? "";
        const now = Date.now();
        const hit = _companySiteCache.get(key);
        if (hit && hit.expiresAt > now)
            return hit;
        const out = { address: null, state: null, countryCode: null, expiresAt: now + 60 * 60 * 1000 };
        if (!company)
            return out;
        const res = await client.get("/api/resource/Address", {
            fields: JSON.stringify(["name", "gst_state_number", "state"]),
            filters: JSON.stringify([
                ["Dynamic Link", "link_doctype", "=", "Company"],
                ["Dynamic Link", "link_name", "=", company],
                ["is_your_company_address", "=", 1],
            ]),
            limit_page_length: "5",
        });
        const row = res.ok === true && Array.isArray(res.data) ? res.data[0] : null;
        out.address = row?.name ? String(row.name) : null;
        out.state = (0, push_rest_1.gstStateCodeOf)(row?.gst_state_number) ?? (0, push_rest_1.gstStateCodeOf)(row?.state);
        const co = await client.get(`/api/resource/Company/${encodeURIComponent(company)}`);
        const countryName = co.ok === true ? co.data?.country : null;
        if (countryName) {
            const c = await client.get(`/api/resource/Country/${encodeURIComponent(String(countryName))}`);
            if (c.ok === true && c.data?.code)
                out.countryCode = String(c.data.code).toLowerCase();
        }
        // An unreadable site is not an answer to keep for an hour.
        if (res.ok === true)
            _companySiteCache.set(key, out);
        return out;
    }
    /**
     * The tax rows ERPNext's own form would put on a sales document:
     * India Compliance picks the taxes template for the place of supply
     * inside `get_party_details`, from the billing, shipping and company
     * addresses. Shipping goes ahead of them as its own row (see
     * `supplyTaxes`). A failure stops the push rather than writing a
     * document without GST.
     */
    async salesTaxes(client, args) {
        const res = await client.post("/api/method/erpnext.accounts.party.get_party_details", {
            party: args.customer,
            party_type: "Customer",
            doctype: args.doctype,
            company: args.defaults.company,
            posting_date: args.date,
            party_address: args.addresses.billing ?? null,
            shipping_address: args.addresses.shipping ?? null,
            company_address: args.defaults.companyAddress ?? null,
        });
        if (res.ok === false)
            return { ok: false, error: `taxes for ${args.customer}: ${res.error}` };
        const gstRows = Array.isArray(res.data?.taxes) ? res.data.taxes : [];
        if (!gstRows.length) {
            return { ok: false, error: `ERPNext chose no taxes for ${args.customer} (template "${res.data?.taxes_and_charges ?? ""}")` };
        }
        const built = (0, push_rest_1.supplyTaxes)({ gstRows, shipping: args.shipping, shippingAccount: args.defaults.shippingAccount });
        return { ok: true, template: res.data?.taxes_and_charges ? String(res.data.taxes_and_charges) : null, rows: built.taxes, notes: built.notes };
    }
    /**
     * What ERPNext's form does on its own and a REST write does not:
     * render the Terms and Conditions text from `tc_name`.
     */
    async completeSalesDoc(client, doc) {
        let out = doc;
        if (out.tc_name && !out.terms) {
            const res = await client.post("/api/method/erpnext.setup.doctype.terms_and_conditions.terms_and_conditions.get_terms_and_conditions", { template_name: out.tc_name, doc: JSON.stringify(out) });
            if (res.ok === true && typeof res.data === "string" && res.data.trim())
                out = { ...out, terms: res.data };
        }
        return out;
    }
    /** Where documents land: the settings, else ERPNext's own defaults. */
    async pushDefaults(client) {
        const row = await this.findSettingsRow();
        const now = Date.now();
        if (!_defaultsCache || _defaultsCache.expiresAt < now) {
            let readable = true;
            const single = async (doctype, field) => {
                const res = await client.get("/api/method/frappe.client.get_single_value", { doctype, field });
                if (res.ok !== true)
                    readable = false;
                return res.ok && res.data ? String(res.data) : null;
            };
            const read = {
                company: await single("Global Defaults", "default_company"),
                priceList: await single("Selling Settings", "selling_price_list"),
                expiresAt: now + 60 * 60 * 1000,
            };
            // An unreadable site is not an answer to keep for an hour.
            if (readable)
                _defaultsCache = read;
            else
                return this.defaultsFrom(row, read, client);
        }
        return this.defaultsFrom(row, _defaultsCache, client);
    }
    async defaultsFrom(row, site, client) {
        const company = row?.erpnext_company || site.company;
        let companyAddress = null;
        try {
            companyAddress = (await this.companySite(client, company)).address;
        }
        catch {
            companyAddress = null;
        }
        return {
            company,
            priceList: row?.erpnext_price_list || site.priceList,
            customerGroup: row?.erpnext_customer_group || null,
            territory: row?.erpnext_territory || null,
            shippingAccount: row?.erpnext_shipping_account || null,
            taxesTemplate: row?.erpnext_taxes_template || null,
            companyAddress,
        };
    }
    /** Did an inbound write touch this record within the echo window? */
    async recentInboundEcho(entityRef) {
        try {
            const [row] = await this.listErpnextSyncEvents({ direction: "inbound", status: "success", entity_ref: entityRef }, { take: 1, order: { last_attempt_at: "DESC" } });
            return Boolean(row && (0, echo_1.isWithinEchoWindow)(row.last_attempt_at ?? row.succeeded_at));
        }
        catch {
            return false;
        }
    }
    /** The ERPNext document this Medusa record became, or null when there
     *  is no link or it cannot be read. */
    async linkedRemoteDoc(client, medusa_entity, medusa_id, doctype) {
        const link = await this.remoteNameFor(medusa_entity, medusa_id, doctype);
        if (!link?.erpnext_name)
            return null;
        const res = await client.get(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(link.erpnext_name)}`);
        return res.ok && res.data ? res.data : null;
    }
    /** The ERPNext name this Medusa record became, from the link table. */
    async remoteNameFor(medusa_entity, medusa_id, doctype) {
        const [link] = await this.listErpnextLinks({ medusa_entity, medusa_id: String(medusa_id), ...(doctype ? { doctype } : {}) }, { take: 1 });
        return link ?? null;
    }
    /** Find a document by the mapping's key when no link knows it yet. */
    async lookupRemoteByKey(client, doctype, keyField, keyValue, has) {
        if (!keyValue)
            return null;
        if (keyField === "name") {
            const res = await client.get(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(keyValue)}`);
            return res.ok && res.data?.name ? String(res.data.name) : null;
        }
        if (!has(keyField))
            return null;
        const res = await client.get(`/api/resource/${encodeURIComponent(doctype)}`, {
            fields: JSON.stringify(["name"]),
            filters: JSON.stringify([[keyField, "=", keyValue]]),
            limit_page_length: "1",
        });
        const rows = res.ok === true && Array.isArray(res.data) ? res.data : [];
        return rows[0]?.name ? String(rows[0].name) : null;
    }
    /** POST a new document or PUT an existing one. */
    async writeRemote(client, doctype, name, doc) {
        const res = name
            ? await client.put(`/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`, doc)
            : await client.post(`/api/resource/${encodeURIComponent(doctype)}`, doc);
        if (res.ok === false)
            return { ok: false, error: res.error, httpStatus: res.status || undefined };
        const written = res.data?.name ? String(res.data.name) : name;
        if (!written)
            return { ok: false, error: "ERPNext answered without a document name" };
        return { ok: true, name: written, created: !name };
    }
    /**
     * Any DocType the mapping names: find it through the link table or the
     * key field, then create or update it as the mapping allows. A new
     * document on a selection DocType is stamped with its direction so the
     * next push finds it selected.
     */
    /**
     * The secondary documents of a sync, after the main one: each is found
     * through its link to the main document (a Link field, or its Links
     * table) and updated, or created with that link set.
     */
    async pushSecondaryDocs(ctx, mainName) {
        const { client, mapping, record } = ctx;
        const mainDoctype = String(mapping.doctype);
        const notes = [];
        for (const { sec, payload } of ctx.secondaries ?? []) {
            const existing = await this.findSecondaryName(client, sec, mainDoctype, mainName);
            if (existing && mapping.allow_update === false) {
                notes.push(`${sec.doctype} ${existing} left alone: update not allowed by the mapping`);
                continue;
            }
            if (!existing && mapping.allow_create === false) {
                notes.push(`${sec.doctype} not created: create not allowed by the mapping`);
                continue;
            }
            const doc = existing ? { ...payload } : { ...payload, ...(0, secondary_doctypes_1.secondaryLinkPayload)(sec, mainDoctype, mainName) };
            const written = await this.writeRemote(client, sec.doctype, existing, doc);
            if (written.ok === false)
                return { ok: false, error: `${sec.doctype}: ${written.error}`, httpStatus: written.httpStatus };
            if (record?.id != null) {
                await this.recordLink({
                    doctype: sec.doctype,
                    erpnext_name: written.name,
                    medusa_entity: mapping.medusa_entity,
                    medusa_id: String(record.id),
                    mapping_id: mapping.id,
                    state: "active",
                });
            }
            notes.push(`${sec.doctype} ${written.name} ${written.created ? "created" : "updated"}`);
        }
        return { ok: true, notes };
    }
    /** The name of the secondary document tied to this main one, if any. */
    async findSecondaryName(client, sec, mainDoctype, mainName) {
        const res = await client.get(`/api/resource/${encodeURIComponent(sec.doctype)}`, {
            filters: JSON.stringify((0, secondary_doctypes_1.secondaryLookupFilters)(sec, mainDoctype, mainName)),
            fields: JSON.stringify(["name"]),
            limit_page_length: "1",
        });
        const name = res.ok === true && Array.isArray(res.data) ? res.data[0]?.name : null;
        return name != null ? String(name) : null;
    }
    /**
     * The main document with its linked secondary documents laid under it
     * by DocType name, which is how a pull reads a secondary pair
     * (`Contact.first_name`). A DocType with no linked document reads as
     * absent, so its pairs are skipped rather than blanked.
     */
    async hydrateSecondaries(client, mapping, doc) {
        const mainDoctype = String(mapping?.doctype ?? "");
        const secs = (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(mapping?.secondary_doctypes, mainDoctype);
        if (!secs.length || !client || !doc?.name)
            return doc;
        const out = { ...doc };
        for (const sec of secs) {
            const name = await this.findSecondaryName(client, sec, mainDoctype, String(doc.name));
            if (!name)
                continue;
            const full = await client.get(`/api/resource/${encodeURIComponent(sec.doctype)}/${encodeURIComponent(name)}`);
            if (full.ok === true && full.data)
                out[sec.doctype] = full.data;
        }
        return out;
    }
    /** Pull mappings that name this DocType as a secondary one. */
    async mappingsWithSecondary(doctype) {
        const mappings = await this.listEnabledPullMappings();
        const out = [];
        for (const m of mappings) {
            const sec = (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(m.secondary_doctypes, m.doctype).find((s) => s.doctype === doctype);
            if (sec)
                out.push({ mapping: m, sec });
        }
        return out;
    }
    async pushGenericDoc(ctx) {
        const { client, cfg, mapping, record } = ctx;
        const doctype = String(mapping.doctype);
        const has = await this.hasFieldFn(doctype);
        const link = record?.id != null ? await this.remoteNameFor(mapping.medusa_entity, String(record.id), doctype) : null;
        const existing = link?.erpnext_name ?? (await this.lookupRemoteByKey(client, doctype, ctx.keyField, ctx.keyValue, has));
        if (existing && mapping.allow_update === false)
            return { ok: true, status: "skipped", reason: "update not allowed by the mapping" };
        if (!existing && mapping.allow_create === false)
            return { ok: true, status: "skipped", reason: "create not allowed by the mapping" };
        const doc = { ...ctx.payload };
        let stamped;
        if (!existing && (0, selection_1.isSyncDoctype)(doctype, cfg.sync_doctypes) && doc[selection_1.SELECTION_FIELD] === undefined) {
            stamped = (0, push_rest_1.directionForCreated)(mapping.direction);
            doc[selection_1.SELECTION_FIELD] = stamped;
        }
        const written = await this.writeRemote(client, doctype, existing, doc);
        if (written.ok === false)
            return written;
        if (record?.id != null) {
            await this.recordLink({
                doctype,
                erpnext_name: written.name,
                medusa_entity: mapping.medusa_entity,
                medusa_id: String(record.id),
                mapping_id: mapping.id,
                state: "active",
                ...(stamped !== undefined ? { remote_direction: stamped } : {}),
            });
        }
        return { ok: true, status: "success", action: written.created ? "created" : "updated", name: written.name };
    }
    /**
     * A Customer, with its Addresses as linked Address documents. Matched
     * through the link table, then by the mapping's key (email), then by
     * email as a last resort.
     */
    async pushCustomerDoc(ctx) {
        const { client, cfg, mapping, record } = ctx;
        const has = await this.hasFieldFn("Customer");
        const defaults = await this.pushDefaults(client);
        const link = record?.id != null ? await this.remoteNameFor("customer", String(record.id), "Customer") : null;
        let existing = link?.erpnext_name ?? (await this.lookupRemoteByKey(client, "Customer", ctx.keyField, ctx.keyValue, has));
        if (!existing && record?.email && has("email_id")) {
            existing = await this.lookupRemoteByKey(client, "Customer", "email_id", String(record.email).toLowerCase(), has);
        }
        if (existing && mapping.allow_update === false)
            return { ok: true, status: "skipped", reason: "update not allowed by the mapping" };
        if (!existing && mapping.allow_create === false)
            return { ok: true, status: "skipped", reason: "create not allowed by the mapping" };
        const notes = [];
        let remote = null;
        if (existing) {
            const res = await client.get(`/api/resource/Customer/${encodeURIComponent(existing)}`);
            if (res.ok && res.data)
                remote = res.data;
            else if (res.status === 404)
                existing = null;
        }
        const doc = (0, push_rest_1.buildCustomerDoc)({ record, mapped: ctx.payload, has, defaults, remote });
        // A Customer this store creates is selected in ERPNext from the
        // start, so the reconcile keeps it and later pushes are not refused
        // as unselected.
        let stamped;
        if (!existing && (0, selection_1.isSyncDoctype)("Customer", cfg.sync_doctypes) && doc[selection_1.SELECTION_FIELD] === undefined) {
            stamped = (0, push_rest_1.directionForCreated)(mapping.direction);
            doc[selection_1.SELECTION_FIELD] = stamped;
        }
        // The Contact first: the Customer's email and phone are fetched from
        // it when the Customer is saved.
        if (remote?.customer_primary_contact) {
            const contact = await this.syncPrimaryContact(client, String(remote.customer_primary_contact), {
                email: doc.email_id,
                phone: doc.mobile_no,
                first_name: record?.first_name ?? null,
                last_name: record?.last_name ?? null,
            });
            if (contact.ok === false)
                notes.push(`contact ${remote.customer_primary_contact}: ${contact.reason}`);
        }
        const written = await this.writeRemote(client, "Customer", existing, doc);
        if (written.ok === false)
            return written;
        if (record?.id != null) {
            await this.recordLink({
                doctype: "Customer",
                erpnext_name: written.name,
                medusa_entity: "customer",
                medusa_id: String(record.id),
                mapping_id: mapping.id,
                state: "active",
                ...(stamped !== undefined ? { remote_direction: stamped } : {}),
            });
        }
        for (const input of (0, push_rest_1.addressesOfCustomer)(record)) {
            const out = await this.syncAddress(client, written.name, input);
            if (out.ok === false)
                notes.push(`address ${input.id}: ${out.reason}`);
        }
        return { ok: true, status: "success", action: written.created ? "created" : "updated", name: written.name, notes };
    }
    /** Put the store's email and phone on a customer's primary Contact. */
    async syncPrimaryContact(client, contactName, want) {
        const res = await client.get(`/api/resource/Contact/${encodeURIComponent(contactName)}`);
        if (res.ok !== true || !res.data)
            return { ok: false, reason: `not readable (HTTP ${res.status ?? "?"})` };
        const patch = (0, push_rest_1.primaryContactPatch)(res.data, want);
        if (!patch)
            return { ok: true, changed: false };
        const written = await this.writeRemote(client, "Contact", contactName, patch);
        if (written.ok === false)
            return { ok: false, reason: written.error };
        return { ok: true, changed: true };
    }
    /** One Address document for a customer, keyed by the Medusa address id. */
    async syncAddress(client, customerName, input) {
        const has = await this.hasFieldFn("Address");
        const countryName = await this.countryNameFor(client, input.country_code);
        const build = (0, push_rest_1.buildAddressDoc)({ input, customerName, countryName, has });
        if (build.ok === false)
            return build;
        const link = await this.remoteNameFor("address", input.id, "Address");
        const written = await this.writeRemote(client, "Address", link?.erpnext_name ?? null, build.doc);
        if (written.ok === false)
            return { ok: false, reason: written.error };
        await this.recordLink({
            doctype: "Address",
            erpnext_name: written.name,
            medusa_entity: "address",
            medusa_id: input.id,
            state: "active",
        });
        return { ok: true, name: written.name };
    }
    /**
     * The Customer an order belongs to, in ERPNext: through the link table
     * for a registered customer (pushed through the customer mapping when
     * it has no link yet), by email for a guest, created from the order
     * when nothing matches.
     */
    async ensureCustomerForOrder(ctx) {
        const { client, container, record: order } = ctx;
        if (order?.customer_id) {
            const link = await this.remoteNameFor("customer", String(order.customer_id), "Customer");
            if (link?.erpnext_name)
                return { ok: true, name: link.erpnext_name };
            const [customerMapping] = (await this.listEnabledPushMappingsForEntity("customer")).filter((m) => m.doctype === "Customer");
            const customerEntity = (0, registry_1.getMedusaEntity)("customer");
            if (customerMapping && customerEntity && container) {
                const customer = await customerEntity.fetchById(container, String(order.customer_id));
                if (customer) {
                    const pushed = await this.pushViaMapping({
                        mapping: customerMapping,
                        event: "customer.updated",
                        event_id: `order:${order.id}:customer:${order.customer_id}`,
                        record: (0, push_rest_1.withOrderContact)(customer, order),
                        container,
                    });
                    if (pushed.ok && pushed.status === "success") {
                        const again = await this.remoteNameFor("customer", String(order.customer_id), "Customer");
                        if (again?.erpnext_name)
                            return { ok: true, name: again.erpnext_name };
                    }
                    // The store has said how a Customer is made, and that
                    // failed. A bare create here would only fail the same
                    // way without the mapping's fixed values, and hide the
                    // reason behind a second error.
                    if (pushed.ok === false)
                        return { ok: false, error: `customer: ${pushed.error}` };
                }
            }
        }
        const has = await this.hasFieldFn("Customer");
        const email = String(order?.email ?? "").toLowerCase();
        if (email && has("email_id")) {
            const found = await this.lookupRemoteByKey(client, "Customer", "email_id", email, has);
            if (found)
                return { ok: true, name: found };
        }
        if (!email)
            return { ok: false, error: "order has no customer and no email to make one from" };
        const person = order?.billing_address ?? order?.shipping_address ?? {};
        const doc = (0, push_rest_1.buildCustomerDoc)({
            record: { email, first_name: person.first_name, last_name: person.last_name, phone: person.phone, company_name: person.company },
            mapped: {},
            has,
            defaults: await this.pushDefaults(client),
        });
        // Made from an order, so it is the store's: selected Medusa → ERPNext,
        // which the reconcile leaves alone.
        const stamped = (0, selection_1.isSyncDoctype)("Customer", ctx.cfg.sync_doctypes) ? (0, push_rest_1.directionForCreated)("push") : undefined;
        if (stamped)
            doc[selection_1.SELECTION_FIELD] = stamped;
        const written = await this.writeRemote(client, "Customer", null, doc);
        if (written.ok === false)
            return { ok: false, error: `customer: ${written.error}` };
        await this.recordLink({
            doctype: "Customer",
            erpnext_name: written.name,
            medusa_entity: "customer",
            medusa_id: order?.customer_id ? String(order.customer_id) : `email:${email}`,
            state: "active",
            ...(stamped ? { remote_direction: stamped } : {}),
        });
        return { ok: true, name: written.name };
    }
    /** The ERPNext Item for an order line: the product's link, else its SKU
     *  when an Item of that code exists. */
    async itemCodeForLine(client, line, cache) {
        const productId = line?.variant?.product?.id ?? line?.product_id;
        const sku = line?.variant?.sku ? String(line.variant.sku) : null;
        const cacheKey = `${productId ?? ""}|${sku ?? ""}`;
        if (cache.has(cacheKey))
            return cache.get(cacheKey) ?? null;
        let code = null;
        if (productId) {
            const link = await this.remoteNameFor("product", String(productId));
            if (link?.erpnext_name)
                code = link.erpnext_name;
        }
        if (!code && sku) {
            const res = await client.get(`/api/resource/Item/${encodeURIComponent(sku)}`);
            if (res.ok && res.data?.name)
                code = String(res.data.name);
        }
        cache.set(cacheKey, code);
        return code;
    }
    /**
     * An order as a Sales Order, and a Sales Invoice once it is paid in
     * full, as drafts. The customer and the addresses are made first; a
     * line with no ERPNext Item stops the order rather than shipping it
     * short. With payments recorded, the documents are then submitted and
     * the payments booked as order-accounting.ts plans; a submission
     * ERPNext refuses fails the push and leaves the draft.
     */
    async pushSalesDocument(ctx, opts = {}) {
        const { client, mapping, record: order } = ctx;
        const settings = await this.findSettingsRow();
        const notes = [];
        const fullyPaid = opts.paidInFull === true || (0, push_rest_1.orderFullyPaid)(order);
        const plan = (0, order_accounting_1.planOrderAccounting)({
            recordPayments: Boolean(settings?.record_payments),
            order,
            fullyPaid,
            modes: (0, order_accounting_1.normalizePaymentModes)(settings?.payment_modes),
        });
        if (plan.action === "fail")
            return { ok: false, error: plan.error };
        const customer = await this.ensureCustomerForOrder(ctx);
        if (customer.ok === false)
            return { ok: false, error: customer.error };
        const addresses = {};
        for (const input of (0, push_rest_1.addressesOfOrder)(order)) {
            const out = await this.syncAddress(client, customer.name, input);
            if (out.ok === false) {
                notes.push(`${input.kind.toLowerCase()} address: ${out.reason}`);
                continue;
            }
            if (input.kind === "Billing")
                addresses.billing = out.name;
            else
                addresses.shipping = out.name;
        }
        // A checkout that ships and bills to one place often records only
        // the shipping address; without this ERPNext bills the customer's
        // first saved address instead of the one on the order.
        if (!addresses.billing && addresses.shipping)
            addresses.billing = addresses.shipping;
        const codes = new Map();
        const lineCodes = new Map();
        for (const li of Array.isArray(order?.items) ? order.items : []) {
            lineCodes.set(String(li?.id ?? li?.title), await this.itemCodeForLine(client, li, codes));
        }
        const defaults = await this.pushDefaults(client);
        const timezone = await this.siteTimezone();
        const taxes = await this.salesTaxes(client, {
            doctype: "Sales Order",
            customer: customer.name,
            defaults,
            addresses,
            date: (0, mapping_engine_2.formatInZone)(new Date(), timezone, false),
            shipping: (0, push_rest_1.shippingNet)(order) ?? (0, push_rest_1.orderTotals)(order).shipping,
        });
        if (taxes.ok === false)
            return { ok: false, error: taxes.error };
        notes.push(...taxes.notes);
        const taxFields = { taxes_and_charges: taxes.template ?? undefined, taxes: taxes.rows };
        const orderDocument = settings?.order_document ?? null;
        const wantSO = (0, push_rest_1.wantsSalesOrder)(orderDocument) || mapping.doctype === "Sales Order";
        const wantSI = (0, push_rest_1.wantsSalesInvoice)(orderDocument) || mapping.doctype === "Sales Invoice";
        let soName = null;
        let action = "unchanged";
        if (wantSO) {
            const has = await this.hasFieldFn("Sales Order");
            const build = (0, push_rest_1.buildSalesOrderDoc)({
                order,
                customerName: customer.name,
                itemCodeFor: (li) => lineCodes.get(String(li?.id ?? li?.title)) ?? null,
                addresses,
                defaults,
                has,
                timezone,
            });
            if (build.ok === false)
                return { ok: false, error: build.reason };
            notes.push(...build.notes);
            const link = await this.remoteNameFor("order", String(order.id), "Sales Order");
            let existing = link?.erpnext_name ?? null;
            if (existing) {
                const state = await client.get(`/api/resource/Sales%20Order/${encodeURIComponent(existing)}`);
                if (state.ok === false && state.status === 404)
                    existing = null;
                else if (state.ok && Number(state.data?.docstatus) !== 0) {
                    notes.push(`${existing} is already ${Number(state.data?.docstatus) === 2 ? "cancelled" : "submitted"}; not updated`);
                    soName = existing;
                }
            }
            if (!soName) {
                if (!existing && mapping.allow_create === false)
                    return { ok: true, status: "skipped", reason: "create not allowed by the mapping" };
                const doc = await this.completeSalesDoc(client, { ...build.doc, ...ctx.payload, ...taxFields, items: build.doc.items });
                const written = await this.writeRemote(client, "Sales Order", existing, doc);
                if (written.ok === false)
                    return written;
                soName = written.name;
                action = written.created ? "created" : "updated";
                await this.recordLink({
                    doctype: "Sales Order",
                    erpnext_name: soName,
                    medusa_entity: "order",
                    medusa_id: String(order.id),
                    mapping_id: mapping.id,
                    state: "active",
                });
            }
        }
        if (soName && plan.action !== "none") {
            const submitted = await (0, order_accounting_1.submitDocument)(client, "Sales Order", soName);
            if (submitted.ok === false) {
                return { ok: false, error: `Sales Order ${soName} not submitted: ${submitted.error}`, httpStatus: submitted.httpStatus };
            }
            if (submitted.state === "cancelled") {
                notes.push(`${soName} is cancelled; nothing booked`);
                return { ok: true, status: "success", action, name: soName, notes };
            }
            if (submitted.state === "submitted") {
                notes.push(`${soName} submitted`);
                action = action === "unchanged" ? "submitted" : `${action},submitted`;
            }
        }
        let siName = null;
        if (wantSI && fullyPaid) {
            const invoiced = await this.remoteNameFor("invoice", String(order.id), "Sales Invoice");
            let draftInvoice = null;
            let invoiceDone = false;
            if (invoiced?.erpnext_name) {
                const state = await client.get(`/api/resource/Sales%20Invoice/${encodeURIComponent(invoiced.erpnext_name)}`);
                if (state.ok === true && Number(state.data?.docstatus) === 0)
                    draftInvoice = invoiced.erpnext_name;
                else if (!(state.ok === false && state.status === 404)) {
                    notes.push(`invoice ${invoiced.erpnext_name} already exists`);
                    invoiceDone = true;
                    siName = invoiced.erpnext_name;
                }
            }
            if (!invoiceDone) {
                const made = await this.makeSalesInvoice(ctx, soName, customer.name, addresses, lineCodes, defaults, timezone, taxFields, draftInvoice);
                if (made.ok === false && plan.action === "record-payments") {
                    return { ok: false, error: `invoice not raised: ${made.error}` };
                }
                if (made.ok === false)
                    notes.push(`invoice not raised: ${made.error}`);
                else if (draftInvoice) {
                    notes.push(`draft invoice ${made.name} refreshed`);
                    action = action === "unchanged" ? "invoiced" : `${action},invoiced`;
                }
                else {
                    notes.push(`invoice ${made.name} raised as a draft`);
                    action = action === "unchanged" ? "invoiced" : `${action},invoiced`;
                }
                if (made.ok)
                    siName = made.name;
            }
        }
        if (plan.action === "record-payments") {
            if (!siName) {
                notes.push("payments not booked: this store's orders do not become Sales Invoices");
            }
            else {
                const submitted = await (0, order_accounting_1.submitDocument)(client, "Sales Invoice", siName);
                if (submitted.ok === false) {
                    return { ok: false, error: `Sales Invoice ${siName} not submitted: ${submitted.error}`, httpStatus: submitted.httpStatus };
                }
                if (submitted.state === "cancelled") {
                    notes.push(`invoice ${siName} is cancelled; nothing booked`);
                    return { ok: true, status: "success", action, name: soName ?? undefined, notes };
                }
                if (submitted.state === "submitted")
                    notes.push(`invoice ${siName} submitted`);
                await this.markInvoiceSubmitted(siName);
                for (const payment of plan.payments) {
                    const booked = await this.bookPayment(ctx, siName, payment, timezone);
                    if (booked.ok === false)
                        return booked;
                    notes.push(...booked.notes);
                    if (booked.created)
                        action = `${action},paid`;
                }
            }
        }
        return { ok: true, status: "success", action: action.replace(/^unchanged,/, ""), name: soName ?? undefined, notes };
    }
    /**
     * One captured payment as a submitted Payment Entry against the
     * invoice, made by ERPNext's own `get_payment_entry` so its rounding
     * and outstanding amount decide the figures. The link table keeps the
     * payment → Payment Entry pair, so a replay submits a draft it left
     * behind or finds the entry already done; an entry made by an attempt
     * that died before recording its link is found by its reference.
     */
    async bookPayment(ctx, siName, payment, timezone) {
        const { client, mapping } = ctx;
        const label = `payment ${payment.id}`;
        const reference = String(payment.reference || payment.id);
        const notes = [];
        let name = null;
        let created = false;
        const link = await this.remoteNameFor(order_accounting_1.PAYMENT_ENTITY, String(payment.id), order_accounting_1.PAYMENT_ENTRY_DOCTYPE);
        if (link?.erpnext_name) {
            const state = await client.get(`/api/resource/Payment%20Entry/${encodeURIComponent(link.erpnext_name)}`);
            if (state.ok === false && state.status !== 404) {
                return { ok: false, error: `Payment Entry ${link.erpnext_name}: ${state.error}`, httpStatus: state.status || undefined };
            }
            if (state.ok === false)
                await this.deleteErpnextLinks([link.id]);
            else if (Number(state.data?.docstatus) === 2) {
                return { ok: true, created: false, notes: [`Payment Entry ${link.erpnext_name} for ${label} is cancelled; not made again`] };
            }
            else
                name = link.erpnext_name;
        }
        if (!name) {
            name = await (0, order_accounting_1.findPaymentEntry)(client, siName, reference);
            if (!name) {
                const made = await (0, order_accounting_1.createPaymentEntry)(client, {
                    invoice: siName,
                    captured: Number(payment.amount),
                    mode: payment.mode,
                    reference,
                    referenceDate: (0, mapping_engine_2.formatInZone)(new Date(payment.captured_at ?? Date.now()), timezone, false),
                });
                if (made.ok === false)
                    return { ok: false, error: `Payment Entry for ${label}: ${made.error}`, httpStatus: made.httpStatus };
                if ("skip" in made)
                    return { ok: true, created: false, notes: [`no Payment Entry for ${label}: ${made.skip}`] };
                name = made.name;
                created = true;
                if (made.note)
                    notes.push(`${name}: ${made.note}`);
            }
            await this.recordLink({
                doctype: order_accounting_1.PAYMENT_ENTRY_DOCTYPE,
                erpnext_name: name,
                medusa_entity: order_accounting_1.PAYMENT_ENTITY,
                medusa_id: String(payment.id),
                mapping_id: mapping.id,
                state: "active",
            });
        }
        const submitted = await (0, order_accounting_1.submitDocument)(client, order_accounting_1.PAYMENT_ENTRY_DOCTYPE, name);
        if (submitted.ok === false) {
            return { ok: false, error: `Payment Entry ${name} not submitted: ${submitted.error}`, httpStatus: submitted.httpStatus };
        }
        notes.push(submitted.state === "submitted"
            ? `Payment Entry ${name} submitted for ${label}`
            : `Payment Entry ${name} for ${label} already ${submitted.state === "cancelled" ? "cancelled" : "submitted"}`);
        return { ok: true, created, notes };
    }
    /**
     * The customer's copy of an invoice this store just submitted. With
     * ERPNext invoices on, the PDF is fetched first; a failed fetch leaves
     * the row a draft so the hourly refresh fetches it again.
     */
    async markInvoiceSubmitted(number) {
        try {
            const [row] = await this.listErpnextInvoices({ number }, { take: 1 });
            if (!row || row.status === "submitted")
                return;
            if ((0, invoice_number_1.receivesErpInvoices)((await this.findSettingsRow())) && !(await this.fetchInvoicePdf(row.id)).ok)
                return;
            await this.updateErpnextInvoices([{ id: row.id, status: "submitted" }]);
        }
        catch (err) {
            console.warn(`[erpnext] invoice row for ${number} not updated:`, describeError(err));
        }
    }
    /** A draft Sales Invoice, new or refreshed: from the Sales Order when
     *  it is submitted, else built like one. Recorded in `erpnext_invoice`
     *  for the storefront. */
    async makeSalesInvoice(ctx, soName, customerName, addresses, lineCodes, defaults, timezone, taxFields, existing = null) {
        const { client, record: order } = ctx;
        let doc = null;
        // ERPNext maps an invoice from a Sales Order only once the order is
        // submitted; a draft order is referenced line by line instead.
        let soDoc = null;
        if (soName) {
            const state = await client.get(`/api/resource/Sales%20Order/${encodeURIComponent(soName)}`);
            if (state.ok === true)
                soDoc = state.data;
        }
        if (soName && Number(soDoc?.docstatus) === 1) {
            const mapped = await client.post("/api/method/erpnext.selling.doctype.sales_order.sales_order.make_sales_invoice", {
                source_name: soName,
            });
            if (mapped.ok === false)
                return { ok: false, error: mapped.error };
            doc = { ...(mapped.data ?? {}) };
            for (const k of ["name", "__islocal", "__unsaved", "docstatus", "creation", "modified", "owner", "modified_by"])
                delete doc[k];
            for (const it of Array.isArray(doc.items) ? doc.items : []) {
                for (const k of ["name", "__islocal", "__unsaved", "parent", "docstatus"])
                    delete it[k];
            }
            for (const t of Array.isArray(doc.taxes) ? doc.taxes : []) {
                for (const k of ["name", "__islocal", "__unsaved", "parent", "docstatus"])
                    delete t[k];
            }
            doc.posting_date = (0, mapping_engine_2.formatInZone)(new Date(), timezone, false);
            doc.set_posting_time = 1;
        }
        else {
            const has = await this.hasFieldFn("Sales Invoice");
            const build = (0, push_rest_1.buildSalesInvoiceDoc)({
                order,
                customerName,
                itemCodeFor: (li) => lineCodes.get(String(li?.id ?? li?.title)) ?? null,
                addresses,
                defaults,
                has,
                timezone,
                soName: soDoc ? soName : null,
                soItems: Array.isArray(soDoc?.items) ? soDoc.items : null,
                payload: ctx.payload,
            });
            if (build.ok === false)
                return { ok: false, error: build.reason };
            doc = await this.completeSalesDoc(client, { ...build.doc, ...taxFields });
        }
        const written = await this.writeRemote(client, "Sales Invoice", existing, doc);
        if (written.ok === false)
            return { ok: false, error: written.error };
        await this.recordLink({
            doctype: "Sales Invoice",
            erpnext_name: written.name,
            medusa_entity: "invoice",
            medusa_id: String(order.id),
            mapping_id: ctx.mapping.id,
            state: "active",
        });
        try {
            const [known] = await this.listErpnextInvoices({ number: written.name }, { take: 1 });
            const facts = {
                order_id: String(order.id),
                customer_id: order?.customer_id ? String(order.customer_id) : null,
                number: written.name,
                source: "erpnext",
                invoice_date: doc.posting_date,
                total: Number(order?.total) || null,
                currency: order?.currency_code ? String(order.currency_code).toUpperCase() : null,
                status: "draft",
            };
            // The customer's copy is fetched once ERPNext submits the invoice
            // (its on_submit webhook, or the hourly reconcile); a draft can
            // still change, so it is never offered.
            if (known)
                await this.updateErpnextInvoices([{ id: known.id, ...facts }]);
            else
                await this.createErpnextInvoices([facts]);
        }
        catch (err) {
            console.warn("[erpnext] invoice row not recorded:", describeError(err));
        }
        return { ok: true, name: written.name };
    }
    // ── Stock and prices, ERPNext → Medusa (Phase 3) ─────────────────
    /**
     * A Stock Ledger Entry, a Sales Order submit/cancel or an Item Price
     * arriving from ERPNext (see stock-prices.ts for the rules).
     */
    async applyStockPriceEvent(body, scope) {
        const cfg = await this.getActiveConfig();
        const results = [];
        if (stock_prices_1.STOCK_DOCTYPES.has(body.doctype)) {
            if (!cfg.sync_stock) {
                results.push({ ok: true, action: "skipped", reason: "stock sync is off in Settings" });
            }
            else {
                const pairs = (0, stock_prices_1.stockPairsOf)(body, cfg.erpnext_warehouse);
                if (!pairs.length) {
                    results.push({
                        ok: true,
                        action: "skipped",
                        reason: `nothing at warehouse ${cfg.erpnext_warehouse ?? "(not set)"}`,
                    });
                }
                for (const pair of pairs) {
                    const link = await this.findLink("Item", pair.item_code, "product");
                    if (!(0, stock_prices_1.stockAllowedByLink)(link)) {
                        results.push({ ok: true, action: "skipped", reason: `${pair.item_code} does not move ERPNext → Medusa` });
                        continue;
                    }
                    results.push(await this.applyStockLevel(scope, pair.item_code));
                }
                const dn = pairs.length ? (0, delivery_1.deliveryNoteOf)(body.doc) : null;
                if (dn)
                    results.push(...(await this.applyDeliveryNote(scope, dn)));
            }
        }
        if (body.doctype === stock_prices_1.ITEM_PRICE_DOCTYPE) {
            if (!cfg.sync_prices) {
                results.push({ ok: true, action: "skipped", reason: "price sync is off in Settings" });
            }
            else {
                const rest = await this.restClient();
                const priceList = rest ? (await this.pushDefaults(rest.client)).priceList : null;
                const plan = (0, stock_prices_1.planItemPrice)({
                    event: body.event,
                    doc: body.doc,
                    priceList,
                    today: (0, mapping_engine_2.formatInZone)(new Date(), await this.siteTimezone(), false),
                });
                if (plan.action === "skip")
                    results.push({ ok: true, action: "skipped", reason: plan.reason });
                else if (!(0, stock_prices_1.stockAllowedByLink)(await this.findLink("Item", plan.item_code, "product"))) {
                    results.push({ ok: true, action: "skipped", reason: `${plan.item_code} does not move ERPNext → Medusa` });
                }
                else
                    results.push(await this.applyVariantPrice(scope, plan));
            }
        }
        return { via: "frappe", event: body.event, results };
    }
    /**
     * The variant an Item's stock and price belong to: through the link
     * (the product's variant with the Item code as SKU, else its only
     * variant — a product linked by hand keeps its own SKU), else any
     * variant carrying the code as its SKU (a pulled product).
     */
    async variantForItem(scope, itemCode) {
        const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        const fields = ["id", "sku", "title", "product_id", "manage_inventory", "inventory_items.inventory_item_id", "price_set.id"];
        const link = await this.findLink("Item", itemCode, "product");
        if (link?.medusa_id) {
            const { data } = await query.graph({ entity: "variant", fields, filters: { product_id: link.medusa_id } });
            const variants = Array.isArray(data) ? data : [];
            const bySku = variants.find((v) => v.sku === itemCode);
            if (bySku)
                return bySku;
            if (variants.length === 1)
                return variants[0];
        }
        const { data } = await query.graph({ entity: "variant", fields, filters: { sku: itemCode } });
        return data?.[0] ?? null;
    }
    /** Read the Bin at the store's warehouse and write the sellable level. */
    async applyStockLevel(scope, itemCode) {
        const cfg = await this.getActiveConfig();
        if (!cfg.erpnext_warehouse || !cfg.medusa_stock_location_id) {
            return { ok: true, action: "skipped", reason: "warehouse or stock location not set in Settings" };
        }
        const rest = await this.restClient();
        if (!rest)
            return { ok: true, action: "skipped", reason: "ERPNext not configured" };
        const bins = await rest.client.get("/api/resource/Bin", {
            filters: JSON.stringify([
                ["item_code", "=", itemCode],
                ["warehouse", "=", cfg.erpnext_warehouse],
            ]),
            fields: JSON.stringify(["actual_qty", "reserved_qty"]),
        });
        if (bins.ok === false)
            return { ok: false, error: `Bin ${itemCode}: ${bins.error}` };
        const item = await rest.client.get("/api/method/frappe.client.get_value", {
            doctype: "Item",
            filters: itemCode,
            fieldname: "safety_stock",
        });
        const safety = (0, stock_prices_1.safetyFor)(item.ok === true ? item.data?.safety_stock : 0, cfg.erpnext_safety_stock);
        const held = await this.storeHolds(scope, rest.client, [itemCode]);
        const qty = (0, stock_prices_1.sellableQty)(Array.isArray(bins.data) ? bins.data[0] : null, safety, held.get(itemCode) ?? 0);
        return this.writeStockLevel(scope, itemCode, cfg.medusa_stock_location_id, qty);
    }
    /**
     * What Medusa still reserves, at the store's location, for store
     * orders whose Sales Order ERPNext has submitted, by Item code. ERPNext
     * reserves those units as well once the order is submitted, so the
     * level adds them back (see `sellableQty`). A read that fails counts as
     * nothing held: the level is then short, never oversold.
     */
    async storeHolds(scope, client, itemCodes) {
        const out = new Map();
        const cfg = await this.getActiveConfig();
        if (!itemCodes.length || !cfg.erpnext_warehouse || !cfg.medusa_stock_location_id)
            return out;
        try {
            // Submitted and still to deliver: a Closed order no longer
            // reserves in ERPNext, and a delivered one has had its Medusa
            // reservation consumed by the Delivery Note's fulfilment.
            const rows = await client.get("/api/resource/Sales%20Order", {
                fields: JSON.stringify(["name"]),
                filters: JSON.stringify([
                    ["docstatus", "=", 1],
                    ["status", "not in", ["Closed", "Completed"]],
                    ["per_delivered", "<", 100],
                    ["Sales Order Item", "item_code", "in", itemCodes],
                    ["Sales Order Item", "warehouse", "=", cfg.erpnext_warehouse],
                ]),
                limit_page_length: "0",
            });
            if (rows.ok !== true || !Array.isArray(rows.data) || !rows.data.length)
                return out;
            const soNames = Array.from(new Set(rows.data.map((r) => String(r.name))));
            const links = await this.listErpnextLinks({ doctype: "Sales Order", medusa_entity: "order", erpnext_name: soNames }, { take: soNames.length });
            const orderIds = Array.from(new Set(links.map((l) => String(l.medusa_id))));
            if (!orderIds.length)
                return out;
            const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
            const { data: orders } = await query.graph({ entity: "order", fields: ["id", "items.id"], filters: { id: orderIds } });
            const lineIds = [];
            for (const o of orders ?? [])
                for (const li of o?.items ?? [])
                    if (li?.id)
                        lineIds.push(String(li.id));
            if (!lineIds.length)
                return out;
            const inventory = scope.resolve(utils_1.Modules.INVENTORY);
            const reservations = await inventory.listReservationItems({ line_item_id: lineIds, location_id: cfg.medusa_stock_location_id }, { take: 5000, select: ["inventory_item_id", "quantity"] });
            const byInventoryItem = new Map();
            for (const r of reservations) {
                byInventoryItem.set(String(r.inventory_item_id), (byInventoryItem.get(String(r.inventory_item_id)) ?? 0) + Number(r.quantity || 0));
            }
            for (const code of itemCodes) {
                const variant = await this.variantForItem(scope, code);
                const inventoryItemId = variant?.inventory_items?.[0]?.inventory_item_id;
                const held = inventoryItemId ? byInventoryItem.get(String(inventoryItemId)) ?? 0 : 0;
                if (held)
                    out.set(code, held);
            }
        }
        catch (err) {
            console.warn("[erpnext] store reservations not read:", describeError(err));
        }
        return out;
    }
    /**
     * A Delivery Note's ledger entry: mark the store order's lines it
     * delivers as fulfilled and shipped in Medusa (or cancel that
     * fulfilment when the note is cancelled), so nothing is entered twice.
     * The note's entries arrive together, one per line; one runs at a time
     * and the link table keeps a note from being applied twice.
     */
    async applyDeliveryNote(scope, dn) {
        const previous = _deliveryLocks.get(dn.name) ?? Promise.resolve();
        const run = previous.catch(() => undefined).then(() => this.applyDeliveryNoteNow(scope, dn));
        _deliveryLocks.set(dn.name, run);
        try {
            return await run;
        }
        finally {
            if (_deliveryLocks.get(dn.name) === run)
                _deliveryLocks.delete(dn.name);
        }
    }
    /** Mark a Delivery Note's fulfilment shipped, with its LR number as
     *  tracking; nothing when it already is. */
    async shipFulfillment(scope, orderId, fulfillmentId, note) {
        const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        const { data } = await query.graph({
            entity: "fulfillment",
            fields: ["id", "shipped_at", "items.line_item_id", "items.quantity"],
            filters: { id: fulfillmentId },
        });
        const f = data?.[0];
        if (!f || f.shipped_at)
            return null;
        const tracking = String(note?.lr_no ?? "").trim();
        try {
            await (0, core_flows_1.createOrderShipmentWorkflow)(scope).run({
                input: {
                    order_id: orderId,
                    fulfillment_id: fulfillmentId,
                    items: (f.items ?? []).map((it) => ({ id: it.line_item_id, quantity: Number(it.quantity) })),
                    labels: tracking ? [{ tracking_number: tracking, tracking_url: "", label_url: "" }] : [],
                },
            });
            return { entity: "fulfillment", id: fulfillmentId, ok: true, action: "shipped", detail: `${note?.name ?? ""} → order ${orderId}` };
        }
        catch (err) {
            return { entity: "fulfillment", id: fulfillmentId, ok: false, error: `${note?.name ?? ""}: fulfilment ${fulfillmentId} not marked shipped: ${describeError(err)}` };
        }
    }
    async applyDeliveryNoteNow(scope, dn) {
        const cfg = await this.getActiveConfig();
        const rest = await this.restClient();
        if (!rest || !cfg.medusa_stock_location_id)
            return [{ ok: true, action: "skipped", reason: "delivery: ERPNext or stock location not configured" }];
        const res = await rest.client.get(`/api/resource/Delivery%20Note/${encodeURIComponent(dn.name)}`);
        if (res.ok !== true || !res.data)
            return [{ ok: false, error: `Delivery Note ${dn.name}: ${res.ok === false ? res.error : "not readable"}` }];
        const note = res.data;
        const cancelled = dn.cancelled || Number(note.docstatus) === 2;
        const results = [];
        for (const so of (0, delivery_1.salesOrdersOf)(note.items)) {
            const key = `${dn.name}|${so}`;
            const done = await this.findLink(delivery_1.DELIVERY_NOTE_DOCTYPE, key, "fulfillment");
            if (cancelled) {
                if (!done || done.state !== "active")
                    continue;
                const [orderId, fulfillmentId] = String(done.medusa_id).split(":");
                // Medusa cancels a fulfilment only before it ships, and a
                // Delivery Note's fulfilment is shipped at once. Taking the
                // goods back is a return in Medusa, which a person decides;
                // the failed row says so. The link stays as it is, so every
                // redelivery and retry of this entry fails the same way
                // instead of passing once the state has moved.
                results.push({
                    entity: "fulfillment",
                    id: fulfillmentId,
                    ok: false,
                    error: `${dn.name} was cancelled in ERPNext; order ${orderId}'s fulfilment ${fulfillmentId} is shipped in Medusa, so record a return there (or cancel the order)`,
                });
                continue;
            }
            if (Number(note.docstatus) !== 1)
                continue;
            if (done?.state === "active") {
                // Fulfilled on an earlier delivery; ship it if that step failed then.
                const [orderId, fulfillmentId] = String(done.medusa_id).split(":");
                const shipped = await this.shipFulfillment(scope, orderId, fulfillmentId, note);
                if (shipped)
                    results.push(shipped);
                continue;
            }
            const orderLink = await this.findLink("Sales Order", so, "order");
            if (!orderLink?.medusa_id)
                continue;
            const orderId = String(orderLink.medusa_id);
            const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
            const { data } = await query.graph({
                entity: "order",
                fields: ["id", "items.id", "items.detail.quantity", "items.detail.fulfilled_quantity", "items.variant.sku", "items.variant.product.id", "items.product_id"],
                filters: { id: orderId },
            });
            const order = data?.[0];
            if (!order)
                continue;
            const codes = new Map();
            const lines = [];
            for (const li of order.items ?? []) {
                lines.push({
                    id: String(li.id),
                    code: await this.itemCodeForLine(rest.client, li, codes),
                    quantity: Number(li?.detail?.quantity ?? 0),
                    fulfilled: Number(li?.detail?.fulfilled_quantity ?? 0),
                });
            }
            const plan = (0, delivery_1.planDeliveryFulfilment)({ dnItems: note.items, salesOrder: so, lines });
            if (!plan.items.length) {
                results.push({ ok: true, action: "skipped", reason: `${dn.name}: nothing left to fulfil on order ${orderId}` });
                continue;
            }
            try {
                const { result: fulfillment } = await (0, core_flows_1.createOrderFulfillmentWorkflow)(scope).run({
                    input: {
                        order_id: orderId,
                        items: plan.items,
                        location_id: cfg.medusa_stock_location_id,
                        metadata: { erpnext_delivery_note: dn.name },
                    },
                });
                const fulfillmentId = String(fulfillment?.id);
                // Recorded before shipping, so a retry ships this fulfilment
                // instead of making a second one.
                await this.recordLink({ doctype: delivery_1.DELIVERY_NOTE_DOCTYPE, erpnext_name: key, medusa_entity: "fulfillment", medusa_id: `${orderId}:${fulfillmentId}`, state: "active" });
                const shipped = await this.shipFulfillment(scope, orderId, fulfillmentId, note);
                if (shipped?.ok === false)
                    results.push(shipped);
                else {
                    results.push({
                        entity: "fulfillment",
                        id: fulfillmentId,
                        ok: true,
                        action: "shipped",
                        detail: `${dn.name} → order ${orderId}${plan.unmatched.length ? `; not on the order: ${plan.unmatched.join(", ")}` : ""}`,
                    });
                }
            }
            catch (err) {
                results.push({ ok: false, error: `${dn.name} → order ${orderId}: ${describeError(err)}` });
            }
            // Medusa moved its own level on fulfilment; ERPNext's is the one to keep.
            for (const code of new Set(lines.map((l) => l.code).filter(Boolean))) {
                await this.applyStockLevel(scope, code);
            }
        }
        return results;
    }
    /** Set the stocked quantity of the variant with this SKU at the location. */
    async writeStockLevel(scope, sku, locationId, qty) {
        const variant = await this.variantForItem(scope, sku);
        if (!variant)
            return { ok: true, action: "skipped", reason: `no variant for Item ${sku}` };
        const inventory = scope.resolve(utils_1.Modules.INVENTORY);
        let inventoryItemId = variant.inventory_items?.[0]?.inventory_item_id ?? null;
        if (!inventoryItemId) {
            // A product the pull created has a variant but no inventory
            // item behind it (the module upsert does not make one, the
            // way the product workflow would). Make one and tie it to the
            // variant, so the level has somewhere to live.
            const [byItemSku] = await inventory.listInventoryItems({ sku: variant.sku ?? sku }, { take: 1 });
            inventoryItemId = byItemSku?.id ?? null;
            if (!inventoryItemId) {
                const created = await inventory.createInventoryItems({ sku: variant.sku ?? sku, title: variant.title ?? sku });
                inventoryItemId = created?.id ?? null;
            }
            if (!inventoryItemId)
                return { ok: true, action: "skipped", reason: `variant ${sku} has no inventory item` };
            const link = scope.resolve(utils_1.ContainerRegistrationKeys.LINK);
            await link.create({
                [utils_1.Modules.PRODUCT]: { variant_id: variant.id },
                [utils_1.Modules.INVENTORY]: { inventory_item_id: inventoryItemId },
            });
        }
        const [level] = await inventory.listInventoryLevels({ inventory_item_id: inventoryItemId, location_id: locationId }, { take: 1 });
        if (level) {
            if (Number(level.stocked_quantity) === qty) {
                return { entity: "inventory_level", id: variant.id, ok: true, action: "unchanged", detail: `${sku}: ${qty}` };
            }
            await inventory.updateInventoryLevels([{ inventory_item_id: inventoryItemId, location_id: locationId, stocked_quantity: qty }]);
            return { entity: "inventory_level", id: variant.id, ok: true, action: "updated", detail: `${sku}: ${qty}` };
        }
        await inventory.createInventoryLevels([{ inventory_item_id: inventoryItemId, location_id: locationId, stocked_quantity: qty }]);
        return { entity: "inventory_level", id: variant.id, ok: true, action: "created", detail: `${sku}: ${qty}` };
    }
    /** Set or remove the variant's base price in one currency. */
    async applyVariantPrice(scope, plan) {
        const variant = await this.variantForItem(scope, plan.item_code);
        if (!variant)
            return { ok: true, action: "skipped", reason: `no variant for Item ${plan.item_code}` };
        const pricing = scope.resolve(utils_1.Modules.PRICING);
        let priceSetId = variant.price_set?.id ?? null;
        if (!priceSetId) {
            if (plan.action === "remove")
                return { ok: true, action: "skipped", reason: `variant ${plan.item_code} has no prices` };
            const created = await pricing.createPriceSets({ prices: [] });
            priceSetId = created.id;
            const link = scope.resolve(utils_1.ContainerRegistrationKeys.LINK);
            await link.create({ [utils_1.Modules.PRODUCT]: { variant_id: variant.id }, [utils_1.Modules.PRICING]: { price_set_id: priceSetId } });
        }
        // The base price: this currency, no price list, no rules.
        const prices = await pricing.listPrices({ price_set_id: [priceSetId], currency_code: plan.currency }, { take: 50 });
        const base = prices.find((p) => !p.price_list_id && !(p.rules_count > 0));
        if (plan.action === "remove") {
            if (!base)
                return { entity: "variant", id: variant.id, ok: true, action: "unchanged", detail: `${plan.item_code}: no ${plan.currency} price` };
            await pricing.softDeletePrices([base.id]);
            return { entity: "variant", id: variant.id, ok: true, action: "removed", detail: `${plan.item_code}: ${plan.currency} price` };
        }
        if (base) {
            if (Number(base.amount) === plan.amount) {
                return { entity: "variant", id: variant.id, ok: true, action: "unchanged", detail: `${plan.item_code}: ${plan.amount} ${plan.currency}` };
            }
            await pricing.updatePrices([{ id: base.id, amount: plan.amount }]);
            return { entity: "variant", id: variant.id, ok: true, action: "updated", detail: `${plan.item_code}: ${plan.amount} ${plan.currency}` };
        }
        await pricing.addPrices({ priceSetId, prices: [{ amount: plan.amount, currency_code: plan.currency }] });
        return { entity: "variant", id: variant.id, ok: true, action: "created", detail: `${plan.item_code}: ${plan.amount} ${plan.currency}` };
    }
    /**
     * Stock and prices for a batch of Items in a few reads: the Bins at
     * the store's warehouse, the Items' safety stock, and the selling
     * prices on the store's list. An Item with no Bin has never been
     * stocked there and is written as 0; an Item with no price on the
     * list keeps whatever price the variant has.
     */
    async refreshStockAndPrices(scope, itemCodes) {
        const cfg = await this.getActiveConfig();
        const codes = Array.from(new Set(itemCodes.filter(Boolean)));
        if (!codes.length || (!cfg.sync_stock && !cfg.sync_prices))
            return { skipped: "off", stock: 0, prices: 0, failed: 0, notes: [] };
        const rest = await this.restClient();
        if (!rest)
            return { skipped: "not-configured", stock: 0, prices: 0, failed: 0, notes: [] };
        let stock = 0;
        let prices = 0;
        let failed = 0;
        const notes = [];
        const note = (r, what) => {
            if (r?.ok === false) {
                failed += 1;
                if (notes.length < 25)
                    notes.push(`${what}: ${r.error}`);
            }
            else if (r?.action === "skipped" && notes.length < 25)
                notes.push(`${what}: ${r.reason}`);
        };
        if (cfg.sync_stock && cfg.erpnext_warehouse && cfg.medusa_stock_location_id) {
            const bins = await rest.client.get("/api/resource/Bin", {
                filters: JSON.stringify([
                    ["warehouse", "=", cfg.erpnext_warehouse],
                    ["item_code", "in", codes],
                ]),
                fields: JSON.stringify(["item_code", "actual_qty", "reserved_qty"]),
                limit_page_length: String(codes.length),
            });
            const safeties = await rest.client.get("/api/resource/Item", {
                filters: JSON.stringify([["name", "in", codes]]),
                fields: JSON.stringify(["name", "safety_stock"]),
                limit_page_length: String(codes.length),
            });
            if (bins.ok === false)
                failed += 1;
            else {
                const binByCode = new Map();
                for (const b of Array.isArray(bins.data) ? bins.data : [])
                    binByCode.set(String(b.item_code), b);
                const safetyByCode = new Map();
                for (const i of safeties.ok === true && Array.isArray(safeties.data) ? safeties.data : []) {
                    safetyByCode.set(String(i.name), i.safety_stock);
                }
                const held = await this.storeHolds(scope, rest.client, codes);
                for (const code of codes) {
                    const qty = (0, stock_prices_1.sellableQty)(binByCode.get(code) ?? null, (0, stock_prices_1.safetyFor)(safetyByCode.get(code), cfg.erpnext_safety_stock), held.get(code) ?? 0);
                    const r = await this.writeStockLevel(scope, code, cfg.medusa_stock_location_id, qty);
                    note(r, `stock ${code}`);
                    if (r?.ok && (r.action === "created" || r.action === "updated"))
                        stock += 1;
                }
            }
        }
        if (cfg.sync_prices) {
            const priceList = (await this.pushDefaults(rest.client)).priceList;
            if (priceList) {
                const rows = await rest.client.get("/api/resource/Item%20Price", {
                    filters: JSON.stringify([
                        ["price_list", "=", priceList],
                        ["item_code", "in", codes],
                        ["selling", "=", 1],
                    ]),
                    fields: JSON.stringify([
                        "item_code",
                        "price_list",
                        "currency",
                        "price_list_rate",
                        "selling",
                        "customer",
                        "packing_unit",
                        "valid_from",
                        "valid_upto",
                    ]),
                    limit_page_length: String(codes.length * 4),
                });
                if (rows.ok === false)
                    failed += 1;
                else {
                    const today = (0, mapping_engine_2.formatInZone)(new Date(), await this.siteTimezone(), false);
                    for (const doc of Array.isArray(rows.data) ? rows.data : []) {
                        const plan = (0, stock_prices_1.planItemPrice)({ event: "on_update", doc, priceList, today });
                        if (plan.action === "skip")
                            continue;
                        const r = await this.applyVariantPrice(scope, plan);
                        note(r, `price ${plan.item_code}`);
                        if (r?.ok && (r.action === "created" || r.action === "updated" || r.action === "removed"))
                            prices += 1;
                    }
                }
            }
        }
        return { stock, prices, failed, notes };
    }
    /** The hourly safety net: every linked Item, 200 at a time. */
    async reconcileStockAndPrices(scope) {
        const cfg = await this.getActiveConfig();
        if (!cfg.enable_sync || (!cfg.sync_stock && !cfg.sync_prices))
            return { skipped: "off", items: 0, stock: 0, prices: 0, failed: 0, notes: [] };
        let items = 0;
        let stock = 0;
        let prices = 0;
        let failed = 0;
        const notes = [];
        for (let offset = 0;; offset += 200) {
            const links = await this.listErpnextLinks({ medusa_entity: "product", state: "active" }, { take: 200, skip: offset, order: { erpnext_name: "ASC" } });
            if (!links.length)
                break;
            const out = await this.refreshStockAndPrices(scope, links.filter((l) => (0, stock_prices_1.stockAllowedByLink)(l)).map((l) => String(l.erpnext_name)));
            items += links.length;
            stock += out.stock;
            prices += out.prices;
            failed += out.failed;
            for (const n of out.notes)
                if (notes.length < 25)
                    notes.push(n);
            if (links.length < 200)
                break;
        }
        return { items, stock, prices, failed, notes };
    }
    /**
     * A delete or cancel in Medusa. Nothing is ever deleted in ERPNext on
     * Medusa's say-so: a Customer or Item is disabled, a draft Sales Order
     * or Invoice is deleted (it was ours and never submitted), a submitted
     * one is cancelled.
     */
    async pushRemoval(ctx) {
        const { client, mapping, record } = ctx;
        const doctype = String(mapping.doctype);
        if (record?.id == null)
            return { ok: true, status: "skipped", reason: "no record id on the event" };
        if (mapping.medusa_entity === "order")
            return this.cancelOrderDocuments(ctx);
        const has = await this.hasFieldFn(doctype);
        const link = await this.remoteNameFor(mapping.medusa_entity, String(record.id), doctype);
        const existing = link?.erpnext_name ?? (await this.lookupRemoteByKey(client, doctype, ctx.keyField, ctx.keyValue, has));
        if (!existing)
            return { ok: true, status: "skipped", reason: "nothing in ERPNext to disable" };
        if (!has("disabled"))
            return { ok: true, status: "skipped", reason: `${doctype} has no disabled field; left as is` };
        const written = await this.writeRemote(client, doctype, existing, { disabled: 1 });
        if (written.ok === false)
            return written;
        return { ok: true, status: "success", action: "disabled", name: existing };
    }
    /**
     * An order's documents unwound: its Payment Entries, then its invoice,
     * then the order. A draft is deleted (it was ours and never
     * submitted), a submitted document cancelled, a cancelled one left
     * alone. A step ERPNext refuses fails the push, and nothing after it
     * is tried, so the retry picks up where it stopped.
     *
     * A paid order cancelled before ERPNext had all of it (its placement
     * or capture failed, or was still queued) is booked first, so ERPNext
     * ends with cancelled documents rather than no trace of the sale.
     */
    async cancelOrderDocuments(ctx) {
        const { client, record: order } = ctx;
        const orderId = String(order.id);
        const notes = [];
        const settings = await this.findSettingsRow();
        const payments = Array.isArray(order?.payments) ? order.payments : [];
        const paymentIds = payments.map((p) => String(p?.id ?? "")).filter(Boolean);
        const booked = paymentIds.length
            ? await this.listErpnextLinks({ doctype: order_accounting_1.PAYMENT_ENTRY_DOCTYPE, medusa_entity: order_accounting_1.PAYMENT_ENTITY, medusa_id: paymentIds }, { take: 50 })
            : [];
        const missing = (0, order_accounting_1.bookBeforeCancel)({
            recordPayments: Boolean(settings?.record_payments),
            payments,
            hasSalesOrder: Boolean((await this.remoteNameFor("order", orderId, "Sales Order"))?.erpnext_name),
            hasInvoice: Boolean((await this.remoteNameFor("invoice", orderId, "Sales Invoice"))?.erpnext_name),
            bookedPaymentIds: booked.map((l) => String(l.medusa_id)),
        });
        if (missing) {
            const made = await this.pushSalesDocument(ctx, { paidInFull: true });
            if (made.ok === false)
                return { ok: false, error: `not cancelled: the paid order could not be booked first: ${made.error}`, httpStatus: made.httpStatus };
            if (made.status === "success")
                notes.push(...(made.notes ?? []));
        }
        for (const { doctype, entity } of order_accounting_1.CANCEL_ORDER) {
            const links = doctype === order_accounting_1.PAYMENT_ENTRY_DOCTYPE
                ? await this.paymentEntryLinks(client, order)
                : [await this.remoteNameFor(entity, orderId, doctype)].filter((l) => l?.erpnext_name);
            const errors = [];
            for (const link of links) {
                const name = String(link.erpnext_name);
                const out = await (0, order_accounting_1.unwindDocument)(client, doctype, name);
                if (out.ok === false) {
                    errors.push(out.error);
                    continue;
                }
                if (out.done === "missing")
                    continue;
                notes.push(`${doctype} ${name} ${out.done === "deleted" ? "deleted (was a draft)" : out.done}`);
                if (out.done === "deleted")
                    await this.deleteErpnextLinks([link.id]);
                if (out.done === "cancelled" && doctype === "Sales Invoice")
                    await this.markInvoiceCancelled(name);
            }
            if (errors.length)
                return { ok: false, error: [...errors, ...notes].join("; ") };
        }
        return { ok: true, status: "success", action: "cancelled", notes };
    }
    /**
     * The Payment Entries this store made for an order: through the link
     * table by the order's payments, and by asking ERPNext which entries
     * pay its invoice. An entry an ERPNext user made is not ours to cancel.
     */
    async paymentEntryLinks(client, order) {
        const found = new Map();
        const keep = (rows) => {
            for (const l of rows ?? [])
                if (l?.erpnext_name)
                    found.set(String(l.id), l);
        };
        const paymentIds = (Array.isArray(order?.payments) ? order.payments : []).map((p) => String(p?.id ?? "")).filter(Boolean);
        if (paymentIds.length) {
            keep(await this.listErpnextLinks({ doctype: order_accounting_1.PAYMENT_ENTRY_DOCTYPE, medusa_entity: order_accounting_1.PAYMENT_ENTITY, medusa_id: paymentIds }, { take: 50 }));
        }
        const invoice = await this.remoteNameFor("invoice", String(order.id), "Sales Invoice");
        if (invoice?.erpnext_name) {
            const res = await client.get("/api/resource/Payment%20Entry", {
                fields: JSON.stringify(["name"]),
                filters: JSON.stringify([["Payment Entry Reference", "reference_name", "=", invoice.erpnext_name]]),
                limit_page_length: "50",
            });
            const names = res.ok === true && Array.isArray(res.data) ? res.data.map((r) => String(r?.name ?? "")).filter(Boolean) : [];
            if (names.length) {
                keep(await this.listErpnextLinks({ doctype: order_accounting_1.PAYMENT_ENTRY_DOCTYPE, medusa_entity: order_accounting_1.PAYMENT_ENTITY, erpnext_name: names }, { take: 50 }));
            }
        }
        return [...found.values()];
    }
    async markInvoiceCancelled(number) {
        try {
            const [row] = await this.listErpnextInvoices({ number }, { take: 1 });
            if (row && row.status !== "cancelled")
                await this.updateErpnextInvoices([{ id: row.id, status: "cancelled" }]);
        }
        catch (err) {
            console.warn(`[erpnext] invoice row for ${number} not updated:`, describeError(err));
        }
    }
    /**
     * A captured payment was refunded. Refunded in full, every payment of
     * the order: its documents are unwound as for a cancellation. Part of
     * the money back is an accounting decision (a Credit Note, a partial
     * return) the store does not guess at; the sync event says so and
     * ERPNext is left as it is.
     */
    async pushOrderRefund(ctx) {
        const settings = await this.findSettingsRow();
        if (!settings?.record_payments)
            return { ok: true, status: "skipped", reason: "payments are not recorded (Settings)" };
        const payments = Array.isArray(ctx.record?.payments) ? ctx.record.payments : [];
        const state = (0, order_accounting_1.refundState)(payments);
        if (state === "none")
            return { ok: true, status: "skipped", reason: "no refund on the order's captured payments" };
        if (state === "partial") {
            const refunded = payments.reduce((sum, p) => sum + (Number(p?.refunded) || 0), 0);
            return {
                ok: true,
                status: "success",
                action: "partial refund noted",
                notes: [`partial refund of ${refunded.toFixed(2)}: ERPNext documents left as they are; book it in ERPNext`],
            };
        }
        return this.cancelOrderDocuments(ctx);
    }
    async markMappingPushOutcome(mapping_id, error) {
        try {
            await this.updateErpnextMappings([
                {
                    id: mapping_id,
                    last_push_run_at: new Date(),
                    last_push_error: error,
                },
            ]);
        }
        catch {
            /* non-critical — mapping table touch failure shouldn't bubble */
        }
    }
    // ─────────────────────────────────────────────────────────────────
    // Pull via mapping
    // ─────────────────────────────────────────────────────────────────
    /**
     * Run one pull tick for a single mapping. Reads rows modified
     * since `last_pull_at` from Frappe, transforms each via the
     * engine, and upserts into Medusa via the entity registry. Caller
     * is the pull cron in `jobs/pull-from-erpnext.ts`.
     */
    async pullFromMapping(args) {
        const mapping = args.mapping;
        const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
        if (!entity) {
            const msg = `entity '${mapping.medusa_entity}' has no registry entry`;
            await this.markMappingPullOutcome(mapping.id, msg);
            return {
                ok: false,
                pulled: 0,
                upserted: 0,
                created: 0,
                updated: 0,
                skipped: 0,
                errors: 0,
                message: msg,
            };
        }
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.erpnext_url || !apiCreds) {
            const msg = "erpnext_url / api credentials not configured";
            await this.markMappingPullOutcome(mapping.id, msg);
            return {
                ok: false,
                pulled: 0,
                upserted: 0,
                created: 0,
                updated: 0,
                skipped: 0,
                errors: 0,
                message: msg,
            };
        }
        // Build filters: time-based watermark + any operator-supplied
        // pull_filter clauses ANDed together.
        const filters = [];
        const since = mapping.last_pull_at ? new Date(mapping.last_pull_at).toISOString() : null;
        const after = (0, pull_watermark_1.modifiedAfter)(mapping.last_pull_at, mapping.last_pull_modified);
        if (after)
            filters.push(["modified", ">", after]);
        if (Array.isArray(mapping.pull_filter)) {
            for (const f of mapping.pull_filter)
                filters.push(f);
        }
        // A selection DocType is pulled through its tick, always: without
        // the field the query fails, which beats a page of unselected rows.
        const underSelection = (0, selection_1.isSyncDoctype)(mapping.doctype, cfg.sync_doctypes);
        const effectiveFilters = (0, selection_1.withSelectionFilter)(filters, mapping.doctype, cfg.sync_doctypes);
        const fields = uniqueFrappeFields(mapping.field_mappings, mapping.key_erpnext_field, ["modified_by", ...(underSelection ? [selection_1.SELECTION_FIELD] : [])]);
        const qs = new URLSearchParams();
        qs.set("limit_page_length", String(mapping.pull_page_size ?? 200));
        qs.set("order_by", "modified asc");
        qs.set("fields", JSON.stringify(fields));
        if (effectiveFilters.length)
            qs.set("filters", JSON.stringify(effectiveFilters));
        let rows = [];
        try {
            const res = await fetch(`${cfg.erpnext_url}/api/resource/${encodeURIComponent(mapping.doctype)}?${qs}`, {
                method: "GET",
                headers: { Authorization: `token ${apiCreds}` },
                signal: AbortSignal.timeout(cfg.request_timeout_ms),
            });
            const text = await res.text().catch(() => "");
            if (!res.ok) {
                const hint = underSelection && res.status < 500 && !text.includes(selection_1.SELECTION_FIELD) === false
                    ? " — the medusa_sync field is missing; run Set up ERPNext"
                    : "";
                const msg = `HTTP ${res.status}: ${text.slice(0, 300)}${hint}`;
                await this.markMappingPullOutcome(mapping.id, msg);
                return {
                    ok: false,
                    pulled: 0,
                    upserted: 0,
                    created: 0,
                    updated: 0,
                    skipped: 0,
                    errors: 0,
                    message: msg,
                };
            }
            const parsed = JSON.parse(text);
            rows = Array.isArray(parsed?.data) ? parsed.data : [];
        }
        catch (err) {
            const msg = describeError(err).slice(0, 300);
            await this.markMappingPullOutcome(mapping.id, msg);
            return {
                ok: false,
                pulled: 0,
                upserted: 0,
                created: 0,
                updated: 0,
                skipped: 0,
                errors: 0,
                message: msg,
            };
        }
        let created = 0;
        let updated = 0;
        let skipped = 0;
        let errors = 0;
        let maxModified = null;
        // A product we drafted when its document was unticked comes back
        // published when the document is ticked again.
        const draftedByName = new Map();
        if (mapping.medusa_entity === "product" && rows.length) {
            try {
                const drafted = await this.listErpnextLinks({
                    doctype: mapping.doctype,
                    medusa_entity: mapping.medusa_entity,
                    erpnext_name: rows.map((r) => String(r?.name ?? "")).filter(Boolean),
                    state: "drafted",
                }, { take: rows.length });
                for (const l of drafted)
                    draftedByName.set(String(l.erpnext_name), l);
            }
            catch {
                /* no republish this tick; the next one will */
            }
        }
        const linksToRecord = [];
        const records = [];
        const note = (r) => {
            if (records.length < PULL_RECORDS_SHOWN)
                records.push(r);
        };
        const transformOptions = await this.transformOptions();
        const apiUser = await this.apiUserEmail();
        const pullClient = (await this.restClient())?.client ?? null;
        for (const row of rows) {
            maxModified = (0, pull_watermark_1.latestModified)(maxModified, row?.modified);
            // A row the API user last wrote is a push of ours; reading it
            // back would only bounce it.
            const recordName = String(row?.name ?? row?.[mapping.key_erpnext_field] ?? "");
            if ((0, push_rest_1.isOwnWrite)(row, apiUser)) {
                skipped += 1;
                note({ name: recordName, action: "skipped", reason: "last saved by this store, so already in step" });
                continue;
            }
            const transform = (0, mapping_engine_1.applyMapping)({
                direction: "pull",
                fields: (0, secondary_doctypes_1.pairsForPull)(mapping.field_mappings, String(mapping.doctype)),
                mappingDirection: mapping.direction,
                source: await this.hydrateSecondaries(pullClient, mapping, row),
                options: transformOptions,
            });
            if (transform.ok === false) {
                skipped += 1;
                note({ name: recordName, action: "skipped", reason: transform.reason });
                continue;
            }
            const keyValue = row?.[mapping.key_erpnext_field] != null
                ? String(row[mapping.key_erpnext_field])
                : null;
            if (!keyValue) {
                skipped += 1;
                note({ name: recordName, action: "skipped", reason: `no ${mapping.key_erpnext_field}` });
                continue;
            }
            const rowName = row?.name != null ? String(row.name) : keyValue;
            const payload = (0, frappe_webhook_1.withRepublish)(transform.payload, draftedByName.has(rowName));
            const outcome = await entity.upsertByKey(args.container, mapping.key_medusa_field, keyValue, payload);
            if (!outcome.ok) {
                errors += 1;
                note({ name: rowName, action: "failed", reason: outcome.error ?? "not written" });
                continue;
            }
            if (outcome.created)
                created += 1;
            else
                updated += 1;
            note({ name: rowName, action: outcome.created ? "created" : "updated", medusa_id: outcome.id });
            if (outcome.id) {
                linksToRecord.push({
                    erpnext_name: rowName,
                    medusa_id: outcome.id,
                    remote_direction: underSelection ? String(row?.[selection_1.SELECTION_FIELD] ?? "") : null,
                });
            }
        }
        for (const link of linksToRecord) {
            await this.recordLink({
                doctype: mapping.doctype,
                erpnext_name: link.erpnext_name,
                medusa_entity: mapping.medusa_entity,
                medusa_id: link.medusa_id,
                mapping_id: mapping.id,
                state: "active",
                ...(link.remote_direction !== null ? { remote_direction: link.remote_direction } : {}),
            });
        }
        // The pulled Items' stock and prices come along, so a product is
        // sellable at the right level and price from its first pull.
        if (linksToRecord.length && mapping.medusa_entity === "product") {
            try {
                await this.refreshStockAndPrices(args.container, linksToRecord.map((l) => l.erpnext_name));
            }
            catch (err) {
                console.warn("[erpnext-pull] stock/price refresh failed:", describeError(err));
            }
            if (mapping.doctype === "Item") {
                try {
                    const gst = await this.refreshProductGst(args.container, linksToRecord.map((l) => l.erpnext_name));
                    if (gst.notes.length)
                        console.warn("[erpnext-pull] GST rate:", gst.notes.join("; "));
                }
                catch (err) {
                    console.warn("[erpnext-pull] GST rate refresh failed:", describeError(err));
                }
            }
        }
        try {
            await this.updateErpnextMappings([
                {
                    id: mapping.id,
                    ...(maxModified ? { last_pull_at: (0, pull_watermark_1.watermarkDate)(maxModified), last_pull_modified: maxModified } : {}),
                    last_pull_run_at: new Date(),
                    last_pull_error: errors ? `${errors} row(s) failed` : null,
                },
            ]);
        }
        catch {
            /* non-critical */
        }
        return {
            ok: errors === 0,
            pulled: rows.length,
            upserted: created + updated,
            created,
            updated,
            skipped,
            errors,
            since,
            records,
        };
    }
    // ─────────────────────────────────────────────────────────────────
    // Frappe core Webhooks (ERPNext → Medusa) and the link table
    // ─────────────────────────────────────────────────────────────────
    /** What every Webhook row signs with. Row first, env second. */
    async getFrappeWebhookSecret() {
        const row = await this.findSettingsRow();
        return row?.frappe_webhook_secret || process.env.ERPNEXT_FRAPPE_WEBHOOK_SECRET || null;
    }
    /**
     * What the coercing transforms need: the ERPNext site's timezone, so
     * a naive Frappe datetime reads and writes as the site means it, and
     * the region a bare phone number belongs to.
     */
    async transformOptions() {
        const row = await this.findSettingsRow();
        return {
            timezone: await this.siteTimezone(),
            phoneRegion: phoneRegionOf(row),
        };
    }
    /**
     * The site's `System Settings.time_zone`, read once per process and
     * kept for an hour. Null — UTC — when ERPNext cannot be asked.
     */
    async siteTimezone() {
        const now = Date.now();
        if (_tzCache && _tzCache.expiresAt > now)
            return _tzCache.value;
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        let value = null;
        if (cfg.erpnext_url && apiCreds) {
            try {
                const qs = new URLSearchParams({ doctype: "System Settings", field: "time_zone" });
                const res = await fetch(`${cfg.erpnext_url}/api/method/frappe.client.get_single_value?${qs}`, {
                    method: "GET",
                    headers: { Authorization: `token ${apiCreds}` },
                    signal: AbortSignal.timeout(cfg.request_timeout_ms),
                });
                if (res.ok) {
                    const body = await res.json().catch(() => null);
                    const tz = String(body?.message ?? "").trim();
                    if (tz) {
                        // A zone Node does not know is worse than UTC: it throws on every date.
                        new Intl.DateTimeFormat("en-US", { timeZone: tz });
                        value = tz;
                    }
                }
            }
            catch {
                value = null;
            }
        }
        _tzCache = { value, expiresAt: now + (value ? 60 * 60 * 1000 : 5 * 60 * 1000) };
        return value;
    }
    /**
     * The known values for a Medusa target path — product status, sales
     * channels, shipping profiles — for the mapper's value picker. Null
     * when the path takes free text.
     */
    async medusaOptions(entity, path, scope) {
        const descriptor = (0, registry_1.getMedusaEntity)(entity);
        const provider = descriptor?.options?.[path];
        if (!provider)
            return null;
        try {
            return await provider(scope);
        }
        catch (err) {
            console.warn(`[erpnext] options for ${entity}.${path} failed:`, describeError(err));
            return [];
        }
    }
    /** Which DocType "link this product" searches. */
    async productsDoctype() {
        const cfg = await this.getActiveConfig();
        let mappings = [];
        try {
            mappings = await this.listErpnextMappings({ medusa_entity: "product" }, { take: 50 });
        }
        catch {
            mappings = [];
        }
        return (0, selection_1.resolveProductsDoctype)(cfg.sync_doctypes, mappings);
    }
    /**
     * One signed, validated webhook body from ERPNext, applied through
     * every enabled pull mapping for its DocType. Always writes a sync row
     * so Frappe's Webhook Request Log and this log tell one story.
     *
     * Answers "skipped" (HTTP 200 at the route) for anything that is not
     * ours to act on: Frappe retries a non-2xx three times, and a retry
     * cannot make a document ours.
     */
    async receiveFrappeWebhook(args) {
        const body = args.body;
        const event_id = (0, frappe_webhook_1.frappeEventId)(body);
        const eventName = `frappe.${body.event}`;
        const cfg = await this.getActiveConfig();
        if (!cfg.enable_sync) {
            return { ok: true, status: "skipped", event_id, message: "sync disabled" };
        }
        // Frappe delivers again when we answer slowly. The same delivery
        // already applied is answered as applied; one still being applied
        // is answered as taken, not applied twice.
        const [existing] = await this.listErpnextSyncEvents({ event_id, direction: "inbound" }, { take: 1 });
        if (existing?.status === "success") {
            return { ok: true, status: "success", event_id, message: "already applied" };
        }
        if (existing?.status === "pending" &&
            existing.last_attempt_at &&
            Date.now() - new Date(existing.last_attempt_at).getTime() < IN_FLIGHT_MS) {
            return { ok: true, status: "skipped", event_id, message: "already being applied" };
        }
        const stockOrPrice = (0, stock_prices_1.isStockOrPriceDoctype)(body.doctype);
        const invoiceEvent = body.doctype === invoice_events_1.SALES_INVOICE_DOCTYPE;
        const mappings = stockOrPrice || invoiceEvent
            ? []
            : (await this.listEnabledPullMappings()).filter((m) => m.doctype === body.doctype);
        if (!stockOrPrice && !invoiceEvent && !mappings.length) {
            // A change on a DocType that hangs off a synced one (a Contact of
            // a Customer): find the main document and apply it as its change.
            const viaSecondary = await this.mappingsWithSecondary(body.doctype);
            if (viaSecondary.length && !(0, push_rest_1.isOwnWrite)(body.doc, await this.apiUserEmail())) {
                const row = await this.upsertInboundEventRow({ event: eventName, event_id, data: body }, { status: "pending", last_error: null });
                try {
                    const rest = await this.restClient();
                    const results = [];
                    for (const { mapping, sec } of viaSecondary) {
                        const mainName = (0, secondary_doctypes_1.mainNameFromSecondaryDoc)(sec, String(mapping.doctype), body.doc);
                        if (!mainName || !rest) {
                            results.push({ mapping: mapping.name, ok: true, action: "skipped", reason: `${body.doctype} ${body.name} is not linked to a ${mapping.doctype}` });
                            continue;
                        }
                        const main = await rest.client.get(`/api/resource/${encodeURIComponent(String(mapping.doctype))}/${encodeURIComponent(mainName)}`);
                        if (main.ok !== true || !main.data) {
                            results.push({ mapping: mapping.name, ok: true, action: "skipped", reason: `${mapping.doctype} ${mainName} not found` });
                            continue;
                        }
                        const synthetic = { event: "on_update", doctype: String(mapping.doctype), name: mainName, doc: main.data };
                        const outcome = await this.applyFrappeEvent(synthetic, args.scope, [mapping]);
                        results.push(...outcome.results);
                    }
                    const failed = results.filter((r) => r.ok === false);
                    const message = failed.length ? String(failed[0].error ?? "failed").slice(0, ERROR_TRUNCATE) : null;
                    await this.updateErpnextSyncEvents({
                        id: row.id,
                        status: failed.length ? "failed" : "success",
                        succeeded_at: failed.length ? null : new Date(),
                        last_error: message,
                        action: summariseActions(results),
                        entity_ref: (0, echo_1.entityRefOf)({ results }),
                    });
                    return failed.length
                        ? { ok: false, status: "failed", event_id, message: message ?? undefined, results }
                        : { ok: true, status: "success", event_id, results };
                }
                catch (err) {
                    const message = describeError(err).slice(0, ERROR_TRUNCATE);
                    await this.updateErpnextSyncEvents({ id: row.id, status: "failed", last_error: message });
                    return { ok: false, status: "failed", event_id, message };
                }
            }
            const message = `no enabled pull mapping for ${body.doctype}`;
            await this.upsertInboundEventRow({ event: eventName, event_id, data: body }, { status: "skipped", last_error: message, action: "skipped" });
            return { ok: true, status: "skipped", event_id, message };
        }
        const row = await this.upsertInboundEventRow({ event: eventName, event_id, data: body }, { status: "pending", last_error: null });
        try {
            const outcome = invoiceEvent
                ? await this.applySalesInvoiceEvent(body, args.scope)
                : stockOrPrice
                    ? await this.applyStockPriceEvent(body, args.scope)
                    : await this.applyFrappeEvent(body, args.scope, mappings);
            const failed = outcome.results.filter((r) => r.ok === false);
            const message = failed.length
                ? String(failed[0].error ?? "failed").slice(0, ERROR_TRUNCATE)
                : null;
            await this.updateErpnextSyncEvents({
                id: row.id,
                status: failed.length ? "failed" : "success",
                succeeded_at: failed.length ? null : new Date(),
                last_error: message,
                action: summariseActions(outcome.results),
                entity_ref: (0, echo_1.entityRefOf)(outcome),
            });
            return failed.length
                ? { ok: false, status: "failed", event_id, message: message ?? undefined, results: outcome.results }
                : { ok: true, status: "success", event_id, results: outcome.results };
        }
        catch (err) {
            const message = describeError(err).slice(0, ERROR_TRUNCATE);
            await this.updateErpnextSyncEvents({ id: row.id, status: "failed", last_error: message });
            return { ok: false, status: "failed", event_id, message };
        }
    }
    /**
     * The executor behind the webhook route, the retry job and the studio's
     * plan: per mapping, decide (./frappe-webhook.ts) and do.
     *
     * The key is the raw value of the mapping's ERPNext key field, as the
     * pull uses it; the entity turns an item code into a handle itself. A
     * draft goes through the link when there is one, so a renamed or
     * re-keyed product is still found.
     */
    async applyFrappeEvent(body, scope, mappings) {
        const candidates = mappings ??
            (await this.listEnabledPullMappings()).filter((m) => m.doctype === body.doctype);
        const results = [];
        const remote_direction = selection_1.SELECTION_FIELD in (body.doc ?? {}) ? String(body.doc[selection_1.SELECTION_FIELD] ?? "") : undefined;
        const transformOptions = await this.transformOptions();
        // A document the API user last wrote is a push of ours coming home;
        // applying it would only bounce it again. Its direction is still
        // noted so a push reads the current answer.
        const ownWrite = (0, push_rest_1.isOwnWrite)(body.doc, await this.apiUserEmail());
        for (const mapping of candidates) {
            const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
            if (!entity) {
                // A configuration gap, not a delivery failure: a retry
                // cannot make an entity appear.
                results.push({
                    mapping: mapping.name,
                    ok: true,
                    action: "skipped",
                    reason: `no registry entry for '${mapping.medusa_entity}'`,
                });
                continue;
            }
            const link = await this.findLink(body.doctype, body.name, mapping.medusa_entity);
            const plan = ownWrite
                ? { action: "skip", reason: "our own write coming home" }
                : (0, frappe_webhook_1.planFrappeEvent)({ event: body.event, doc: body.doc, mapping, link });
            if (plan.action === "skip") {
                // Remember which way the document now moves, so a push for
                // it reads the current answer.
                if (link && remote_direction !== undefined && remote_direction !== link.remote_direction) {
                    await this.recordLink({
                        doctype: body.doctype,
                        erpnext_name: body.name,
                        medusa_entity: mapping.medusa_entity,
                        medusa_id: link.medusa_id,
                        mapping_id: mapping.id,
                        state: link.state === "drafted" ? "drafted" : "active",
                        remote_direction,
                    });
                }
                results.push({
                    mapping: mapping.name,
                    entity: mapping.medusa_entity,
                    ok: true,
                    action: "skipped",
                    reason: plan.reason,
                });
                continue;
            }
            if (plan.action === "draft") {
                if (!entity.disableByKey) {
                    results.push({
                        mapping: mapping.name,
                        entity: mapping.medusa_entity,
                        ok: true,
                        action: "skipped",
                        reason: `inbound delete not supported for entity '${mapping.medusa_entity}'`,
                    });
                    continue;
                }
                const out = plan.by === "link"
                    ? await entity.disableByKey(scope, "id", plan.medusa_id)
                    : await entity.disableByKey(scope, mapping.key_medusa_field, mapping.key_medusa_field === "handle" ? (0, registry_1.handleFromKey)(plan.key) : plan.key);
                const id = out.id ?? (plan.by === "link" ? plan.medusa_id : undefined);
                if (out.ok !== false && id) {
                    await this.recordLink({
                        doctype: body.doctype,
                        erpnext_name: body.name,
                        medusa_entity: mapping.medusa_entity,
                        medusa_id: id,
                        mapping_id: mapping.id,
                        state: "drafted",
                        remote_direction,
                    });
                }
                results.push({
                    mapping: mapping.name,
                    entity: mapping.medusa_entity,
                    ok: out.ok !== false,
                    id,
                    action: out.skipped ? "skipped" : "drafted",
                    reason: out.skipped ? `${plan.reason}; ${out.action ?? "absent"}` : plan.reason,
                    error: out.error,
                });
                continue;
            }
            const transform = (0, mapping_engine_1.applyMapping)({
                direction: "pull",
                fields: (0, secondary_doctypes_1.pairsForPull)(mapping.field_mappings, String(mapping.doctype)),
                mappingDirection: mapping.direction,
                source: await this.hydrateSecondaries((await this.restClient())?.client ?? null, mapping, body.doc),
                options: transformOptions,
            });
            if (transform.ok === false) {
                results.push({
                    mapping: mapping.name,
                    entity: mapping.medusa_entity,
                    ok: true,
                    action: "skipped",
                    reason: transform.reason,
                });
                continue;
            }
            const payload = (0, frappe_webhook_1.withRepublish)(transform.payload, plan.republish);
            const outcome = await entity.upsertByKey(scope, mapping.key_medusa_field, plan.key, payload);
            if (outcome.ok && outcome.id) {
                await this.recordLink({
                    doctype: body.doctype,
                    erpnext_name: body.name,
                    medusa_entity: mapping.medusa_entity,
                    medusa_id: outcome.id,
                    mapping_id: mapping.id,
                    state: "active",
                    remote_direction,
                });
                if (mapping.medusa_entity === "product" && body.doctype === "Item") {
                    try {
                        const gst = await this.refreshProductGst(scope, [body.name]);
                        if (gst.notes.length)
                            console.warn("[erpnext] GST rate:", gst.notes.join("; "));
                    }
                    catch (err) {
                        console.warn("[erpnext] GST rate refresh failed:", describeError(err));
                    }
                    // An Item and its first Item Price are saved together, and
                    // the price's webhook can land before the product exists;
                    // a new product reads its price and stock itself.
                    if (outcome.created) {
                        try {
                            await this.refreshStockAndPrices(scope, [body.name]);
                        }
                        catch (err) {
                            console.warn("[erpnext] stock/price for a new product failed:", describeError(err));
                        }
                    }
                }
            }
            results.push({
                mapping: mapping.name,
                entity: mapping.medusa_entity,
                ok: outcome.ok,
                id: outcome.id,
                action: outcome.ok ? (outcome.created ? "created" : "updated") : undefined,
                reason: plan.reason,
                error: outcome.error,
            });
        }
        return { via: "frappe", event: body.event, results };
    }
    /**
     * Re-apply a stored inbound row. A row from before the Frappe-webhook
     * era carries a medusync envelope, which nothing can apply any more;
     * it is marked poison so the retry job stops cycling it.
     */
    async replayInboundEvent(row, scope) {
        const parsed = frappe_webhook_1.FrappeWebhookBody.safeParse(row?.payload);
        const attempts = (row?.attempts ?? 0) + 1;
        if (parsed.success) {
            // A later delivery for the same document that already applied
            // wins: replaying this older body would put back what it changed.
            let later = [];
            try {
                later = await this.listErpnextSyncEvents({
                    direction: "inbound",
                    status: "success",
                    event_id: { $like: `frappe:%:${parsed.data.doctype}:${parsed.data.name}:%` },
                }, { take: 50 });
            }
            catch {
                later = [];
            }
            if ((0, frappe_webhook_1.supersededBy)(parsed.data, later)) {
                const error = "superseded by a later delivery for the same document; not replayed";
                await this.updateErpnextSyncEvents({
                    id: row.id,
                    status: "skipped",
                    last_error: error,
                    attempts,
                    last_attempt_at: new Date(),
                });
                return { ok: true, status: "success", error };
            }
        }
        if (!parsed.success) {
            const error = "not replayable: the payload is from the retired medusync protocol";
            await this.updateErpnextSyncEvents({
                id: row.id,
                status: "poison",
                last_error: error,
                attempts,
                last_attempt_at: new Date(),
            });
            return { ok: false, status: "failed", error, poison: true };
        }
        try {
            const outcome = (0, stock_prices_1.isStockOrPriceDoctype)(parsed.data.doctype)
                ? await this.applyStockPriceEvent(parsed.data, scope)
                : await this.applyFrappeEvent(parsed.data, scope);
            const failed = outcome.results.filter((r) => r.ok === false);
            const error = failed.length ? String(failed[0].error ?? "failed").slice(0, ERROR_TRUNCATE) : null;
            await this.updateErpnextSyncEvents({
                id: row.id,
                attempts,
                last_attempt_at: new Date(),
                status: failed.length ? "failed" : "success",
                succeeded_at: failed.length ? null : new Date(),
                last_error: error,
                action: summariseActions(outcome.results),
                entity_ref: (0, echo_1.entityRefOf)(outcome),
            });
            return failed.length ? { ok: false, status: "failed", error: error ?? undefined } : { ok: true, status: "success" };
        }
        catch (err) {
            const error = describeError(err).slice(0, ERROR_TRUNCATE);
            await this.updateErpnextSyncEvents({
                id: row.id,
                attempts,
                last_attempt_at: new Date(),
                status: "failed",
                last_error: error,
            });
            return { ok: false, status: "failed", error };
        }
    }
    /**
     * What a webhook body WOULD do, mapping by mapping, without doing it.
     * The studio's "plan inbound". Reads links, writes nothing.
     */
    async planInbound(body) {
        // Stock and prices have no mapping; say what would move and why.
        if ((0, stock_prices_1.isStockOrPriceDoctype)(body.doctype)) {
            const cfg = await this.getActiveConfig();
            if (stock_prices_1.STOCK_DOCTYPES.has(body.doctype)) {
                if (!cfg.sync_stock)
                    return { action: "skipped", reason: "stock sync is off in Settings" };
                const pairs = (0, stock_prices_1.stockPairsOf)(body, cfg.erpnext_warehouse);
                return pairs.length
                    ? { action: "stock", warehouse: cfg.erpnext_warehouse, items: pairs.map((p) => p.item_code), reads: "Bin per item, then the level = actual − reserved − safety" }
                    : { action: "skipped", reason: `nothing at warehouse ${cfg.erpnext_warehouse ?? "(not set)"}` };
            }
            if (!cfg.sync_prices)
                return { action: "skipped", reason: "price sync is off in Settings" };
            const rest = await this.restClient();
            const priceList = rest ? (await this.pushDefaults(rest.client)).priceList : null;
            const plan = (0, stock_prices_1.planItemPrice)({ event: body.event, doc: body.doc, priceList, today: (0, mapping_engine_2.formatInZone)(new Date(), await this.siteTimezone(), false) });
            return plan.action === "skip" ? { action: "skipped", reason: plan.reason } : { action: `price ${plan.action}`, ...plan };
        }
        let mappings = [];
        try {
            mappings = (await this.listEnabledPullMappings()).filter((m) => m.doctype === body.doctype);
        }
        catch {
            mappings = [];
        }
        if (!mappings.length) {
            return {
                action: "skipped",
                reason: `no enabled pull mapping for '${body.doctype}'`,
            };
        }
        const plans = [];
        for (const mapping of mappings) {
            const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
            if (!entity) {
                plans.push({
                    mapping: mapping.name,
                    action: "error",
                    reason: `no registry entry for '${mapping.medusa_entity}'`,
                });
                continue;
            }
            const link = await this.findLink(body.doctype, body.name, mapping.medusa_entity);
            const plan = (0, frappe_webhook_1.planFrappeEvent)({ event: body.event, doc: body.doc, mapping, link });
            const linkView = link ? { medusa_id: link.medusa_id, state: link.state } : null;
            if (plan.action === "skip") {
                plans.push({ mapping: mapping.name, entity: mapping.medusa_entity, action: "skipped", reason: plan.reason, link: linkView });
                continue;
            }
            if (plan.action === "draft") {
                plans.push({
                    mapping: mapping.name,
                    entity: mapping.medusa_entity,
                    action: entity.disableByKey ? "disabled" : "skipped",
                    reason: entity.disableByKey
                        ? plan.reason
                        : `inbound delete not supported for entity '${mapping.medusa_entity}'`,
                    key_field: plan.by === "link" ? "id" : mapping.key_medusa_field,
                    key_value: plan.by === "link" ? plan.medusa_id : plan.key,
                    link: linkView,
                });
                continue;
            }
            const transform = (0, mapping_engine_1.applyMapping)({
                direction: "pull",
                fields: (0, secondary_doctypes_1.pairsForPull)(mapping.field_mappings, String(mapping.doctype)),
                mappingDirection: mapping.direction,
                source: await this.hydrateSecondaries((await this.restClient())?.client ?? null, mapping, body.doc),
                options: await this.transformOptions(),
            });
            if (transform.ok === false) {
                plans.push({ mapping: mapping.name, entity: mapping.medusa_entity, action: "skipped", reason: transform.reason, link: linkView });
                continue;
            }
            plans.push({
                mapping: mapping.name,
                entity: mapping.medusa_entity,
                action: "upserted",
                reason: plan.reason,
                key_field: mapping.key_medusa_field,
                key_value: plan.key,
                republish: plan.republish,
                payload: (0, frappe_webhook_1.withRepublish)(transform.payload, plan.republish),
                skipped_fields: transform.skippedFields,
                link: linkView,
            });
        }
        return { action: "planned", mappings: plans };
    }
    /**
     * A saved address was deleted in the store: disable its ERPNext Address
     * (ERPNext keeps it for the documents that used it) and push the
     * customer, so ERPNext's list matches the store's.
     */
    async addressRemoved(scope, customerId, addressId) {
        const [row] = await this.listErpnextLinks({ doctype: "Address", medusa_entity: "address", medusa_id: addressId }, { take: 1 });
        if (row?.erpnext_name) {
            const rest = await this.restClient();
            if (rest) {
                const out = await this.writeRemote(rest.client, "Address", String(row.erpnext_name), { disabled: 1 });
                if (out.ok === false)
                    console.warn(`[erpnext] Address ${row.erpnext_name} not disabled: ${out.error}`);
                else
                    await this.recordLink({ doctype: "Address", erpnext_name: String(row.erpnext_name), medusa_entity: "address", medusa_id: addressId, state: "drafted" });
            }
        }
        const eventBus = scope.resolve(utils_1.Modules.EVENT_BUS);
        await eventBus.emit([{ name: "customer.updated", data: { id: customerId } }]);
    }
    // ── GST: the product's rate and the store's rounding ─────────────
    /**
     * Charge each linked product at its ERPNext Item's GST rate: the rate
     * of the Item Tax Template ERPNext would pick (the Item's own, else its
     * group's), recorded as a product rule on a non-default rate of the
     * company's country's tax region, with `metadata.gst_rate` as a copy
     * for display. An Item without a template is charged the region's
     * default rate, as ERPNext's taxes template charges it.
     */
    async refreshProductGst(scope, itemCodes) {
        const notes = [];
        let updated = 0;
        const codes = Array.from(new Set(itemCodes.filter(Boolean)));
        const rest = await this.restClient();
        if (!rest || !codes.length)
            return { updated, notes };
        const client = rest.client;
        const defaults = await this.pushDefaults(client);
        const site = await this.companySite(client, defaults.company);
        if (!site.countryCode)
            return { updated, notes: ["GST rates: the company's country is unknown"] };
        const tax = scope.resolve(utils_1.Modules.TAX);
        const [region] = await tax.listTaxRegions({ country_code: site.countryCode, parent_id: null }, { take: 1 });
        if (!region)
            return { updated, notes: [`GST rates: no tax region for "${site.countryCode}"`] };
        const templates = await this.itemTaxTemplates(client);
        const today = (0, mapping_engine_2.formatInZone)(new Date(), await this.siteTimezone(), false);
        const product = scope.resolve(utils_1.Modules.PRODUCT);
        for (const code of codes) {
            try {
                const link = await this.findLink("Item", code, "product");
                if (!link?.medusa_id)
                    continue;
                const item = await client.get(`/api/resource/Item/${encodeURIComponent(code)}`);
                if (item.ok !== true || !item.data) {
                    notes.push(`GST ${code}: Item not readable`);
                    continue;
                }
                const tables = [Array.isArray(item.data.taxes) ? item.data.taxes : []];
                let group = item.data.item_group ? String(item.data.item_group) : null;
                let groupsRead = true;
                for (let depth = 0; group && depth < 10; depth += 1) {
                    const g = await this.itemGroup(client, group);
                    if (!g.ok) {
                        groupsRead = false;
                        break;
                    }
                    tables.push(g.taxes);
                    group = g.parent;
                }
                const template = (0, item_gst_1.effectiveItemTaxTemplate)({
                    tables,
                    today,
                    company: defaults.company,
                    companyOf: (name) => templates.map.get(name)?.company ?? null,
                });
                // A read that failed is not "no template": moving the product
                // to the default rate would overcharge it until the next refresh.
                if (!template && !groupsRead) {
                    notes.push(`GST ${code}: Item Group not readable; rate left as it is`);
                    continue;
                }
                if (template && !templates.map.has(template)) {
                    notes.push(`GST ${code}: ${templates.ok ? "template" : "templates"} ${template} not readable; rate left as it is`);
                    continue;
                }
                const rate = template ? templates.map.get(template)?.rate ?? null : null;
                const regionRates = await tax.listTaxRates({ tax_region_id: region.id }, { relations: ["rules"], take: 200 });
                const plan = (0, item_gst_1.planProductTaxRule)({ productId: String(link.medusa_id), rate, regionRates });
                let targetId = plan.addTo;
                if (plan.create) {
                    const [created] = await tax.createTaxRates([
                        { tax_region_id: region.id, ...plan.create, is_default: false, is_combinable: false },
                    ]);
                    targetId = created.id;
                }
                if (plan.remove.length)
                    await tax.deleteTaxRateRules(plan.remove);
                if (targetId) {
                    await tax.createTaxRateRules([{ tax_rate_id: targetId, reference: "product", reference_id: String(link.medusa_id) }]);
                }
                const [row] = await product.listProducts({ id: link.medusa_id }, { select: ["id", "metadata"], take: 1 });
                const meta = row?.metadata ?? {};
                const changed = Number(meta.gst_rate) !== plan.rate || (meta.gst_template ?? null) !== template;
                if (row && changed) {
                    await product.updateProducts(row.id, { metadata: { ...meta, gst_rate: plan.rate, gst_template: template } });
                }
                if (changed || plan.create || plan.remove.length || targetId)
                    updated += 1;
            }
            catch (err) {
                notes.push(`GST ${code}: ${describeError(err)}`);
            }
        }
        return { updated, notes };
    }
    /** Item Tax Templates' GST rate and company, cached for an hour. */
    async itemTaxTemplates(client) {
        const now = Date.now();
        if (_itemTaxTemplateCache && _itemTaxTemplateCache.expiresAt > now)
            return { ok: true, map: _itemTaxTemplateCache.map };
        const res = await client.get("/api/resource/Item%20Tax%20Template", {
            fields: JSON.stringify(["name", "gst_rate", "company", "disabled"]),
            limit_page_length: "0",
        });
        const map = new Map();
        for (const r of res.ok === true && Array.isArray(res.data) ? res.data : []) {
            const rate = r.gst_rate === null || r.gst_rate === undefined || r.gst_rate === "" ? null : Number(r.gst_rate);
            map.set(String(r.name), { rate: Number.isFinite(rate) ? rate : null, company: r.company ? String(r.company) : null });
        }
        if (res.ok === true)
            _itemTaxTemplateCache = { map, expiresAt: now + 60 * 60 * 1000 };
        return { ok: res.ok === true, map };
    }
    /** An Item Group's taxes and parent, cached for an hour. */
    async itemGroup(client, name) {
        const now = Date.now();
        const hit = _itemGroupCache.get(name);
        if (hit && hit.expiresAt > now)
            return { ok: true, ...hit };
        const res = await client.get(`/api/resource/Item%20Group/${encodeURIComponent(name)}`);
        if (res.ok !== true)
            return { ok: false, taxes: [], parent: null };
        const out = {
            taxes: Array.isArray(res.data?.taxes) ? res.data.taxes : [],
            parent: res.data?.parent_item_group ? String(res.data.parent_item_group) : null,
            expiresAt: now + 60 * 60 * 1000,
        };
        _itemGroupCache.set(name, out);
        return { ok: true, ...out };
    }
    /**
     * How ERPNext rounds a sales document's total: whether it does at all
     * (Global Defaults), by which method (System Settings) and to what
     * fraction of the currency. Cached for ten minutes; an unreadable site
     * keeps the last answer, else Banker's rounding to the unit.
     */
    async erpnextRoundingRule(client, currency) {
        const now = Date.now();
        const key = currency.toUpperCase();
        const hit = _roundingCache.get(key);
        if (hit && hit.expiresAt > now)
            return hit;
        const single = (doctype, field) => client.get("/api/method/frappe.client.get_single_value", { doctype, field });
        const disabled = await single("Global Defaults", "disable_rounded_total");
        const method = await single("System Settings", "rounding_method");
        const fraction = await client.get("/api/method/frappe.client.get_value", {
            doctype: "Currency",
            filters: key,
            fieldname: "smallest_currency_fraction_value",
        });
        if (disabled.ok !== true || method.ok !== true || fraction.ok !== true) {
            return hit ?? { roundTotal: true, method: null, smallestFraction: 0 };
        }
        const rule = {
            roundTotal: !Number(disabled.data),
            method: method.data ? String(method.data) : null,
            smallestFraction: Number(fraction.data?.smallest_currency_fraction_value) || 0,
            expiresAt: now + 10 * 60 * 1000,
        };
        _roundingCache.set(key, rule);
        return rule;
    }
    /**
     * Keep the cart's rounding line at what makes its total ERPNext's
     * rounded total (see rounding.ts), and bring an existing payment
     * collection to the new total. Called by the storefront before it
     * shows the checkout summary and before it takes payment. Never
     * throws for a sync reason: a cart that cannot be rounded is left as
     * it is and the reason returned.
     */
    async roundCart(scope, cartId) {
        const cfg = await this.getActiveConfig();
        if (!cfg.enable_sync)
            return { ok: true, action: "skipped", reason: "sync is off" };
        const rest = await this.restClient(STORE_TIMEOUT_MS);
        if (!rest)
            return { ok: true, action: "skipped", reason: "ERPNext not configured" };
        const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
        const { data } = await query.graph({
            entity: "cart",
            fields: [
                "id",
                "currency_code",
                "total",
                "items.id",
                "items.unit_price",
                "items.quantity",
                "items.is_tax_inclusive",
                "items.adjustments.amount",
                "items.tax_lines.rate",
                "shipping_methods.amount",
                "shipping_methods.adjustments.amount",
                "credit_lines.id",
                "credit_lines.reference",
                "credit_lines.amount",
                "billing_address.province",
                "shipping_address.province",
                "payment_collection.id",
            ],
            filters: { id: cartId },
        });
        const cart = data?.[0];
        if (!cart)
            return { ok: false, action: "failed", reason: "cart not found" };
        const defaults = await this.pushDefaults(rest.client);
        const site = await this.companySite(rest.client, defaults.company);
        const rule = await this.erpnextRoundingRule(rest.client, String(cart.currency_code ?? "inr"));
        const plan = (0, rounding_1.planCartRounding)({
            cart,
            companyState: site.state,
            roundTotal: rule.roundTotal,
            rounding: { method: rule.method, smallestFraction: rule.smallestFraction },
        });
        const cartModule = scope.resolve(utils_1.Modules.CART);
        const ours = (cart.credit_lines ?? []).filter((c) => c?.reference === rounding_1.ROUNDING_REFERENCE);
        const want = plan.action === "set" ? plan.amount : 0;
        const current = ours.reduce((s, c) => s + Number(c.amount || 0), 0);
        if (ours.length === (want ? 1 : 0) && Math.abs(current - want) < 0.005) {
            return { ok: true, action: "unchanged", amount: want, payable: plan.action === "set" ? plan.estimate.payable : undefined };
        }
        if (ours.length)
            await cartModule.softDeleteCreditLines(ours.map((c) => c.id));
        if (want) {
            await cartModule.createCreditLines([
                { cart_id: cartId, reference: rounding_1.ROUNDING_REFERENCE, reference_id: cartId, amount: want, metadata: { label: "Rounding" } },
            ]);
        }
        if (cart.payment_collection?.id) {
            await (0, core_flows_1.refreshPaymentCollectionForCartWorkflow)(scope).run({ input: { cart_id: cartId } });
        }
        return {
            ok: true,
            action: want ? "set" : "cleared",
            amount: want,
            reason: plan.action === "clear" ? plan.reason : undefined,
            payable: plan.action === "set" ? plan.estimate.payable : undefined,
        };
    }
    async findLink(doctype, erpnext_name, medusa_entity) {
        const [row] = await this.listErpnextLinks({ doctype, erpnext_name, medusa_entity }, { take: 1 });
        return row ?? null;
    }
    /**
     * Remember which Medusa record an ERPNext document became. Never
     * throws: the write it describes has already happened, and the next
     * event rebuilds a link that was not recorded.
     */
    async recordLink(args) {
        try {
            const existing = await this.findLink(args.doctype, args.erpnext_name, args.medusa_entity);
            const now = new Date();
            const direction = args.remote_direction !== undefined ? { remote_direction: args.remote_direction } : {};
            if (existing) {
                await this.updateErpnextLinks([
                    {
                        id: existing.id,
                        medusa_id: args.medusa_id,
                        mapping_id: args.mapping_id ?? existing.mapping_id ?? null,
                        state: args.state,
                        ...direction,
                        ...(args.state === "active" ? { last_seen_at: now } : {}),
                    },
                ]);
                return;
            }
            await this.createErpnextLinks([
                {
                    doctype: args.doctype,
                    erpnext_name: args.erpnext_name,
                    medusa_entity: args.medusa_entity,
                    medusa_id: args.medusa_id,
                    mapping_id: args.mapping_id ?? null,
                    state: args.state,
                    remote_direction: args.remote_direction ?? null,
                    last_seen_at: args.state === "active" ? now : null,
                },
            ]);
        }
        catch (err) {
            console.warn("[erpnext] link not recorded:", describeError(err));
        }
    }
    /**
     * "Set up ERPNext": the `medusa_sync` field and the two Webhooks on
     * every selection DocType, over REST, idempotently. See
     * ./erpnext-setup.ts for what is created and why in that order.
     *
     * The secret is generated here when the row has none, so the operator
     * never has to type one anywhere.
     */
    async setupErpnext(args = {}) {
        const cfg = await this.getActiveConfig();
        const creds = await this.frappeApiCreds();
        if (!cfg.erpnext_url)
            return { ok: false, message: "ERPNext URL is not set" };
        if (!creds)
            return { ok: false, message: "ERPNext API key and secret are not set" };
        const publicUrl = cfg.medusa_public_url ?? publicUrlOf(args.fallbackPublicUrl ?? null);
        if (!publicUrl) {
            return {
                ok: false,
                message: "Medusa public URL is not set — where ERPNext will POST webhooks (or set MEDUSA_BACKEND_URL)",
            };
        }
        if (!cfg.sync_doctypes.length)
            return { ok: false, message: "no sync doctypes configured" };
        let row = await this.findSettingsRow();
        let secret = cfg.frappe_webhook_secret;
        if (!secret) {
            secret = crypto_1.default.randomBytes(32).toString("hex");
            if (row) {
                await this.updateErpnextSettings([{ id: row.id, frappe_webhook_secret: secret }]);
            }
            else {
                ;
                [row] = await this.createErpnextSettings([
                    { singleton_key: SINGLETON_KEY, frappe_webhook_secret: secret },
                ]);
            }
        }
        // Creating a Custom Field makes Frappe ALTER the DocType's table on
        // the spot; on a 60k-row Item that is well past the ordinary request
        // timeout, and a request that times out here still completes there.
        const client = (0, frappe_client_1.makeFrappeClient)({
            baseUrl: cfg.erpnext_url,
            token: creds,
            timeoutMs: Math.max(cfg.request_timeout_ms, SETUP_TIMEOUT_MS),
        });
        const sellingList = cfg.sync_prices ? (await this.pushDefaults(client)).priceList : null;
        const report = await (0, erpnext_setup_1.runErpnextSetup)({
            client,
            doctypes: cfg.sync_doctypes,
            publicUrl,
            secret,
            previous: cfg.erpnext_setup_report,
            stock: cfg.sync_stock && cfg.erpnext_warehouse ? { warehouse: cfg.erpnext_warehouse } : null,
            prices: cfg.sync_prices && sellingList ? { priceList: sellingList } : null,
            invoices: (0, invoice_number_1.receivesErpInvoices)(row),
            secondaries: (await this.listEnabledPullMappings()).flatMap((m) => (0, secondary_doctypes_1.normalizeSecondaryDoctypes)(m.secondary_doctypes, m.doctype).map((s) => s.doctype)),
        });
        if (row) {
            await this.updateErpnextSettings([
                { id: row.id, erpnext_setup_at: new Date(), erpnext_setup_report: report },
            ]);
        }
        return { ok: report.ok, report };
    }
    /**
     * The safety net under the webhooks: every active link whose document
     * no longer moves ERPNext → Medusa — deselected while we were down,
     * trashed, renamed — gets its product drafted. A document that became
     * Medusa → ERPNext is Medusa's own and is left alone; its new direction
     * is noted so a push reads the current answer. Runs hourly.
     */
    async reconcileSelection(container) {
        const report = { checked: 0, drafted: 0, errors: [] };
        const cfg = await this.getActiveConfig();
        const apiCreds = await this.frappeApiCreds();
        if (!cfg.enable_sync)
            return { ...report, skipped: "sync-disabled" };
        if (!cfg.erpnext_url || !apiCreds)
            return { ...report, skipped: "not-configured" };
        let mappings = [];
        try {
            mappings = (await this.listEnabledPullMappings()).filter((m) => (0, selection_1.isSyncDoctype)(m.doctype, cfg.sync_doctypes));
        }
        catch (err) {
            report.errors.push({ error: describeError(err) });
            return report;
        }
        const PAGE = 100;
        for (const mapping of mappings) {
            const entity = (0, registry_1.getMedusaEntity)(mapping.medusa_entity);
            if (!entity?.disableByKey)
                continue;
            // Every link first, then the work: drafting while paging by
            // offset would shift the unread rows under the cursor.
            const all = [];
            try {
                for (let skip = 0;; skip += PAGE) {
                    const page = await this.listErpnextLinks({ doctype: mapping.doctype, medusa_entity: mapping.medusa_entity }, { take: PAGE, skip, order: { id: "ASC" } });
                    all.push(...page);
                    if (page.length < PAGE)
                        break;
                }
            }
            catch (err) {
                report.errors.push({ mapping: mapping.name, error: describeError(err) });
                continue;
            }
            for (let i = 0; i < all.length; i += PAGE) {
                const links = all.slice(i, i + PAGE);
                const names = links.map((l) => String(l.erpnext_name));
                const qs = new URLSearchParams();
                qs.set("fields", JSON.stringify(["name", selection_1.SELECTION_FIELD]));
                qs.set("filters", JSON.stringify([["name", "in", names]]));
                qs.set("limit_page_length", String(names.length));
                try {
                    const res = await fetch(`${cfg.erpnext_url}/api/resource/${encodeURIComponent(mapping.doctype)}?${qs}`, {
                        method: "GET",
                        headers: { Authorization: `token ${apiCreds}` },
                        signal: AbortSignal.timeout(cfg.request_timeout_ms),
                    });
                    const text = await res.text().catch(() => "");
                    if (!res.ok) {
                        report.errors.push({ mapping: mapping.name, error: `HTTP ${res.status}: ${text.slice(0, 200)}` });
                        break;
                    }
                    const parsed = JSON.parse(text);
                    // What ERPNext says now, per document. A name it does not
                    // return is gone (trashed, renamed) and reads as undefined.
                    const values = new Map();
                    for (const r of Array.isArray(parsed?.data) ? parsed.data : []) {
                        values.set(String(r?.name), r?.[selection_1.SELECTION_FIELD] ?? "");
                    }
                    for (const link of links) {
                        const value = values.get(String(link.erpnext_name));
                        const decision = (0, selection_1.reconcileDecision)(value);
                        const seen = value === undefined ? undefined : String(value ?? "");
                        // The direction ERPNext shows is noted on every link,
                        // drafted ones included, so a push reads the current
                        // answer. Only an active link can be drafted here.
                        if (link.state !== "active") {
                            if (seen !== undefined && seen !== (link.remote_direction ?? "")) {
                                await this.updateErpnextLinks([{ id: link.id, remote_direction: seen }]);
                            }
                            continue;
                        }
                        report.checked += 1;
                        if (decision !== "draft") {
                            if (seen !== undefined && seen !== (link.remote_direction ?? "")) {
                                await this.updateErpnextLinks([{ id: link.id, remote_direction: seen }]);
                            }
                            continue;
                        }
                        const out = await entity.disableByKey(container, "id", link.medusa_id);
                        if (out.ok === false) {
                            report.errors.push({ mapping: mapping.name, name: link.erpnext_name, error: out.error });
                            continue;
                        }
                        await this.updateErpnextLinks([
                            { id: link.id, state: "drafted", ...(seen !== undefined ? { remote_direction: seen } : {}) },
                        ]);
                        await this.upsertInboundEventRow({
                            event: "frappe.reconcile",
                            event_id: `frappe:reconcile:${mapping.doctype}:${link.erpnext_name}:${Date.now()}`,
                            data: { doctype: mapping.doctype, name: link.erpnext_name, medusa_id: link.medusa_id },
                        }, { status: "success", last_error: null, action: "drafted" });
                        report.drafted += 1;
                    }
                }
                catch (err) {
                    report.errors.push({ mapping: mapping.name, error: describeError(err) });
                    break;
                }
            }
        }
        return report;
    }
    async markMappingPullOutcome(mapping_id, error) {
        try {
            await this.updateErpnextMappings([
                {
                    id: mapping_id,
                    last_pull_run_at: new Date(),
                    last_pull_error: error,
                },
            ]);
        }
        catch {
            /* non-critical */
        }
    }
}
/** The ERPNext site's timezone, per process. See `siteTimezone`. */
let _tzCache = null;
/** The API user, per process. See `apiUserEmail`. */
let _apiUserCache = null;
/** ERPNext Country names by ISO code, per process. */
let _countryCache = null;
/** Per company: its own address, GST state and country code. */
const _companySiteCache = new Map();
/** Item Tax Templates' GST rate and company, per process. */
let _itemTaxTemplateCache = null;
/** Item Groups' taxes and parent, per process. */
const _itemGroupCache = new Map();
/** How ERPNext rounds a sales document's total, per currency, per process. */
const _roundingCache = new Map();
/** One Delivery Note applied at a time: its ledger entries arrive together. */
const _deliveryLocks = new Map();
/** One push per store order at a time, per process. */
const _orderLocks = new Map();
async function oneAtATime(locks, key, run) {
    const previous = locks.get(key) ?? Promise.resolve();
    const current = previous.catch(() => undefined).then(run);
    locks.set(key, current);
    try {
        return await current;
    }
    finally {
        if (locks.get(key) === current)
            locks.delete(key);
    }
}
/** ERPNext's own defaults for pushed documents, per process. */
let _defaultsCache = null;
const DEFAULT_PHONE_REGION = "IN";
/** Set up ERPNext waits this long for one call: a Custom Field POST
 *  alters the DocType's table before it answers. */
const SETUP_TIMEOUT_MS = 180_000;
/** A push waits this long for one write; ERPNext validates and names the
 *  document before answering. */
const PUSH_TIMEOUT_MS = 90_000;
/** A storefront request (checkout rounding, an order's GST) waits this long
 *  for one ERPNext read; a slow ERPNext must not hold up a checkout. */
const STORE_TIMEOUT_MS = 5_000;
/** A pending inbound row younger than this is a delivery still being
 *  applied; Frappe's retry of it is answered without a second apply. */
const IN_FLIGHT_MS = 120_000;
/** Two upper-case letters, or the default. */
function phoneRegionOf(row) {
    const raw = String(row?.phone_region ?? "").trim().toUpperCase();
    return /^[A-Z]{2}$/.test(raw) ? raw : DEFAULT_PHONE_REGION;
}
// ─── Module-level meta cache ─────────────────────────────────────────
// Field-meta lookups are pure on the Frappe side; cache per-process
// for 5 minutes so the admin field-mapper UI feels snappy.
const _META_CACHE_TTL_MS = 5 * 60 * 1000;
const _metaCache = new Map();
/**
 * Stringify a thrown error INCLUDING its underlying `cause`. Node's
 * undici `fetch` throws a bare `TypeError: fetch failed` and stashes
 * the real reason (ENOTFOUND / ECONNREFUSED / self-signed cert / DNS /
 * connect timeout) on `err.cause`. Recording only `err.message` makes
 * every connection-level failure read "fetch failed" with no clue why;
 * appending the cause turns the sync-event row into an actionable one.
 */
function describeError(err) {
    const base = String(err?.message ?? err);
    const cause = err?.cause;
    if (!cause)
        return base;
    const causeMsg = cause?.code
        ? `${cause.code}${cause.message ? `: ${cause.message}` : ""}`
        : String(cause?.message ?? cause);
    return causeMsg && causeMsg !== base ? `${base} (${causeMsg})` : base;
}
function maskSecret(s) {
    if (!s)
        return null;
    if (s.length <= 8)
        return "*".repeat(s.length);
    return `${s.slice(0, 3)}…${s.slice(-3)}`;
}
/**
 * Postgres 23505. The ORM wraps the driver error, so the code can sit on
 * the error itself or on its cause.
 */
function isUniqueViolation(err) {
    return err?.code === "23505" || err?.cause?.code === "23505";
}
function normaliseUrl(input) {
    if (input === null)
        return null;
    if (input === undefined || input === "")
        return undefined;
    return input.replace(/\/$/, "");
}
/** An absolute http(s) URL without a trailing slash, or null. */
function publicUrlOf(input) {
    const raw = String(input ?? "").trim().replace(/\/+$/, "");
    return /^https?:\/\/[^\s/]+/i.test(raw) ? raw : null;
}
/** The selection DocTypes on a settings row, never empty. */
function syncDoctypesOf(row) {
    const list = (0, selection_1.normalizeSyncDoctypes)(row?.sync_doctypes);
    return list.length ? list : selection_1.DEFAULT_SYNC_DOCTYPES;
}
/** "created" | "updated,skipped" | … — what an inbound apply did, short. */
function summariseActions(results) {
    const seen = [];
    for (const r of results ?? []) {
        const a = r?.ok === false ? "failed" : r?.action;
        if (a && !seen.includes(a))
            seen.push(a);
    }
    return seen.length ? seen.join(",").slice(0, 40) : null;
}
const PUSH_SETTING_KEYS = [
    "erpnext_company",
    "erpnext_price_list",
    "erpnext_customer_group",
    "erpnext_territory",
    "erpnext_shipping_account",
    "erpnext_taxes_template",
];
/** Where a pushed document lands, as the settings page shows it. */
function pushSettingsView(row) {
    const out = {};
    for (const key of PUSH_SETTING_KEYS)
        out[key] = row?.[key] ?? null;
    return out;
}
/** Stock and prices, as the settings page shows them. */
function stockSettingsView(row) {
    return {
        sync_stock: Boolean(row?.sync_stock),
        sync_prices: Boolean(row?.sync_prices),
        erpnext_warehouse: row?.erpnext_warehouse ?? null,
        medusa_stock_location_id: row?.medusa_stock_location_id ?? null,
        erpnext_safety_stock: Number(row?.erpnext_safety_stock) || 0,
    };
}
/** The invoice and storage part of the settings view. Secrets masked. */
function invoiceSettingsView(row) {
    return {
        order_document: row?.order_document ?? null,
        invoice_numbering: row?.invoice_numbering === "store" ? "store" : "erpnext",
        store_invoice_prefix: row?.store_invoice_prefix ?? null,
        store_invoice_next: row?.store_invoice_next ?? 1,
        send_invoice_to_store: Boolean(row?.send_invoice_to_store),
        record_payments: Boolean(row?.record_payments),
        payment_modes: (0, order_accounting_1.normalizePaymentModes)(row?.payment_modes),
        invoice_storage: row?.invoice_storage === "s3" ? "s3" : "local",
        invoice_local_dir: row?.invoice_local_dir ?? null,
        s3_bucket: row?.s3_bucket ?? null,
        s3_region: row?.s3_region ?? null,
        s3_endpoint: row?.s3_endpoint ?? null,
        s3_prefix: row?.s3_prefix ?? null,
        s3_force_path_style: Boolean(row?.s3_force_path_style),
        s3_access_key_id_masked: maskSecret(row?.s3_access_key_id),
        s3_secret_access_key_masked: maskSecret(row?.s3_secret_access_key),
    };
}
function applyInvoiceSettings(patch, input) {
    const text = (v) => (v ?? "").trim() || null;
    if ("order_document" in input)
        patch.order_document = text(input.order_document);
    if ("invoice_numbering" in input) {
        patch.invoice_numbering = input.invoice_numbering === "store" ? "store" : "erpnext";
    }
    if ("store_invoice_prefix" in input)
        patch.store_invoice_prefix = text(input.store_invoice_prefix);
    if (input.send_invoice_to_store !== undefined)
        patch.send_invoice_to_store = input.send_invoice_to_store;
    if (input.record_payments !== undefined)
        patch.record_payments = input.record_payments;
    if ("payment_modes" in input) {
        patch.payment_modes = input.payment_modes == null ? null : (0, order_accounting_1.normalizePaymentModes)(input.payment_modes);
    }
    if ("invoice_storage" in input)
        patch.invoice_storage = input.invoice_storage === "s3" ? "s3" : "local";
    if ("invoice_local_dir" in input)
        patch.invoice_local_dir = text(input.invoice_local_dir);
    for (const key of ["s3_bucket", "s3_region", "s3_endpoint", "s3_prefix"]) {
        if (key in input)
            patch[key] = text(input[key]);
    }
    if (input.s3_force_path_style !== undefined)
        patch.s3_force_path_style = input.s3_force_path_style;
    applySecret(patch, "s3_access_key_id", input.s3_access_key_id);
    applySecret(patch, "s3_secret_access_key", input.s3_secret_access_key);
}
function applySecret(patch, key, val) {
    // Empty string = "leave as-is" (UI sends "" when the masked
    // preview was shown but not edited). null = clear. anything else
    // = update.
    if (val === undefined)
        return;
    if (val === "")
        return;
    patch[key] = val; // could be null (clear) or a real value
}
function clampInt(n, min, max) {
    if (!Number.isFinite(n))
        return min;
    return Math.max(min, Math.min(max, Math.floor(n)));
}
/**
 * Validate + sanitise the field_mappings payload coming off the admin
 * form. Drops malformed entries silently — the admin UI rejects them
 * before save, so anything that slips through is a programming error
 * we'd rather not bubble as a 500. Returns the cleaned array ready
 * for JSON-column persistence.
 */
function validateFieldMappings(raw) {
    if (!Array.isArray(raw))
        return [];
    const out = [];
    const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : undefined);
    for (const r of raw) {
        if (!r || typeof r !== "object")
            continue;
        const medusa_path = String(r.medusa_path ?? "").trim();
        const erpnext_field = String(r.erpnext_field ?? "").trim();
        const hasConstant = r.constant !== undefined;
        const hasConstantPull = r.constant_pull !== undefined;
        // A pair needs a target on at least one side and something to write
        // to it: a push-fixed pair has an ERPNext field and no Medusa path,
        // a pull-fixed pair has a Medusa path and no ERPNext field, and an
        // ordinary pair has both.
        const pushShape = Boolean(erpnext_field) && (Boolean(medusa_path) || hasConstant);
        const pullShape = Boolean(medusa_path) && (Boolean(erpnext_field) || hasConstantPull);
        if (!pushShape && !pullShape)
            continue;
        const pair = { medusa_path, erpnext_field };
        if (hasConstant)
            pair.constant = r.constant;
        if (hasConstantPull)
            pair.constant_pull = r.constant_pull;
        if (r.direction && ["push", "pull", "both", "none"].includes(r.direction)) {
            pair.direction = r.direction;
        }
        const targetDoctype = text(r.erpnext_doctype);
        if (targetDoctype)
            pair.erpnext_doctype = targetDoctype;
        // A composite template ("{first_name} {last_name}") joins several
        // Medusa fields into one Frappe column and has no inverse. Pin it
        // to push here rather than trusting the form.
        if ((0, mapping_engine_1.isTemplatePath)(medusa_path)) {
            pair.direction = "push";
        }
        const shared = text(r.transform);
        if (shared)
            pair.transform = shared;
        const push = text(r.transform_push);
        if (push)
            pair.transform_push = push;
        const pull = text(r.transform_pull);
        if (pull)
            pair.transform_pull = pull;
        if (r.default !== undefined)
            pair.default = r.default;
        if (r.default_push !== undefined)
            pair.default_push = r.default_push;
        if (r.default_pull !== undefined)
            pair.default_pull = r.default_pull;
        if (typeof r.required === "boolean")
            pair.required = r.required;
        out.push(pair);
    }
    return out;
}
/**
 * Compute the Frappe `fields` argument for the pull query — only the
 * field names referenced in the mapping (plus `name`, `modified`, and
 * the chosen key field). Avoids over-fetching when the doctype has 50+
 * columns and we only care about 3.
 *
 * Push-only pairs are left out. A pair like `medusa_product_id <- id`
 * carries an id the store owns and names no column on a vanilla ERPNext,
 * so asking Frappe for it fails the whole page with `DataError: Field not
 * permitted in query` — and there would be nothing to read if it answered.
 */
function uniqueFrappeFields(pairs, keyField, extra = []) {
    const set = new Set(["name", "modified", ...extra]);
    if (keyField)
        set.add(keyField);
    for (const p of pairs ?? []) {
        if (!p?.erpnext_field)
            continue;
        if (String(p.direction ?? "").toLowerCase() === "push")
            continue;
        // A pair on a secondary DocType reads the linked document, not a
        // column of this one.
        if (String(p.erpnext_doctype ?? "").trim())
            continue;
        set.add(p.erpnext_field);
    }
    return Array.from(set);
}
/** Internals reachable from the unit tests, which do not boot a container. */
exports.__test__ = { uniqueFrappeFields, validateFieldMappings };
exports.default = (0, utils_1.Module)(exports.ERPNEXT_MODULE, {
    service: ErpnextModuleService,
});
//# sourceMappingURL=index.js.map